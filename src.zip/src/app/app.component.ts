import { APP_INITIALIZER, Component, Injector, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { FirebaseInitializeService } from './firebase-initialize/service/firebase-initialize.service'
import { SwPush } from '@angular/service-worker';
import { Messaging, getToken, isSupported } from '@angular/fire/messaging';
import { AuthService } from './route-guard/service/auth.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'culture-seekerz';
  constructor(private authService: AuthService) {}

  logout(): void {
    this.authService.logout();
  }
  // constructor(
  //   private swpush : SwPush, 
  //   private FirebaseInitializeService : FirebaseInitializeService,
  //   private injector: Injector ){
  //   // this.FirebaseInitializeService.checkForUpdate();
  //   console.log('FirebaseApp and Messaging providers configured.');
  // }

  // async ngOnInit(): Promise<void> {
  //   console.log('Checking if messaging is supported');
  //   if (await isSupported()) {
  //     console.log('Messaging is supported');
  //     this.subscribeToPush();
  //     await this.requestPermission();
  //   } else {
  //     console.log('Messaging is not supported on this browser.');
  //   }
  // }

  // subscribeToPush(): void {
  //   this.swpush.messages.subscribe(
  //     (message: any) => {
  //       console.log(message, 'message on the push');
  //     },
  //     (error) => {
  //       console.error('Error subscribing to push messages:', error);
  //     }
  //   );
  // }

  // async requestPermission(): Promise<void> {
  //   try {
  //     const permission = await Notification.requestPermission();
  //     if (permission === 'granted') {
  //       console.log('Notification permission granted');
  //       const messaging = this.injector.get(Messaging);
  //       const registration = await navigator.serviceWorker.ready;
  //       const token = await getToken(messaging, {
  //         vapidKey:
  //           'BCa6qyX8sst2z3OZGjPygiD4WYCFZgJH0z3nLLxR4t2v3pnEGC-z_MJ2cfXkLCRIEbZRQbakOFUMocjgvZtmsfM',
  //         serviceWorkerRegistration: registration,
  //       });
  //       console.log('FCM Token:', token);
  //     } else {
  //       console.log('Notification permission not granted');
  //     }
  //   } catch (err) {
  //     console.error('Error requesting notification permission:', err);
  //   }
  // }
  
}
// export function initializeApp(injector: Injector) {
//   return async () => {
//     // Do any async initialization here, if needed
//     const messaging = injector.get(Messaging);
//     // await messaging.init();
//   };
// }

// export const appInitializerProviders = [
//   { provide: APP_INITIALIZER, useFactory: initializeApp, deps: [Injector], multi: true }
// ];
