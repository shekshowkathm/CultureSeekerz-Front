import { Component } from '@angular/core';
import { RegistrationService } from '../service/registration.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-add-kid-register',
  standalone: true,
  imports: [HttpClientModule,],
  providers: [
    HttpClient,RegistrationService
  ],
  templateUrl: './add-kid-register.component.html',
  styleUrl: './add-kid-register.component.scss'
})
export class AddKidRegisterComponent {

  constructor(private registerService:RegistrationService){

  }

}
