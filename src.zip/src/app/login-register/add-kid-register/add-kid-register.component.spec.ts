import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddKidRegisterComponent } from './add-kid-register.component';

describe('AddKidRegisterComponent', () => {
  let component: AddKidRegisterComponent;
  let fixture: ComponentFixture<AddKidRegisterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddKidRegisterComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AddKidRegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
