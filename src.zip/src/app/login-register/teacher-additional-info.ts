export class TeacherAdditionalInfo {
  profile: string = null;
  uG: string = '';
  certificate :string = '';
  uGUniversity: string = '';
  pG: string = '';
  // pGCertificate:string = '';
  pGUniversity: string = '';
  m_Ed!: boolean ;
  b_Ed!: boolean ;
  experience: string = '';
  // b_EdCertificate: string = '';
  // m_EdCertificate:string = '';
  // expienceCertificate:string = '';
  idProof: string = '';
  b_EdInstitute: string = '';
  m_EdInstitute: string = '';
  mode: string = '';
  additionalQualification: string = '';
  specializedIn: string []= [];
  trailClass!:boolean;
  activity!: string;
  about:string = '';
  // experienceCertificate: any;

}
