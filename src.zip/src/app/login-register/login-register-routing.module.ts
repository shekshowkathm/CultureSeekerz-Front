import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { HeaderComponent } from './header/header.component';
import { WhycultureseekerzComponent } from './whycultureseekerz/whycultureseekerz.component';
import { StudentRegisterComponent } from './student-register/student-register.component';
import { ToRegisterationComponent } from './to-registeration/to-registeration.component';
import { TeacherAdditionalInformationComponent } from './teacher-additional-information/teacher-additional-information.component';
import { ForgetPasswordComponent } from './components/forget-password/forget-password.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { PasswordAreaComponent } from './components/password-area/password-area.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'header', component: HeaderComponent },
  { path: 'whycultureseekerz', component: WhycultureseekerzComponent },
  { path: 'studentRegister', component: StudentRegisterComponent },
  { path: 'toregistration', component: ToRegisterationComponent },
  { path: 'teacheraddons', component: TeacherAdditionalInformationComponent },
  { path: 'forgotpassword', component: ForgetPasswordComponent },
  { path: 'contactus', component: ContactUsComponent },
  { path: 'changepassword/:email/:id', component: PasswordAreaComponent },
 
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LoginRegisterRoutingModule {}
