import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CszlogoComponent } from './cszlogo.component';

describe('CszlogoComponent', () => {
  let component: CszlogoComponent;
  let fixture: ComponentFixture<CszlogoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CszlogoComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CszlogoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
