import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { ParentService } from '../../parent/service/parent.service';

@Component({
  selector: 'app-cszlogo',
  standalone: true,
  imports: [],
  templateUrl: './cszlogo.component.html',
  styleUrl: './cszlogo.component.scss',
})
export class CszlogoComponent {
  @Input() width: string = '400px';
  @Input() height: string = '80px';

  constructor(private router: Router, private parentService: ParentService) {}

  navigateHome() {
    const storedRole = localStorage.getItem('role');
    if (storedRole === 'STUDENT') {
      this.router.navigate(['/']);
    } else if (storedRole === 'ADMIN') {
      this.router.navigate(['/']);
    } else if (storedRole === 'TEACHER') {
      this.router.navigate(['/teacher/home']);
    } else if (storedRole === 'PARENT') {
      this.router.navigate(['/parent/parent']);
      this.parentService.setCurrentNavItem('Home');
    } else {
      this.router.navigate(['/']);
    }
  }
}
