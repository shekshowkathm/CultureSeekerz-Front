import { Component } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  Validators,
  AbstractControl,
  AsyncValidatorFn,
  ValidationErrors,
} from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatButtonModule } from '@angular/material/button';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { HeaderComponent } from '../header/header.component';
import { MatSelectModule } from '@angular/material/select';
import { TeacherAdditionalInfo } from '../teacher-additional-info';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { RegistrationService } from '../service/registration.service';
import { Observable, of } from 'rxjs';
import { environment } from '../../../environments/environment.development';
import AWSS3UploadAshClient from 'aws-s3-upload-ash';
import { UploadResponse } from 'aws-s3-upload-ash/dist/types';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-teacher-additional-information',
  standalone: true,
  imports: [
    HeaderComponent,
    FormsModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatButtonModule,
    CommonModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatCheckboxModule,
  ],
  templateUrl: './teacher-additional-information.component.html',
  styleUrl: './teacher-additional-information.component.scss',
})
export class TeacherAdditionalInformationComponent {
  fileInput: File | undefined;
  myForm!: FormGroup;
  currentFile?: File;
  fileName = 'Select File';
  fileSelected: any[] = [];
  fileLink: any;
  queryParamId: any;
  fileLocations: { [key: string]: string } = {};
  formControlNames: string[] = [];

  teacheradditionalinfo = new TeacherAdditionalInfo();
  config = {
    bucketName: 'cultureseekerz-image',
    dirName:
      'media' /* optional - when use: e.g BUCKET_ROOT/dirName/fileName.extesion */,
    region: 'ap-south-1',
    accessKeyId: environment.AWS_ACCESS_KEY,
    secretAccessKey: environment.AWS_SECRET_KEY,
    // s3Url: 'https://wherewasitshot-s3.s3.amazonaws.com/'
    s3Url: 'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/',
  };
  S3CustomClient: AWSS3UploadAshClient = new AWSS3UploadAshClient(this.config);
  fileLocation: any;
  S3link: string;
  fileNames: any;
  selectedFileName: string;

  constructor(
    private formbuilder: FormBuilder,
    private registrationService: RegistrationService,
    private route: ActivatedRoute,
    private routing: Router
  ) {}
  //  public teacheradditionalinfo!:TeacherAdditionalInfo;

  ngOnInit(): void {
    this.route.queryParams.subscribe((params) => {
      this.queryParamId = params['id'];
    });

    this.myForm = this.formbuilder.group({
      uG: [this.teacheradditionalinfo.uG, Validators.required],
      uGUniversity: [
        this.teacheradditionalinfo.uGUniversity,
        Validators.required,
      ],
      certificate: [
        this.teacheradditionalinfo.certificate,
        Validators.required,
      ],
      pG: [this.teacheradditionalinfo.pG],
      pGUniversity: [this.teacheradditionalinfo.pGUniversity],
      m_Ed: [this.teacheradditionalinfo.m_Ed, Validators.required],
      m_EdInstitute: [this.teacheradditionalinfo.m_EdInstitute],
      b_Ed: [this.teacheradditionalinfo.b_Ed, Validators.required],
      b_EdInstitute: [this.teacheradditionalinfo.b_EdInstitute],
      experience: [this.teacheradditionalinfo.experience, Validators.required],
      about: [this.teacheradditionalinfo.about, Validators.required],
      profile: [this.teacheradditionalinfo.profile],
      mode: [this.teacheradditionalinfo.mode, Validators.required],
      additionalQualification: [
        this.teacheradditionalinfo.additionalQualification,
      ],
      specializedIn: [
        this.teacheradditionalinfo.specializedIn || [],
        [Validators.required],
        [this.validateSpecializations()],
      ],
      activity: [''],
      trailClass: [this.teacheradditionalinfo.trailClass, Validators.required],
    });
  }
  /** Specialisedin checbox value*/
  isCheckboxDisabled(option: string): boolean {
    const selectedOptions = this.myForm.get('specializedIn')?.value || [];
    return selectedOptions.length >= 2 && !selectedOptions.includes(option);
  }
  validateSpecializations(): AsyncValidatorFn {
    return (control: AbstractControl): Observable<ValidationErrors | null> => {
      const selectedOptions = control.value || [];

      return of(
        selectedOptions.length > 2 ? { maxSelectionReached: true } : null
      );
    };
  }

  /**select files */
  onChangeFile(event: any, formControlName: string, index: number) {
    if (event.target.files && event.target.files.length > 0) {
      const selectedFile: File = event.target.files[0]; // Access the first file in the FileList
      if (selectedFile) {
        this.selectedFileName = selectedFile.name;
      }

      const selectedFilesArray = Array.from(event.target.files);

      // Log each selected file
      selectedFilesArray.forEach((selectedFile, fileIndex) => {
        if (this.fileSelected[index]) {
          // Replace the file at the specified index
          this.fileSelected[index] = {
            [`${formControlName}_${index + 1}`]: selectedFilesArray[0],
          };
        } else {
          // Add a new file at the specified index
          this.fileSelected[index] = {
            [`${formControlName}_${index + 1}`]: selectedFilesArray[0],
          };
        }
      });

      // Check if the index already exists in the array

      // Optionally, you can log the entire array for debugging
    } else {
      console.error('No files selected');
    }
  }

  async handleSendFiles(): Promise<void> {
    try {
      const filePromises = this.fileSelected.map(async (fileObject) => {
        const formControlName = Object.keys(fileObject)[0]; // Extract form control name
        const fileLocation = await this.handleSendFile(
          formControlName,
          fileObject[formControlName]
        );
        this.fileLocations[formControlName] = fileLocation;
      });

      await Promise.all(filePromises);

      // After all files are uploaded, update the form controls
      for (const [formControlName, fileLocation] of Object.entries(
        this.fileLocations
      )) {
        const formControl = this.myForm.get(formControlName);
        if (formControl) {
          formControl.setValue(fileLocation);
        }
      }
    } catch (error) {
      throw error;
    }
  }

  async handleSendFile(formControlName: string, file: File): Promise<string> {
    try {
      const data: UploadResponse = await this.S3CustomClient.uploadFile(
        file,
        file.type,
        undefined,
        file.name,
        'public-read',
        formControlName
      );

      return data.location;
    } catch (err) {
      throw err;
    }
  }

  /** formsubmit */
  onSubmit() {
    if (this.myForm.valid) {
      // Upload files to S3
      this.handleSendFiles()
        .then(() => {
          // Now, proceed to submit the form
          const myformvalues = this.myForm.value;

          for (const [formControlName, fileLocation] of Object.entries(
            this.fileLocations
          )) {
            if (Reflect.has(myformvalues, formControlName)) {
              Reflect.set(myformvalues, formControlName, fileLocation);
            }
          }

          myformvalues['certificate'] = this.fileLocations['Ug_1'];
          const queryParamsId = this.queryParamId;
          const localStorageId = localStorage.getItem('id');
          const bothQueryparamandlocalId = {
           id: queryParamsId || localStorageId };
          myformvalues['basicInfo'] = bothQueryparamandlocalId
          this.registrationService.submitTeacherStep2(myformvalues).subscribe({
            next: (response) => {
              if (response) {
                // Clear the local storage
                localStorage.clear();

                // Show the success message
                Swal.fire({
                  title: 'Registration Successful',
                  text: 'Welcome to cultureseekez!',
                  icon: 'success',
                  timer: 1000,
                  timerProgressBar: false,
                  showConfirmButton: false,
                });

                // Reset the form
                this.myForm.reset();
              }
              this.routing.navigate(['/login-reg/login']);
            },
            error: (error) => {},
          });
        })
        .catch((error) => {});
    } else {
    }
  }
  clearFile(fileType: string): void {
    // Assuming `fileName` is an object with keys corresponding to file types
    this.fileName[fileType] = ''; // Clear the file name

    const fileInput = document.querySelector(
      `#${fileType.toLowerCase()}CertificateInput`
    ) as HTMLInputElement | null;
    if (fileInput) {
      fileInput.value = ''; // Clear the file input value
    }

    const formControl = this.myForm.get(`${fileType.toLowerCase()}Certificate`);
    if (formControl) {
      formControl.setValue(null); // Clear the form control value
    }
  }
}
