import { Component, Inject } from '@angular/core';
import {
  Validators,
  FormsModule,
  ReactiveFormsModule,
  FormBuilder,
  FormGroup,
} from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule } from '@angular/router';
import { Login } from './login';
import { RegistrationService } from '../service/registration.service';
import { Router } from '@angular/router';
import { NgIf } from '@angular/common';
import { CszlogoComponent } from '../cszlogo/cszlogo.component';
import { HeaderComponent } from '../header/header.component';
import { ParentService } from '../../parent/service/parent.service';
import { CookieService } from 'ngx-cookie-service';
import Swal from 'sweetalert2';
import { FirebaseInitializeService } from '../../firebase-initialize/service/firebase-initialize.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    MatFormFieldModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatIconModule,
    RouterModule,
    NgIf,
    CszlogoComponent,
    HeaderComponent,
  ],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
})
export class LoginComponent {
  loginForm: FormGroup;
  loginModel: Login = new Login();
  hide = true;
  errorMessage: string = '';
  loginmessage: string | null = null;
  role: string = '';

  constructor(
    private formBuilder: FormBuilder,
    private registrationService: RegistrationService,
    private router: Router,
    private parentService: ParentService,
    private cookieService: CookieService,
    private FirebaseInitializeService: FirebaseInitializeService
  ) {
    this.loginForm = this.formBuilder.group({
      username: [this.loginModel.username, [Validators.required]],
      password: [
        this.loginModel.password,
        [Validators.required, Validators.minLength(8)],
      ],
    });
    localStorage.removeItem('loglevel');
  }

  ngOnInit() {
    // localStorage.clear();
    localStorage.removeItem('isOTPVerification');
    this.checkLocalStorage();
  }

  getErrorMessage(controlName: string): string {
    // const control = this.loginForm.get(controlName);
    // if (control && control.hasError('email')) {
    //   return 'Not a valid email';
    // }
    // return '';
    const control = this.loginForm.get(controlName);
    if (control && control.hasError('required')) {
      return `${
        controlName.charAt(0).toUpperCase() + controlName.slice(1)
      } is required`;
    } else if (control && control.hasError('minlength')) {
      return 'Password must be at least 8 characters long';
    }
    return '';
  }

  onSubmit() {
    if (this.loginForm.valid) {
      this.loginModel = { ...this.loginForm.value };
      this.registrationService.postLoginData(this.loginModel).subscribe({
        next: (response) => {
          this.loginmessage = response.response;
          if (
            this.loginmessage === 'Login successfully' ||
            this.loginmessage === 'Step2'
          ) {
            const role = response.role;
            const cookieRouteValue = this.cookieService.get('route');
            const cookieParamsValue = this.cookieService.get('params');
            localStorage.setItem('timezone', response.timeZone);
            if (
              cookieRouteValue &&
              cookieParamsValue &&
              response.role === 'STUDENT'
            ) {
              localStorage.setItem('age', response.age);
              localStorage.setItem('role', response.role);
              localStorage.setItem('token', response.token);
              localStorage.setItem('username', response.username);
              localStorage.setItem('id', response.id);
              if (cookieRouteValue === 'activityWithTeacher') {
                this.router.navigate(['/activityWithTeacher'], {
                  queryParams: {
                    Activity: cookieParamsValue,
                    class: cookieParamsValue,
                  },
                });
              } else if (
                cookieRouteValue === 'trailclass' &&
                cookieParamsValue === 'KG and Elementary'
              ) {
                this.router.navigate(['/trailclass'], {
                  queryParams: { ageGroup: cookieParamsValue },
                });
              } else if (
                cookieRouteValue === 'trailclass' &&
                cookieParamsValue === 'Middle'
              ) {
                this.router.navigate(['/trailclass'], {
                  queryParams: { ageGroup: cookieParamsValue },
                });
              } else if (
                cookieRouteValue === 'trailclass' &&
                cookieParamsValue === 'High'
              ) {
                this.router.navigate(['/trailclass'], {
                  queryParams: { ageGroup: cookieParamsValue },
                });
              } else if (cookieRouteValue === 'teacherProfileCard') {
                this.router.navigate(['/teacherProfileCard'], {
                  queryParams: { classId: cookieParamsValue },
                });
              } else {
                this.router.navigate(['/trailclass'], {
                  queryParams: { FreeTrial: 'freetrial' },
                });
              }
            } else if (
              cookieRouteValue &&
              cookieParamsValue &&
              response.role === 'PARENT'
            ) {
              localStorage.setItem('role', response.role);
              localStorage.setItem('token', response.token);
              localStorage.setItem('username', response.username);
              localStorage.setItem('id', response.id);
              const role = response.role;
              switch (role) {
                case 'STUDENT':
                  localStorage.setItem('age', response.age);
                  this.router.navigate(['/']);
                  break;
                case 'PARENT':
                  if (cookieRouteValue === 'activityWithTeacher') {
                    localStorage.setItem('currentItem', 'activitywithteacher');
                    localStorage.setItem('currentActivity', cookieParamsValue);
                    const currentnavItem = localStorage.getItem('currentItem');
                    this.router.navigate(['/parent/parent']);
                    this.parentService.setCurrentNavItem(currentnavItem);
                  } else if (cookieRouteValue === 'teacherProfileCard') {
                    localStorage.setItem('currentItem', 'teacherprofilecard');
                    localStorage.setItem(
                      'teacherprofilecardid',
                      cookieParamsValue
                    );
                    const currentnavItem = localStorage.getItem('currentItem');
                    this.router.navigate(['/parent/parent']);
                    this.parentService.setCurrentNavItem(currentnavItem);
                  } else {
                    localStorage.setItem('currentItem', 'Home');
                    const currentnavItem = localStorage.getItem('currentItem');
                    this.router.navigate(['/parent/parent']);
                    this.parentService.setCurrentNavItem(currentnavItem);
                  }
                  // setTimeout(() => {
                  //   window.location.reload();
                  // }, 300);
                  break;
                case 'TEACHER':
                  localStorage.setItem('teacherID', response.personalId);
                  this.router.navigate(['/teacher/home']);
                  break;
                case 'ADMIN':
                  this.router.navigate(['/admin/admin']);
                  break;
                default:
                  this.router.navigate(['/default']);
              }
            } else {
              localStorage.setItem('role', response.role);
              localStorage.setItem('token', response.token);
              localStorage.setItem('username', response.username);
              localStorage.setItem('id', response.id);
              const role = response.role;
              switch (role) {
                case 'STUDENT':
                  localStorage.setItem('age', response.age);
                  this.router.navigate(['/']);
                  this.FirebaseInitializeService.initializePushNotifications();

                  break;
                case 'PARENT':
                  localStorage.setItem('currentItem', 'Home');
                  const currentnavItem = localStorage.getItem('currentItem');
                  this.router.navigate(['/parent/parent']);
                  this.parentService.setCurrentNavItem(currentnavItem);
                  this.FirebaseInitializeService.initializePushNotifications();
                  break;
                case 'TEACHER':
                  localStorage.setItem('teacherID', response.personalId);
                  console.log(response, 'fgstwfst');
                  if (
                    response.role === 'TEACHER' &&
                    response.response === 'Login successfully'
                  ) {
                    this.router.navigate(['/teacher/home']);
                    this.FirebaseInitializeService.initializePushNotifications();
                  } else if (
                    response.role === 'TEACHER' &&
                    response.response !== 'Login successfully'
                  ) {
                    this.router.navigate(['/teacher/teacheraddons']);
                  }
                  break;
                case 'ADMIN':
                  this.router.navigate(['/admin/admin']);
                  break;
                default:
                  this.router.navigate(['/default']);
              }
            }

            this.cookieService.delete('route');
            this.cookieService.delete('params');
            if (response.personalId) {
              Swal.fire({
                title: 'Login Successful',
                text: 'Welcome to cultureseekez!',
                icon: 'success',
                timer: 1000,
                timerProgressBar: false,
                showConfirmButton: false,
              });
            } else if (response.role === 'ADMIN') {
              Swal.fire({
                title: 'Login Successful',
                text: 'Welcome to cultureseekez!',
                icon: 'success',
                timer: 1000,
                timerProgressBar: false,
                showConfirmButton: false,
              });
            } else if (
              response.role === 'STUDENT' ||
              response.role === 'PARENT'
            ) {
              Swal.fire({
                title: 'Login Successful',
                text: 'Welcome to cultureseekez!',
                icon: 'success',
                timer: 1000,
                timerProgressBar: false,
                showConfirmButton: false,
              });
            } else {
            }
          } else if (this.loginmessage === 'Not verified') {
            Swal.fire({
              title: 'Your are under verification process',
              text: 'Please try later',
              timer: 3000,
              timerProgressBar: false,
              icon: 'error',
              showConfirmButton: false,
            });
          } else if (this.loginmessage === 'Invalid User') {
            Swal.fire({
              title: 'Login failed',
              text: 'Please check your credentials.',
              timer: 1000,
              timerProgressBar: false,
              icon: 'error',
              showConfirmButton: false,
            });
          } else if (this.loginmessage === 'OTP not verified') {
            Swal.fire({
              title: 'OTP not verified',
              text: 'Please verify your OTP',
              icon: 'error',
              showCloseButton: true,
              confirmButtonText: 'Proceed Now',
            }).then((result) => {
              if (result.isConfirmed) {
                this.goToOTP(response);
              }
            });
          } else {
          }

          this.loginForm.reset();
        },
        error: (error) => {
          console.error('POST request failed:', error);
          Swal.fire({
            title: 'Login failed',
            text: 'Please check your credentials.',
            timer: 1000,
            timerProgressBar: false,
            icon: 'error',
            showConfirmButton: false,
          });
          // this.loginmessage = error.error.detail;
          // this.errorMessage = 'Login failed. Please check your credentials.';
        },
      });
      // this.loginForm.reset();
    } else {
      this.loginmessage = 'Please fill in all required fields';
      return;
    }
  }

  goToForgotPassword() {
    this.router.navigate(['/forgotpassword']);
  }

  checkLocalStorage(): void {
    const localRole = localStorage.getItem('role');
    if (!localRole) {
      console.log('Local storage is empty');
      // this.router.navigate(['/login']);
    } else {
      console.log('Local storage is not empty');
      this.role = localStorage.getItem('role');
      console.log(this.role);

      if (this.role === 'PARENT') {
        console.log('parent ulla pocha');
        this.router.navigate(['/parent/parent']);
      }
      // else if (this.role === 'STUDENT') {
      //   console.log("STUDENT ulla pocha");
      //   this.router.navigate(['/studenthome']);
      // }
      else if (this.role === 'TEACHER') {
        console.log('TEACHER ulla pocha');
        this.router.navigate(['/teacher/home']);
      }
    }
  }

  goToOTP(APIResponse) {
    localStorage.setItem('email', APIResponse.username);
    localStorage.setItem('isOTPVerification', 'true');
    this.router.navigate(['/login-reg/studentRegister'], {
      queryParams: { role: APIResponse.role },
    });
  }
}
