export class StudentRegister {
  firstName!: string;
  middleName!: string;
  lastName!: string;
  email!: string;
  mobileNumber!: string;
  age!:string;
  dob!: string;
  timeZone!:string;
  gender!: string;
  password!:string;
  Conformpassword!:string;
  address: Address = new Address();
}
export class Address {
  streetAddress!: string;
  city!: string;
  stateProvince!: string;
  postalCode!: string;
}


