import { Component, HostListener } from '@angular/core';
import { NgIf } from '@angular/common';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { RegistrationService } from '../service/registration.service';
import Swal from 'sweetalert2';
import { MatMenuModule } from '@angular/material/menu';
import { ParentService } from '../../parent/service/parent.service';
import { CszlogoComponent } from '../cszlogo/cszlogo.component';
import { LoginComponent } from '../login/login.component';
import { MatTooltipModule } from '@angular/material/tooltip';
import { CookieService } from 'ngx-cookie-service';
import {MatBadgeModule} from '@angular/material/badge';
import { MatTab } from '@angular/material/tabs';
import { MatTabGroup } from '@angular/material/tabs';
import { PrimeIcons } from 'primeng/api';
import { AuthService } from '../../route-guard/service/auth.service';
@Component({
  selector: 'app-header',
  standalone: true,
  imports: [
    NgIf,
    CommonModule,
    MatIconModule,
    RouterModule,
    MatMenuModule,
    CszlogoComponent,
    MatTooltipModule,
    MatBadgeModule,
    MatTab,
    MatTabGroup
    // PrimeIcons
  ],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss',
})
export class HeaderComponent {
  logoWidth: string = '240px';
  logoHeight: string = '80px';
  public username: string = '';
  public role: string = '';
  public id: string = '';
  routes: string = '';
  showManageIcon: boolean = false;
  studentResponse: any;
  studName: any;
  studEmail: any;
  studNumber: any;
  studGender: any;
  studAge: any;
  isMobileView: boolean = false;
  remainderInfo:any[]=[];
  currentClassRemainder : any[] = [] ;

  constructor(
    private dialog: MatDialog,
    private route: ActivatedRoute,
    private router: Router,
    private parentService: ParentService,
    private registrationService: RegistrationService,
    private cookieService: CookieService,
    private authService: AuthService

  ) {}

  ngOnInit() {
    const storedUsername = localStorage.getItem('username');
    this.username = storedUsername ?? '';
    const storedID = localStorage.getItem('id');
    this.id = storedID ?? '';
    const storedRole = localStorage.getItem('role');
    this.role = storedRole ?? '';
    this.route.url.subscribe((segments) => {
      segments.forEach((segment) => {
        this.routes = segment.path;
        if (segment.path === 'classWithTeacher') {
        }
      });
    });
    if (this.role === 'STUDENT') {
      this.showManageIcon = true;
      this.getStudentInfo();
    }
    this.checkIfMobileView();
    // this.getRemainderInfo();
    this.getTodayClassReminder();
  }
  openPopupLogin(): void {
    const dialogRef = this.dialog.open(LoginComponent, {
      width: '50%',
      height: 'auto',
    });
    dialogRef.afterClosed().subscribe((result) => {});
  }

  confirmLogout(): void {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You will be logged out!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, logout',
      cancelButtonText: 'No, cancel',
    }).then((result) => {
      if (result.isConfirmed) {
        this.logout();
      }
    });
  }

  logout(): void {

    this.cookieService.deleteAll();
    setTimeout(() => {
      localStorage.clear();
      sessionStorage.clear();
      document.cookie = '';
      this.cookieService.delete('route');
      this.cookieService.delete('params');
      this.parentService.setCurrentNavItem('Home');
      this.router.navigate(['/login']);
    }, 250);
    // this.authService.logout();
  }

  showParentProfile() {
    this.parentService.setCurrentNavItem('Profile');
    this.router.navigate(['/parent/parent']);
  }
  showParentProfileCalendar() {
    this.registrationService.setcalendarProfile(true);
    this.parentService.setCurrentNavItem('Profile');
    this.router.navigate(['/parent/parent']);
  }

  showTeacherProfile() {
    this.router.navigate(['/teacher/teacherprofile']);
  }
  goTOManageClass() {
    this.router.navigate(['/manageclass']);
  }

  getStudentInfo() {
    const storedID = localStorage.getItem('id');
    this.registrationService.getStudetInfo(storedID).subscribe(
      (response: any) => {
        this.studentResponse = response;
        this.studName = this.studentResponse.firstName;
        this.studNumber = this.studentResponse.mobileNumber;
        this.studEmail = this.studentResponse.email;
        this.studGender = this.studentResponse.gender;
        this.studAge = this.studentResponse.age;
      },
      (error) => {}
    );
  }

  navigateHome() {
    const storedRole = localStorage.getItem('role');
    if (storedRole === 'STUDENT') {
      this.router.navigate(['/']);
    } else if (storedRole === 'ADMIN') {
      this.router.navigate(['/']);
    } else if (storedRole === 'TEACHER') {
      this.router.navigate(['/teacher/home']);
    } else if (storedRole === 'PARENT') {
      this.router.navigate(['/parent/parent']);
      this.parentService.setCurrentNavItem('Home');
    } else {
      this.router.navigate(['/']);
    }
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.checkIfMobileView();
  }

  checkIfMobileView() {
    const mobileViewWidthThreshold = 768; // You can adjust this value according to your design
    if (window.innerWidth < mobileViewWidthThreshold) {
      this.isMobileView = true;
    } else {
      this.isMobileView = false;
    }
  }

  // getRemainderInfo(){
  //   const role = localStorage.getItem('role');
  //   if(role === 'PARENT'){
  //     this.registrationService.getRemainder().subscribe(
  //       (response: any) => {
  //         this.remainderInfo=response.remainder
  //       },
  //       (error) => {}
  //     );
  //   }
  // }

  getStudentIdForReminder(studentId : number){
      this.router.navigate(['/parent/remainder'], { queryParams: { studentId: studentId }})
  }

  getTodayClassReminder(){
    const role = localStorage.getItem('role');
    if(role === "PARENT" || role === "TEACHER"){
      this.registrationService.getCurrentDayClassRemainder().subscribe(
        response => {
          this.currentClassRemainder = response;
          console.log("Currebt Dy class" , this.currentClassRemainder)
        }
      )
    }
  }

  preventMenuClose(event: MouseEvent): void {
    console.log("closeeeee")
    event.stopPropagation();
  }

}

