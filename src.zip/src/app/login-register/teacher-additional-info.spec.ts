import { TeacherAdditionalInfo } from './teacher-additional-info';

describe('TeacherAdditionalInfo', () => {
  it('should create an instance', () => {
    expect(new TeacherAdditionalInfo()).toBeTruthy();
  });
});
