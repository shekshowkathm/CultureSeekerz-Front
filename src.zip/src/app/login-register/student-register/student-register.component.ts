import { NgIf } from '@angular/common';
import { ChangeDetectorRef, Component, ViewEncapsulation } from '@angular/core';
import { FormControl, FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { StudentRegister } from '../student-register';
import { ActivatedRoute, Router } from '@angular/router';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatNativeDateModule, MatOptionModule } from '@angular/material/core';
import { HeaderComponent } from '../header/header.component';
import { RegistrationService } from '../service/registration.service';
import { HttpClient } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import Swal from 'sweetalert2';
import { ParentService } from '../../parent/service/parent.service';
import { FirebaseInitializeService } from '../../firebase-initialize/service/firebase-initialize.service';
import {
  MatDatepickerInputEvent,
  MatDatepickerModule,
} from '@angular/material/datepicker';

@Component({
  selector: 'app-student-register',
  standalone: true,
  imports: [
    FormsModule,
    ReactiveFormsModule,
    NgIf,
    MatInputModule,
    MatSelectModule,
    MatOptionModule,
    HeaderComponent,
    HttpClientModule,
    MatDatepickerModule,
    MatNativeDateModule,
  ],
  providers: [HttpClient],
  templateUrl: './student-register.component.html',
  styleUrl: './student-register.component.scss',
  encapsulation: ViewEncapsulation.None,
})
export class StudentRegisterComponent {
  studentForm: FormGroup | undefined | any;
  student: StudentRegister = new StudentRegister();
  showOtpSection: boolean = true;
  showSuccessRej: boolean = true;
  keyFromQueryParams: string = '';
  otpForm: FormGroup | undefined | any;
  generalInfoResponse: any;
  otpValue: string = '';
  errorMessage: string | null = null;
  errorEmailMessage: string | null = null;
  role: string = '';
  studentid!: number;
  showTimer: boolean = true;
  minutes: string = '02';
  seconds: string = '00';
  formData: any = {};
  isInvalidOTP: boolean = false;
  registerReponseRole: String;

  constructor(
    private Formbuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private registrationService: RegistrationService,
    private cdr: ChangeDetectorRef,
    private parentService: ParentService,
    private FirebaseInitializeService: FirebaseInitializeService
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe((params) => {
      this.keyFromQueryParams = params['role'];
    });
    this.otpForm = this.Formbuilder.group({
      otp: ['', [Validators.required, this.otpValidator]],
    });
    this.FormValidation();
    if (localStorage.getItem('isOTPVerification')) {
      this.successRej();
      this.resendOtp();
    }
  }

  otpValidator(control) {
    const validPattern = /^[0-9]{6}$/;
    if (!validPattern.test(control.value)) {
      return { invalidOTP: true };
    }
    return null;
  }

  FormValidation(): void {
    this.studentForm = this.Formbuilder.group({
      firstName: [
        this.student.firstName,
        [Validators.required, this.alphaOnlyValidator()],
      ],
      middleName: [null],
      lastName: [
        this.student.lastName,
        [Validators.required, this.alphaOnlyValidator()],
      ],
      email: [
        null,
        [
          Validators.required,
          (control) =>
            ['TEACHER', 'PARENT'].includes(this.keyFromQueryParams)
              ? Validators.email(control)
              : Validators.nullValidator(control),
          ...(['TEACHER', 'PARENT'].includes(this.keyFromQueryParams)
            ? [this.lowercaseValidator]
            : []),
        ],
      ],
      // mobileNumber: [this.student.mobileNumber,[ Validators.pattern('^[0-9]{10}$')]],
      mobileNumber: [
        this.student.mobileNumber,
        [
          this.keyFromQueryParams === 'TEACHER' ||
          this.keyFromQueryParams === 'PARENT'
            ? Validators.required
            : Validators.nullValidator,
          Validators.pattern('^[0-9]{10}$'),
        ],
      ],
      age: [
        this.student.age,
        [Validators.min(1), Validators.max(999), this.maxLengthValidator(3)],
      ],
      dob: [this.student.dob, []],
      timeZone: [this.student.timeZone],
      gender: [this.student.gender, Validators.required],
      password: ['', [Validators.required, Validators.minLength(8)]],
      conformPassword: ['', Validators.required],
    });
    this.studentForm.setValidators(this.passwordMatchValidator.bind(this));
    if (this.keyFromQueryParams === 'STUDENT') {
      this.studentForm.get('timeZone').setValue(''); // Set empty string for dob
      this.studentForm.get('timeZone').clearValidators();
    } else {
      this.studentForm.get('age').setValue('');
      this.studentForm.get('age').clearValidators();
    }
    if (this.keyFromQueryParams === 'PARENT') {
      this.studentForm.get('timeZone').setValidators(Validators.required);
    } else {
      this.studentForm.get('timeZone').setValue(''); // Set empty string for dob
      this.studentForm.get('timeZone').clearValidators();
    }
  }
  lowercaseValidator(control) {
    const email = control.value;
    if (email && email !== email.toLowerCase()) {
      return { lowercase: true };
    }
    return null;
  }

  hasLowercaseError(controlName: string): boolean {
    const control = this.studentForm.get(controlName);
    return control ? control.hasError('lowercase') && control.touched : false;
  }

  restrictToNumbers() {
    const mobileNoControl = this.studentForm.get('mobileNumber');
    if (mobileNoControl) {
      const numericValue = mobileNoControl.value.replace(/[^0-9]/g, '');
      const isValid = /^\d{10}$/.test(numericValue);
      mobileNoControl.setValue(numericValue);
      mobileNoControl.setErrors(isValid ? null : { pattern: true });
    }
  }

  passwordMatchValidator(formGroup: FormGroup) {
    const passwordControl = formGroup.get('password');
    const conformPasswordControl = formGroup.get('conformPassword');

    if (passwordControl && conformPasswordControl) {
      const password = passwordControl.value;
      const conformPassword = conformPasswordControl.value;
      if (!conformPassword) {
        conformPasswordControl.setErrors({ required: true });
      } else if (password !== conformPassword) {
        conformPasswordControl.setErrors({ passwordMismatch: true });
      } else {
        conformPasswordControl.setErrors(null);
      }
    }
  }

  maxLengthValidator(maxLength: number) {
    return (control) => {
      const value = control.value;
      if (value && value.toString().length > maxLength) {
        return { maxLength: true };
      }
      return null;
    };
  }

  submitGeneralInfo(): void {
    if (this.studentForm.valid) {
      const formData = {
        ...this.studentForm.value,
        role: this.keyFromQueryParams,
        password: this.studentForm.get('password').value,
      };
      this.registrationService.submitRegisterData(formData).subscribe(
        (response) => {
          this.registerReponseRole = response.role;

          this.studentForm.reset();
          if (response.role !== 'STUDENT') {
            localStorage.setItem('id', response.id);
            localStorage.setItem('email', response.email);
          } else if (
            response.response === 'Email already exist' &&
            response.role !== 'STUDENT'
          ) {
            this.errorEmailMessage =
              'Email already exists. Please use a different email.';
          } else {
            const parentID = localStorage.getItem('id');
            const childObject = {
              id: parentID,
              child: [{ id: response.id }],
            };
            this.updateParentDetails(childObject);
            this.FirebaseInitializeService.sendDataToFirebaseService(
              childObject
            );
          }

          if (response.response !== 'Email already exist') {
            this.showSuccessRej = false;
            this.showOtpSection = true;
            this.studentForm.reset();
            this.generalInfoResponse = response;
          } else {
            this.errorEmailMessage =
              'Email already exists. Please use a different email.';
          }

          if (
            this.registerReponseRole === 'STUDENT' ||
            this.registerReponseRole === 'TEACHER'
          ) {
            if (response.response !== 'Email already exist') {
              this.showOtpSection = false;
              this.showSuccessRej = false;
              this.startTimer();
            }
          }
        },
        (error) => {}
      );
    } else {
      this.markFormGroupTouched(this.studentForm);
    }
  }

  successRej() {
    this.showSuccessRej = false;
    this.showOtpSection = false;
    this.startTimer();
  }
  noGoToOTP() {
    this.resendOtp();
    this.showSuccessRej = false;
    this.showOtpSection = false;
    this.startTimer();
  }

  yesGoToChildRegister() {
    if (this.keyFromQueryParams === 'PARENT') {
      this.keyFromQueryParams = 'STUDENT';
      this.showSuccessRej = true;
      this.studentForm.get('timeZone').setValue('');
      this.studentForm.get('timeZone').clearValidators();
    }
    this.keyFromQueryParams = 'STUDENT';
    this.FormValidation();
    console.log(this.keyFromQueryParams, 'yesGoToChildRegister');
  }

  resendOtp(): void {
    this.stopTimer();
    this.minutes = '02';
    this.seconds = '00';
    this.startTimer();
    this.otpValue = '';
    const email = localStorage.getItem('email');
    this.registrationService.resendOTP(email).subscribe({
      next: (response) => {},
      error: (error) => {},
    });
  }

  startTimer(): void {
    this.showTimer = true;
    const timer = setInterval(() => {
      let currentMinutes = parseInt(this.minutes);
      let currentSeconds = parseInt(this.seconds);

      if (currentMinutes === 0 && currentSeconds === 0) {
        this.stopTimer();
        clearInterval(timer);
      } else {
        if (currentSeconds === 0) {
          currentMinutes--;
          currentSeconds = 59;
        } else {
          currentSeconds--;
        }

        this.minutes = currentMinutes.toString().padStart(2, '0');
        this.seconds = currentSeconds.toString().padStart(2, '0');
      }
    }, 1000);
  }

  stopTimer(): void {
    this.showTimer = false;
  }

  showTimeoutAlert(): void {
    Swal.fire({
      title: 'OTP Time Expired',
      text: 'Click resend OTP button',
      icon: 'error',
      confirmButtonText: 'Resend OTP',
    }).then((result) => {
      if (result.isConfirmed) {
        this.resendOtp();
      }
    });
  }

  goToLogin(): void {
    this.router.navigateByUrl('/login');
  }

  submitOtp(otp: string): void {
    if (this.otpForm.valid) {
      this.registrationService.submitOtp(otp).subscribe({
        next: (response) => {
          this.otpValue = '';
          this.stopTimer();
          if (
            response.response === 'OTP is correct' &&
            response.age < 18 &&
            response.role === 'STUDENT'
          ) {
            this.keyFromQueryParams = 'PARENT';
            this.showSuccessRej = true;
            this.showOtpSection = true;
            this.studentid = response.id;
            Swal.fire({
              title: 'Registration Successful',
              text: 'Welcome to cultureseekez!',
              icon: 'success',
              timer: 1000,
              timerProgressBar: false,
              showConfirmButton: false,
            });
          } else if (response.role === 'TEACHER') {
            const id = response.id;
            this.router.navigate(['/teacheraddons'], {
              queryParams: { id: id },
            });
          } else if (response.response === 'OTP is invalid') {
            this.showOtpSection = false;
            this.isInvalidOTP = true;
          } else {
            Swal.fire({
              title: 'Registration Successful',
              text: 'Welcome to cultureseekez!',
              icon: 'success',
              timer: 1000,
              timerProgressBar: false,
              showConfirmButton: false,
            });
            this.router.navigate(['/login-reg/login']);
          }
        },
        error: (error) => {
          this.errorMessage = 'Error submitting OTP. Please try again.';
          this.cdr.detectChanges();
          this.stopTimer();
        },
      });
      this.showOtpSection = false;
    } else {
      this.markFormGroupTouched(this.otpForm);
    }
    this.studentForm.reset();
    // this.FirebaseInitializeService.initializePushNotifications();
  }

  markFormGroupTouched(formGroup: FormGroup): void {
    Object.values(formGroup.controls).forEach((control) => {
      control.markAsTouched();
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }

  isInvalid(controlName: string): boolean {
    const control = this.studentForm.get(controlName);
    return control ? control.invalid && control.touched : false;
  }

  getErrorMessage(controlName: string): string {
    const control = this.studentForm.get(controlName);
    if (control && control.errors) {
      if (control.errors.required) {
        return 'Email is required';
      } else if (control.errors.email) {
        return 'Email is not valid';
      }
    }
    return '';
  }

  validateMaxLength(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.value.length > 3) {
      input.value = input.value.slice(0, 3);
      this.studentForm.controls['age'].setValue(input.value);
    }
  }

  isInvalidOtp(): boolean {
    const control = this.otpForm.get('otp');
    return control ? control.invalid && control.touched : false;
  }

  alphaOnlyValidator(): any {
    return (control: FormControl): { [key: string]: any } | null => {
      const alphaRegex = /^[a-zA-Z]+$/;
      if (control.value && !alphaRegex.test(control.value)) {
        return { alphaOnly: true }; // Return validation error if input contains anything other than alphabets
      }
      return null; // Return null if validation passes
    };
  }

  updateParentDetails(parentDetails: any): void {
    this.parentService.addKidsToParent(parentDetails).subscribe({
      next: (response) => {},
      error: (error) => {},
    });
  }
  validateDate(event: Event) {
    const dateControl = this.studentForm.get('dob') as FormControl;

    // Clear any previous validation errors
    dateControl.setErrors(null);

    // Get the entered date as a string
    const enteredDate = (event.target as HTMLInputElement).value;

    // Regular expression for basic date format validation (YYYY-MM-DD)
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;

    // Validate basic format
    if (!dateRegex.test(enteredDate)) {
      dateControl.setErrors({ invalidFormat: true });
      return;
    }

    // Convert the string to a JavaScript Date object
    const dateObject = new Date(enteredDate);

    // Validate if it's a valid date (not NaN)
    if (isNaN(dateObject.getTime())) {
      dateControl.setErrors({ invalidDate: true });
      return;
    }

    // Validate date is in the past (assuming DOB cannot be a future date)
    if (dateObject > new Date()) {
      dateControl.setErrors({ futureDate: true });
      return;
    }
  }

  onDateChange(event: any) {
    const dateControl = this.studentForm.get('dob') as FormControl;
    if (event.value) {
      const formattedDate = this.formatDate(event.value);
      dateControl.setValue(formattedDate);
    }
  }

  formatDate(date: Date): string {
    const year = date.getFullYear();
    const month = ('0' + (date.getMonth() + 1)).slice(-2);
    const day = ('0' + date.getDate()).slice(-2);
    return `${year}-${month}-${day}`;
  }
}
