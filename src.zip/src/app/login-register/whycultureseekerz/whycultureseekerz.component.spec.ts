import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WhycultureseekerzComponent } from './whycultureseekerz.component';

describe('WhycultureseekerzComponent', () => {
  let component: WhycultureseekerzComponent;
  let fixture: ComponentFixture<WhycultureseekerzComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WhycultureseekerzComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(WhycultureseekerzComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
