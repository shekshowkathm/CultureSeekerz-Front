import { Component } from '@angular/core';
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from "../components/footer/footer.component";
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { NgIf } from '@angular/common';
import { ProgressSpinnerModule } from 'primeng/progressspinner';

@Component({
    selector: 'app-whycultureseekerz',
    standalone: true,
    templateUrl: './whycultureseekerz.component.html',
    styleUrl: './whycultureseekerz.component.scss',
    imports: [HeaderComponent, FooterComponent,MatProgressSpinnerModule,NgIf,ProgressSpinnerModule]
})
export class WhycultureseekerzComponent {
  imageLoaded: boolean = false;

  constructor() {
  }
  ngOnInit() {
    this.loadImage();
  }
  loadImage() {
    const img = new Image();
    img.onload = () => {
      this.imageLoaded = true;
    };
    img.src = "https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/why cultureseekerz addon.svg";
  }
}
