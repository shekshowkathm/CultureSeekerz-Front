import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { MatIconModule, MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [MatIconModule],
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.scss',
  providers: [HttpClient, MatIconRegistry],
})
export class FooterComponent {
  email: string = 'support@cultureseekerz.com';
  constructor(
    private matIconRegistry: MatIconRegistry,
    private domSanitizer: DomSanitizer,
    private router: Router
  ) {
    this.matIconRegistry.addSvgIcon(
      'linkedin',
      this.domSanitizer.bypassSecurityTrustResourceUrl(
        '../../../../assets/SVG icon/linkedin.svg'
      )
    );
  }
  openLinkedIn() {
    window.open('https://www.linkedin.com/company/cultureseekerz/', '_blank');
  }
  openInstagram() {
    window.open('https://www.instagram.com/culture_seekerz/?hl=en', '_blank');
  }
  openFacebook() {
    window.open(
      'https://www.facebook.com/share/nEtqXSuGDD3EeDPz/?mibextid=qi2Omg',
      '_blank'
    );
  }
  openGmail() {
    window.open('mailto:' + this.email);
  }
  homeroute() {
    this.router.navigate(['']).then(() => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }
  whyculturesekers() {
    this.router.navigate(['/whycultureseekerz']).then(() => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }
  aboutUs() {
    this.router.navigate(['/aboutus']).then(() => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }
  contactUs() {
    this.router.navigate(['/contactus']).then(() => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }
}
