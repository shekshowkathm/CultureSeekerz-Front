import { Component } from '@angular/core';
import { HeaderComponent } from '../../header/header.component';
import { FooterComponent } from '../footer/footer.component';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { NgFor, NgIf } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RegistrationService } from '../../service/registration.service';

@Component({
  selector: 'app-contact-us',
  standalone: true,
  imports: [
    HeaderComponent,
    FooterComponent,
    MatIconModule,
    MatButtonModule,
    NgIf,
    NgFor,
    FormsModule,
    ReactiveFormsModule,
  ],
  templateUrl: './contact-us.component.html',
  styleUrl: './contact-us.component.scss',
})
export class ContactUsComponent {
  emailID: string = 'support@cultureseekerz.com';

  constructor(private registrationService: RegistrationService) {}

  onSubmit(userForm) {
    console.log(userForm.value);
    this.registrationService.feedbackPost(userForm.value).subscribe({
      next: (response) => {
        console.log(response);
        userForm.reset();
      },
      error: (err) => {
        console.log(err);
      },
    });
  }
}
