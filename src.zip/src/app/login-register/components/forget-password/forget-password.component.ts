import { NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, NgForm, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import Swal from 'sweetalert2';
import { RegistrationService } from '../../service/registration.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forget-password',
  standalone: true,
  imports: [MatButtonModule, NgIf, FormsModule, ReactiveFormsModule],
  templateUrl: './forget-password.component.html',
  styleUrl: './forget-password.component.scss',
})
export class ForgetPasswordComponent {
  constructor(
    private registrationService: RegistrationService,
    private router: Router
  ) {}

  submitForm(form: NgForm) {
    if (form.valid) {
      this.registrationService.sendEmailToUser(form.value.email).subscribe({
        next: (response: any) => {
          form.resetForm();
          if (response.response === 'Mail send') {
            this.showSuccessAlert();
          } else {
            this.validEmailAlert();
          }
        },
        error: (error: any) => {
          form.resetForm();
          console.error('Error fetching data:', error);
        },
      });

    } else {
    }
  }

  showPasswordMismatchAlert() {
    Swal.fire({
      icon: 'error',
      title: 'Passwords do not match',
      text: 'Please make sure your passwords match.',
    });
  }

  showSuccessAlert() {
    Swal.fire({
      title: 'Your email has been successfully validated.',
      text: 'Please check your inbox',
      icon: 'success',
      confirmButtonText: 'OK',
      customClass: {
        popup: 'sweetalert-custom-font',
        title: 'sweetalert-custom-font',
      },
    });
  }

  validEmailAlert() {
    Swal.fire({
      title: 'Email does not exist',
      text: 'Please enter a valid email address',
      icon: 'error',
      confirmButtonText: 'OK',
      customClass: {
        popup: 'sweetalert-custom-font',
        title: 'sweetalert-custom-font',
      },
    });
  }

  goToLogin() {
    this.router.navigateByUrl('/login');
  }
}
