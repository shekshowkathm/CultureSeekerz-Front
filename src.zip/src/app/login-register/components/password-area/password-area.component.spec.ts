import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PasswordAreaComponent } from './password-area.component';

describe('PasswordAreaComponent', () => {
  let component: PasswordAreaComponent;
  let fixture: ComponentFixture<PasswordAreaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PasswordAreaComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PasswordAreaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
