import { NgFor, NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, NgForm, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import Swal from 'sweetalert2';
import { RegistrationService } from '../../service/registration.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-password-area',
  standalone: true,
  imports: [NgIf, FormsModule, ReactiveFormsModule, NgFor, MatButtonModule],
  templateUrl: './password-area.component.html',
  styleUrl: './password-area.component.scss',
})
export class PasswordAreaComponent {
  userEmail: string = '';
  constructor(
    private registrationService: RegistrationService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe((params) => {
      const email = params['email'];
      this.userEmail = email;
    });
    // this.showSuccessAlert();
  }

  submitForm(form: NgForm) {
    // Handle form submission logic here

    if (form.valid) {
      if (form.value.password != form.value.confirmPassword) {
        form.resetForm();
        this.showPasswordMismatchAlert();
      } else {
        const passwordObject = {
          email: this.userEmail,
          password: form.value.password,
        };

        this.registrationService.updatePassword(passwordObject).subscribe(
          (response: any) => {
            form.resetForm();
            this.showSuccessAlert();
          },
          (error) => {
            console.error('Update password request failed:', error);
          }
        );
      }
    } else {
    }
  }

  showPasswordMismatchAlert() {
    Swal.fire({
      icon: 'error',
      title: 'Passwords do not match',
      text: 'Please make sure your passwords match.',
      customClass: {
        popup: 'sweetalert-custom-font',
        title: 'sweetalert-custom-font',
      },
    });
  }

  showSuccessAlert() {
    Swal.fire({
      title: 'Password Updated Successfully',

      icon: 'success',
      showCancelButton: false, // Change this to false to hide the cancel button
      confirmButtonText: 'Go to Login',
      customClass: {
        popup: 'sweetalert-custom-font',
        title: 'sweetalert-custom-font',
      },
    }).then((result) => {
      if (result.isConfirmed) {
        // Redirect to login page or navigate as needed
        this.router.navigateByUrl('/login');
      } else {
      }
    });
  }
}
