import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginRegisterRoutingModule } from './login-register-routing.module';
import { HeaderComponent } from './header/header.component';
import { HttpClientModule } from '@angular/common/http';
import { RegistrationService } from './service/registration.service';
import { ParentService } from '../parent/service/parent.service';



@NgModule({
  declarations: [
  ],
  exports: [
    HeaderComponent,

  ],
  imports: [
    CommonModule,
    LoginRegisterRoutingModule,
    HeaderComponent,
    HttpClientModule,
  ],
  providers: [
    RegistrationService,ParentService,

  ],
})
export class LoginRegisterModule {}
