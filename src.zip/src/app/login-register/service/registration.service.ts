import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import {
  BehaviorSubject,
  Observable,
  catchError,
  map,
  tap,
  throwError,
} from 'rxjs';
import { StudentRegister } from '../student-register';
import { Login } from '../login/login';
import { TeacherAdditionalInfo } from '../teacher-additional-info';
import { environment } from '../../../environments/environment.development';

@Injectable({
  providedIn: 'root',
})
export class RegistrationService {
  public api = environment.localdomain + '/seekerz/add';
  public OtpApi = environment.localdomain + '/seekerz/verifyOtp';
  public loginApi = environment.localdomain + '/seekerz/authenticate';
  public teacherAddons = environment.localdomain + '/teacher/add';
  public updateForgotPassword =
    environment.localdomain + '/seekerz/forgotPassword';
  public resendOTPAPI = environment.localdomain + '/seekerz/resend/';
  public getStudentDetailsAPI = environment.localdomain + '/seekerz/get/';
  public sendEmailAPI = environment.localdomain + '/seekerz/forgotpassword/';
  public remainderAPI = environment.localdomain + '/student/paymentremainder/';
  public uniqueTeacherRemainderDetails =
    environment.localdomain + '/student/remainderclass/';
  public currentClassRemainder =
    environment.localdomain + '/pushnotification/getTodayClass/';

  public feedbackAdd = environment.localdomain + '/feedback/savefeedback';

  private calendarProfileSubject: BehaviorSubject<boolean> =
    new BehaviorSubject<boolean>(false);
  public calendarProfile$: Observable<boolean> =
    this.calendarProfileSubject.asObservable();
  private authToken: string | null = null;
  token: any;

  constructor(private http: HttpClient) {}
  /**
   *Data passing login to header
   */
  loginResponceData: any = {};

  setcalendarProfile(newValue: boolean): void {
    this.calendarProfileSubject.next(newValue);
  }

  setloginResponceData(data: any): void {
    this.loginResponceData = data;
  }
  getloginResponceData(): any {
    return this.loginResponceData;
  }

  /**
   * @returns headers
   */
  private getRequestOptions(): { headers: HttpHeaders } {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return { headers };
  }
  /**
   * @param person srudent,parent and teacher
   * @returns
   */
  submitRegisterData(person: StudentRegister): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const requestBody = JSON.stringify(person);
    return this.http.post(this.api, requestBody, requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError)
    );
  }
  submitTeacherStep2(
    additionalDetails: TeacherAdditionalInfo
  ): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const requestBody = JSON.stringify(additionalDetails);
    return this.http.post(this.teacherAddons, requestBody, requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError)
    );
  }

  /**
   * @param otp
   * @returns
   */
  submitOtp(otp: string): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const apiUrl = `${this.OtpApi}/${otp}`;
    return this.http.get(apiUrl, requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError)
    );
  }
  /**
   * @param loginData
   * @returns
   */
  postLoginData(loginData: Login): Observable<any> {
    console.log(loginData, 'ssssssss');
    const requestOptions = this.getRequestOptions();
    const requestBody = JSON.stringify(loginData);
    return this.http.post(this.loginApi, requestBody, requestOptions).pipe(
      tap((response: any) => {
        console.log('POST request successful:', response);
        if (response.token) {
          this.token = response.token;
        }
      }),
      catchError(this.handleError)
    );
  }
  /**
   * @param error
   */
  private handleError(error: any): Observable<never> {
    console.error('An error occurred:', error);
    throw error;
  }

  updatePassword(object: any) {
    console.log(object);
    const requestOptions = this.getRequestOptions();
    return this.http.put(this.updateForgotPassword, object, requestOptions);
  }

  resendOTP(id: any) {
    return this.http.get<any>(this.resendOTPAPI + id);
  }

  private getRequestOptionsWithToken(): { headers: HttpHeaders } {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + localStorage.getItem('token'),
    });
    return { headers };
  }

  getStudetInfo(id: string) {
    const requestOptions = this.getRequestOptionsWithToken();
    return this.http.get(this.getStudentDetailsAPI + id, requestOptions);
  }

  sendEmailToUser(email: string) {
    return this.http.get(this.sendEmailAPI + email);
  }

  getRemainder() {
    const id = localStorage.getItem('id');
    const requestOptions = this.getRequestOptionsWithToken();
    return this.http.get(this.remainderAPI + id, requestOptions);
  }

  getReminderTeacherDetails(id: number) {
    const requestOptions = this.getRequestOptionsWithToken();
    const timeZone = localStorage.getItem('timezone');
    return this.http.get<any>(
      `${this.uniqueTeacherRemainderDetails}${id}/${timeZone}`,
      requestOptions
    );
  }

  getCurrentDayClassRemainder() {
    const id = localStorage.getItem('id');
    const role = localStorage.getItem('role');
    const url = `${this.currentClassRemainder}${id}/${role}`;
    return this.http.get<any>(url, this.getRequestOptionsWithToken());
  }

  feedbackPost(data): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.post(this.feedbackAdd, data, requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError)
    );
  }
}
