import { Component } from '@angular/core';
import { HeaderComponent } from '../header/header.component';
import { Router, RouterModule } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-to-registeration',
  standalone: true,
  imports: [
    HeaderComponent,
    RouterModule,MatButtonModule
  ],
  templateUrl: './to-registeration.component.html',
  styleUrl: './to-registeration.component.scss'
})
export class ToRegisterationComponent {

  constructor(private router: Router) {}
  showAgeContainer: boolean = false;
  toggleAgeContainer() {
    this.showAgeContainer = !this.showAgeContainer;
  }
  routeToParentRegistration() {
    this.router.navigate(['/login-reg/studentRegister'], { queryParams: { role: 'PARENT' }});
  }

  routeToStudentRegistration() {
    this.router.navigate(['/login-reg/studentRegister'], { queryParams: { role: 'STUDENT' }});
  }

}
