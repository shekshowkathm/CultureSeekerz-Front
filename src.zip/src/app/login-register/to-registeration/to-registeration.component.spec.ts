import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ToRegisterationComponent } from './to-registeration.component';

describe('ToRegisterationComponent', () => {
  let component: ToRegisterationComponent;
  let fixture: ComponentFixture<ToRegisterationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ToRegisterationComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ToRegisterationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
