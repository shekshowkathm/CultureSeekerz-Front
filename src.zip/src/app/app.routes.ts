import { Routes } from '@angular/router';



export const routes: Routes = [
  {path:"login-reg",loadChildren:()=>import ('./login-register/login-register.module').then(m=>m.LoginRegisterModule)},
  {path:"",loadChildren:()=>import ('./user/user.module').then(m=>m.UserModule)},
  {path:"teacher",loadChildren:()=>import ('./teacher-module/teacher-module.module').then(m=>m.TeacherModuleModule)},
  {path:"parent",loadChildren:()=>import ('./parent/parent.module').then(m=>m.ParentModule)},
  {path:"admin",loadChildren:()=>import ('./admin/admin.module').then(m=>m.AdminModule)},
];
