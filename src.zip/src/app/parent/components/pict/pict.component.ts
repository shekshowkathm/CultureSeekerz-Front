import { Component } from '@angular/core';
import AWSS3UploadAshClient from 'aws-s3-upload-ash';
import { UploadResponse } from 'aws-s3-upload-ash/dist/types';
import { environment } from '../../../../environments/environment.development';

import { HeaderComponent } from '../../../login-register/header/header.component';
import { NgFor } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { DialogueComponent } from './dialogue/dialogue.component';

@Component({
  selector: 'app-pict',
  standalone: true,
  imports: [HeaderComponent,NgFor],
  templateUrl: './pict.component.html',
  styleUrl: './pict.component.scss',
})
export class PictComponent {
  filesSelected: any[] = [];
  keyObjects: any[] = [];
  config = {
    bucketName: 'cultureseekerz-image',
    dirName: 'media',
    region: 'ap-south-1',
    accessKeyId: environment.AWS_ACCESS_KEY,
    secretAccessKey: environment.AWS_SECRET_KEY,
    s3Url: 'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/',
  };
  S3CustomClient: AWSS3UploadAshClient = new AWSS3UploadAshClient(this.config);
  fileLocations: any[] = [];

  constructor(public dialog: MatDialog) {}

  ngOnInit(): void {}

  getKey(keyObject: any): string {
    return Object.keys(keyObject)[0];
  }

  onChangeFile(event: any) {
    this.filesSelected = Array.from(event.target.files);
  }


async handleSendFiles() {

  console.log('handleSendFiles');

  for (let i = 0; i < this.filesSelected.length; i++) {
    const file = this.filesSelected[i];
    console.log(file.name);

    // Dynamically generate a unique key based on file properties or user input
    const keyName = `key${i + 1}_${Date.now()}`;
    const keyValuePair = { [keyName]: file.name };

    // Store key-value pair in the array
    this.keyObjects.push(keyValuePair);

    await this.S3CustomClient.uploadFile(
      file,
      file.type,
      undefined,
      file.name,
      'public-read'
    )
      .then((data: UploadResponse) => {
        console.log(data);
        this.fileLocations.push(data.location);
      })
      .catch((err: any) => console.error(err));
  }

  console.log(this.keyObjects);
  console.log(this.fileLocations);
}
// async updateFile(file: File, key: string) {
//   console.log(`Updating file with key: ${key}`);

//   await this.S3CustomClient.uploadFile(
//     file,
//     file.type,
//     undefined,
//     key,
//     'public-read'
//   )
//   .then((data: UploadResponse) => {
//     console.log('File updated successfully:', data);
//     const index = this.fileLocations.findIndex(location => location.includes(key));
//     if (index !== -1) {
//       this.fileLocations[index] = data.location;
//     }
//   })
//   .catch((err: any) => console.error(err));
// }

// async deleteFile(key: string) {
//   console.log(`Deleting file with key: ${key}`);

//   await this.S3CustomClient.deleteFile(key)
//   .then(() => {
//     console.log('File deleted successfully');
//     const index = this.fileLocations.findIndex(location => location.includes(key));
//     if (index !== -1) {
//       this.fileLocations.splice(index, 1);
//     }
//     const keyIndex = this.keyObjects.findIndex(obj => this.getKey(obj) === key);
//     if (keyIndex !== -1) {
//       this.keyObjects.splice(keyIndex, 1);
//     }
//   })
//   .catch((err: any) => console.error(err));
// }

openDialog(): void {
  this.dialog.open(DialogueComponent, {
    width: '500px',  // Specify width here
    height: '500px'  // Specify height here
  });

}
}
