import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GoalsFeedbackComponent } from './goals-feedback.component';

describe('GoalsFeedbackComponent', () => {
  let component: GoalsFeedbackComponent;
  let fixture: ComponentFixture<GoalsFeedbackComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GoalsFeedbackComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(GoalsFeedbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
