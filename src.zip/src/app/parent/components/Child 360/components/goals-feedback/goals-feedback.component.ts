import { HttpClient } from '@angular/common/http';
import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { ParentService } from '../../../../service/parent.service';
import { NgIf, NgFor } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { HeaderComponent } from '../../../../../login-register/header/header.component';
import { Child360Service } from '../../../../service/child360.service';

@Component({
  selector: 'app-goals-feedback',
  standalone: true,
  templateUrl: './goals-feedback.component.html',
  styleUrl: './goals-feedback.component.scss',
  imports: [NgIf, NgFor, HeaderComponent, CommonModule],
})
export class GoalsFeedbackComponent {
  activity: { [key: string]: SafeHtml } = {};
  icons: any;
  showAllTeachers: boolean[] = [];
  showFullGoalDescription: boolean = false;
  showFullFeedbackDescription: boolean=false;
  currentChildId: number;
  goalsAndFeedbackResponse: any[] = [];
  currentNavItem: string;

  constructor(
    private http: HttpClient,
    private sanitizer: DomSanitizer,
    private parentService: ParentService,
    private router: Router,
    private route: ActivatedRoute,
    private child360Service: Child360Service
  ) {
    this.loadActivitySvgData();
  }

  ngOnInit() {
    this.route.paramMap.subscribe((params) => {
      this.currentChildId = +params.get('id');
      console.log(
        'Current Child ID in Goals and feedback:',
        this.currentChildId
      );
    });
    this.initializeShowFullDescription();
    if (
      localStorage.getItem('particularAgeWiseData') &&
      localStorage.getItem('particularAgeWiseDataCurrentActivity')
    ) {
      this.goalsAndFeedbackByAgeWise();
    } else {
      this.goalsAndFeedback();
    }
  }

  loadActivitySvgData() {
    this.http
      .get('assets/JsonFile/activityIcon.json')
      .subscribe((data: any) => {
        this.activity['bible'] = this.sanitizer.bypassSecurityTrustHtml(
          data.bible
        );
        this.activity['carnatic'] = this.sanitizer.bypassSecurityTrustHtml(
          data.carnatic
        );
        this.activity['sloga'] = this.sanitizer.bypassSecurityTrustHtml(
          data.sloga
        );
        this.activity['chess'] = this.sanitizer.bypassSecurityTrustHtml(
          data.chess
        );
        this.activity['programming'] = this.sanitizer.bypassSecurityTrustHtml(
          data.programming
        );
        this.activity['maths'] = this.sanitizer.bypassSecurityTrustHtml(
          data.maths
        );
        this.activity['science'] = this.sanitizer.bypassSecurityTrustHtml(
          data.science
        );
        this.activity['telugu1'] = this.sanitizer.bypassSecurityTrustHtml(
          data.telugu1
        );
        this.activity['yoga'] = this.sanitizer.bypassSecurityTrustHtml(
          data.yoga
        );
      });
  }

  initializeShowFullDescription() {
    // this.showFullGoalDescription = this.goalsAndFeedbackResponse.map(
    //   () => false
    // );
    // this.showFullFeedbackDescription = this.goalsAndFeedbackResponse.map(
    //   () => false
    // );
  }

  truncateText(text: string, characters: number): string {
    if (text.length <= characters) {
      return text;
    }
    const truncatedText = text.slice(0, characters);
    return truncatedText + '...';
  }

  toggleGoalDescription() {
    this.showFullGoalDescription = !this.showFullGoalDescription;
  }

  toggleFeedbackDescription() {
    this.showFullFeedbackDescription = !this.showFullFeedbackDescription;
  }

  getDescriptionContent(
    description: string,
    index: number,
    type: string
  ): string {
    if (!description) {
      return '';
    }
    if (type === 'goal') {
      return this.showFullGoalDescription[index]
        ? description
        : this.truncateText(description, 100);
    } else if (type === 'feedback') {
      return this.showFullFeedbackDescription[index]
        ? description
        : this.truncateText(description, 100);
    }
    return '';
  }

  navigateToAccomplishment() {
    this.router.navigate(['/parent/accomplishment/', this.currentChildId]);
  }

  navigateToProgress() {
    this.router.navigate(['/parent/learningProgress/', this.currentChildId]);
  }

  navigateToChild360() {
    this.prevContainer();
    this.router.navigate(['/parent/parent']);
  }

  isLeftSide(index: number): boolean {
    return index % 2 === 0;
  }

  initializeShowAllTeachers() {
    this.showAllTeachers = this.goalsAndFeedbackResponse.map(() => false);
  }

  toggleAllTeachers(index: number) {
    this.showAllTeachers[index] = !this.showAllTeachers[index];
  }

  goalsAndFeedback() {
    const id = this.currentChildId;
    this.child360Service.getGolasAndFeedback(id).subscribe((response) => {
      console.log(response);

      this.goalsAndFeedbackResponse = response;
    });
  }

  goalsAndFeedbackByAgeWise() {
    const activity = localStorage.getItem(
      'particularAgeWiseDataCurrentActivity'
    );
    const age = localStorage.getItem('particularAgeWiseData');
    this.child360Service
      .getGolasAndFeedbackByAgeWise(this.currentChildId, activity, age)
      .subscribe({
        next: (response) => {
          console.log(response);
          this.goalsAndFeedbackResponse = response;
        },
        error: (error) => {
          console.error('Error:', error);
        },
        complete: () => {
          console.log('Request completed');
        },
      });
  }

  prevContainer() {
    const previousNavItem = localStorage.getItem('previousNavItem');
    this.parentService.setCurrentNavItem(previousNavItem);
    this.updateUrl();
  }

  updateUrl(): void {
    this.router.navigate(['/parent/parent'], {
      queryParams: { navItem: this.currentNavItem },
    });
  }

  ngOnDestroy() {
    localStorage.removeItem('particularAgeWiseData');
    localStorage.removeItem('particularAgeWiseDataCurrentActivity');
  }
}
