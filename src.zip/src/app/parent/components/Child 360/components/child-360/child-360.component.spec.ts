import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Child360Component } from './child-360.component';

describe('Child360Component', () => {
  let component: Child360Component;
  let fixture: ComponentFixture<Child360Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Child360Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Child360Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
