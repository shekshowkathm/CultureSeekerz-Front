import { HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { ActivatedRoute, Router } from '@angular/router';
import { ParentService } from '../../../../service/parent.service';
import { NgIf } from '@angular/common';
@Component({
  selector: 'app-child-360',
  standalone: true,
  imports: [MatIconModule, HttpClientModule, NgIf],
  templateUrl: './child-360.component.html',
  styleUrl: './child-360.component.scss',
  providers: [HttpClientModule],
})
export class Child360Component {
  studentInfo: any;
  currentChildIndex: number = 0;
  currentChildId: number;

  constructor(
    private router: Router,
    private parentService: ParentService,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.getStudentData();
  }

  goToAccomplishments() {
    if (this.currentChildId !== null) {
      localStorage.setItem('previousNavItem', 'Child 360');
      localStorage.setItem('currentItem', 'Child 360');
      this.router.navigate(['/parent/accomplishment', this.currentChildId]);
    } else {
      console.error('No child selcted');
    }
  }
  goToCalendar() {
    if (this.currentChildId !== null) {
      localStorage.setItem('previousNavItem', 'Child 360');
      localStorage.setItem('currentItem', 'Child 360');
      this.router.navigate(['/calendarscheduler'], { queryParams: { childId: this.currentChildId } });
    } else {
      console.error('No child selcted');
    }
  }

  navigateToGoals() {
    if (this.currentChildId !== null) {
      localStorage.setItem('previousNavItem', 'Child 360');
      localStorage.setItem('currentItem', 'Child 360');
      this.router.navigate(['/parent/goals_and_feedback', this.currentChildId]);
    } else {
      console.error('No child selcted');
    }
  }

  navigateToLearningProgress() {
    if (this.currentChildId !== null) {
      localStorage.setItem('previousNavItem', 'Child 360');
      localStorage.setItem('currentItem', 'Child 360');
      this.router.navigate(['/parent/learningProgress', this.currentChildId]);
    } else {
      console.error('No child selected');
    }
  }

  getStudentData() {
    const id = localStorage.getItem('id');
    this.parentService.getData(id).subscribe((response) => {
      this.studentInfo = response;
      console.log('Student Info details', this.studentInfo);

      if (this.studentInfo.child.length > 0) {
        this.currentChildId = this.studentInfo.child[this.currentChildIndex].id;
        console.log('Initial and Current Child ID:', this.currentChildId);
      }
    });
  }

imageUrl1: string = 'https://media3.giphy.com/media/IEQAd3dboUuu4XKrbn/giphy.gif?cid=6c09b9529ek1gdissvkry5ktqc53sk93x4mw7nsk73qbv5ln&ep=v1_internal_gif_by_id&rid=giphy.gif&ct=g';
imageUrl2: string = 'https://media3.giphy.com/media/IEQAd3dboUuu4XKrbn/giphy.gif?cid=6c09b9529ek1gdissvkry5ktqc53sk93x4mw7nsk73qbv5ln&ep=v1_internal_gif_by_id&rid=giphy.gif&ct=g';
currentImageUrl: string = this.imageUrl1; 
  toggleChild() {
    if (this.studentInfo.child.length > 1) {
      this.currentChildIndex =
        (this.currentChildIndex + 1) % this.studentInfo.child.length;
      this.currentChildId = this.studentInfo.child[this.currentChildIndex].id;
      console.log('Current Child ID:', this.currentChildId);
    }
    this.currentImageUrl = this.currentImageUrl === this.imageUrl1 ? this.imageUrl2 : this.imageUrl1;
  }
}
