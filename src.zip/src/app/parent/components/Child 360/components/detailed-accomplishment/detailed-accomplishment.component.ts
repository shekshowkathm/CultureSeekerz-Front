import { Component } from '@angular/core';
import { HeaderComponent } from '../../../../../login-register/header/header.component';
import { NgFor, NgIf } from '@angular/common';
import { Child360Service } from '../../../../service/child360.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ParentService } from '../../../../service/parent.service';
@Component({
  selector: 'app-detailed-accomplishment',
  standalone: true,
  templateUrl: './detailed-accomplishment.component.html',
  styleUrl: './detailed-accomplishment.component.scss',
  imports: [HeaderComponent, NgFor, NgIf],
})
export class DetailedAccomplishmentComponent {
  currentChildId: number;
  accomplishmentResponse: any[] = [];
  activityResponse: any[] = [];
  selectedActivity: string;
  specificActivity: any[] = [];

  currentNavItem: string;

  constructor(
    private child360Service: Child360Service,
    private route: ActivatedRoute,
    private router: Router,
    private parentService: ParentService
  ) {}

  ngOnInit() {
    this.route.paramMap.subscribe((params) => {
      this.currentChildId = +params.get('id');
      this.selectedActivity = params.get('activity');
      if (this.selectedActivity && this.currentChildId) {
        this.getActivityInAccomplishment(
          this.selectedActivity,
          this.currentChildId
        );
      }
    });
    this.getSpecificActivity();
  }

  getActivityInAccomplishment(activity: string, id: number) {
    console.log('Calling API with Activity:', activity, 'and ID:', id);
    this.child360Service.getActivityInAccomplishments(id, activity).subscribe(
      (response) => {
        this.activityResponse = response;
        console.log(this.activityResponse);
        if (localStorage.getItem('particularAgeWiseData')) {
          // console.log(localStorage.getItem('particularAgeWiseData'));
          const ageToFilter = parseInt(
            localStorage.getItem('particularAgeWiseData') || '0',
            10
          );
          this.activityResponse = response.filter(
            (activity) => activity.age === ageToFilter
          );
          // console.log(this.activityResponse);
        }
      },
      (error) => {
        console.error('API error:', error);
      }
    );
  }

  getSpecificActivity() {
    const id = this.currentChildId;
    this.child360Service.getAccomplishment(id).subscribe(
      (response) => {
        console.log(response);

        const specificActivity = response.filter(
          (activity) => activity.activity === this.selectedActivity
        );
        console.log(specificActivity);

        if (specificActivity.length > 0) {
          this.specificActivity = specificActivity;
        } else {
          console.error('Selected activity not found in response');
        }
      },
      (error) => {
        console.error('Error fetching accomplishment data:', error);
      }
    );
  }

  getImageUrl(activity: string): string {
    const imageUrls = {
      Tamil:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/tamil.svg',
      Telugu:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Telugu.png',
      Bible:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Bible.png',
      Carnatic:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Carnatic.png',
      Shloka:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Shloka.png',
      Chess:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Chess.png',
      Programming:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Programming.png',
      Maths:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Maths.png',
      Science:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Science.png',
      Yoga: 'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Yoga.png',
      Mridangam:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Miruthangam.svg',
      Hindi:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Hindi.svg',
    };

    return imageUrls[activity] || 'default-image-url'; // Provide a default image URL if the activity doesn't match
  }

  updateUrl(): void {
    // Navigate to the same route with currentNavItem as a parameter
    this.router.navigate(['/parent/parent'], {
      queryParams: { navItem: this.currentNavItem },
    });
  }

  navigateToChild360() {
    this.prevContainer();
    this.router.navigate(['/parent/parent']);
  }

  prevContainer() {
    const previousNavItem = localStorage.getItem('previousNavItem');
    this.parentService.setCurrentNavItem(previousNavItem);
    this.updateUrl();
  }

  ngOnDestroy() {
    localStorage.removeItem('particularAgeWiseData');
  }
}
