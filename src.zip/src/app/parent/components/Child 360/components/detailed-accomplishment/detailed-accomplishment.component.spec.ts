import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailedAccomplishmentComponent } from './detailed-accomplishment.component';

describe('DetailedAccomplishmentComponent', () => {
  let component: DetailedAccomplishmentComponent;
  let fixture: ComponentFixture<DetailedAccomplishmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DetailedAccomplishmentComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DetailedAccomplishmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
