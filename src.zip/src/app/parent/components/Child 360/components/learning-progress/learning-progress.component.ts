import { Component, ElementRef, ViewChildren, QueryList } from '@angular/core';
import { HeaderComponent } from '../../../../../login-register/header/header.component';
import { NgFor, NgIf } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { ViewportScroller } from '@angular/common';
import { Child360Service } from '../../../../service/child360.service';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';
import { ParentService } from '../../../../service/parent.service';

@Component({
  selector: 'app-learning-progress',
  standalone: true,
  imports: [HeaderComponent, NgFor, NgIf],
  templateUrl: './learning-progress.component.html',
  styleUrl: './learning-progress.component.scss',
})
export class LearningProgressComponent {
  activeButton: string = 'age';
  selectedActivityIndexes: number[] = [];
  getAgeLearningProg: any[] = [];
  currentChildId: number;
  expandedStates: boolean[] = [];
  allActivity: any[] = [];
  learningProgressByActivity: any[] = [];
  selectedActivity: string;
  activityyy: { [key: string]: SafeHtml } = {};
  currentNavItem: string;

  @ViewChildren('routing') descriptions: QueryList<ElementRef<HTMLDivElement>>;

  constructor(
    private router: Router,
    private scroller: ViewportScroller,
    private child360Service: Child360Service,
    private route: ActivatedRoute,
    private sanitizer: DomSanitizer,
    private http: HttpClient,
    private parentService: ParentService
  ) {
    this.selectedActivityIndexes = new Array(
      this.child360Service.getAgeLearningProgress.length
    ).fill(0);
    this.learningProgressByActivity.forEach(() =>
      this.expandedStates.push(false)
    );
    this.loadActivitySvgData();
  }

  ngOnInit() {
    this.learningProgressByActivity.forEach((ageDetail, index) => {
      this.selectedActivityIndexes[index] = 0;
    });
    this.getAgeLearningProgress();
    this.route.paramMap.subscribe((params) => {
      this.currentChildId = +params.get('id');
      console.log(
        'Current Child ID in Learning Progress:',
        this.currentChildId
      );
    });
    this.getAllActivity();
  }

  toggleActive(buttonType: string) {
    this.activeButton = buttonType;
  }

  selectActivity(ageIndex: number, activityIndex: number) {
    this.selectedActivityIndexes[ageIndex] = activityIndex;
    const descriptionElement =
      this.descriptions.toArray()[ageIndex].nativeElement;
    descriptionElement.scrollIntoView({ behavior: 'smooth' });
    this.getClassInfo(this.selectedActivityIndexes);
  }

  getAgeLearningProgress() {
    this.route.paramMap.subscribe((params) => {
      const id = +params.get('id');
      this.child360Service.getAgeLearningProgress(id).subscribe((response) => {
        this.getAgeLearningProg = response;
        console.log(
          'Data came get leaning age progress',
          this.getAgeLearningProg
        );
        this.selectedActivityIndexes = new Array(
          this.getAgeLearningProg.length
        ).fill(0);
        this.getClassInfo(this.selectedActivityIndexes);
      });
    });
  }

  getClassInfo(selectedActivityIndexes: number[]): any {
    if (selectedActivityIndexes.length === 0) {
      return null;
    }

    const index = selectedActivityIndexes[0];

    if (
      index >= 0 &&
      index < this.getAgeLearningProg[0].learningProgressByAge.length
    ) {
      // console.log(
      //   this.getAgeLearningProg[0].learningProgressByAge[index].classes
      // );

      return this.getAgeLearningProg[0].learningProgressByAge[index].classes;
    }

    return null;
  }

  navigateToAccomplishment(details: any) {
    console.log(details);
    // console.log(this.selectedActivityIndexes[0]);
    const currentActivity =
      details.learningProgressByAge[this.selectedActivityIndexes[0]].activity;

    localStorage.setItem('particularAgeWiseData', details.age);
    this.router.navigate([
      '/parent/accomplishment-details',
      this.currentChildId,
      currentActivity,
    ]);
    this.scroller.scrollToPosition([0, 0]);
  }

  navigateToGoal(details: any) {
    const currentActivity =
      details.learningProgressByAge[this.selectedActivityIndexes[0]].activity;
    localStorage.setItem('particularAgeWiseData', details.age);
    localStorage.setItem(
      'particularAgeWiseDataCurrentActivity',
      currentActivity
    );
    this.router.navigate(['/parent/goals_and_feedback', this.currentChildId]),
      this.scroller.scrollToPosition([0, 0]);
  }

  navigateToChild360() {
    this.prevContainer();
    this.router.navigate(['/parent/parent']);
  }

  toggleMonths(index: number) {
    this.expandedStates[index] = !this.expandedStates[index];
  }

  getAllActivity() {
    this.route.paramMap.subscribe((params) => {
      const id = +params.get('id');
      this.child360Service.getAllActivity(id).subscribe((response) => {
        this.allActivity = response;

        if (this.allActivity.length > 0) {
          this.selectActivityprogress(this.allActivity[0]);
        }
      });
    });
  }

  selectActivityprogress(activity: any) {
    this.selectedActivity = activity;
    this.getLearningProgressByActivity();
  }

  getSelectedActivity(activity: any) {
    this.selectActivityprogress(activity);
  }

  getLearningProgressByActivity() {
    this.route.paramMap.subscribe((params) => {
      const id = +params.get('id');
      this.child360Service
        .getLearningProgressByActivity(id, this.selectedActivity)
        .subscribe((response) => {
          this.learningProgressByActivity = response;
        });
    });
  }

  loadActivitySvgData() {
    this.http
      .get('assets/JsonFile/activityIcon.json')
      .subscribe((data: any) => {
        this.activityyy['bible'] = this.sanitizer.bypassSecurityTrustHtml(
          data.bible
        );
        this.activityyy['carnatic'] = this.sanitizer.bypassSecurityTrustHtml(
          data.carnatic
        );
        this.activityyy['sloga'] = this.sanitizer.bypassSecurityTrustHtml(
          data.sloga
        );
        this.activityyy['chess'] = this.sanitizer.bypassSecurityTrustHtml(
          data.chess
        );
        this.activityyy['programming'] = this.sanitizer.bypassSecurityTrustHtml(
          data.programming
        );
        this.activityyy['maths'] = this.sanitizer.bypassSecurityTrustHtml(
          data.maths
        );
        this.activityyy['science'] = this.sanitizer.bypassSecurityTrustHtml(
          data.science
        );
        this.activityyy['telugu1'] = this.sanitizer.bypassSecurityTrustHtml(
          data.telugu1
        );
        this.activityyy['yoga'] = this.sanitizer.bypassSecurityTrustHtml(
          data.yoga
        );
      });
  }

  getActivityContent(activity: any): any {
    if (activity.activityType === 'Telugu') {
      return this.activityyy['telugu1'];
    } else if (activity.activityType === 'Bible') {
      return this.activityyy['bible'];
    } else {
      return activity.bible;
    }
  }

  prevContainer() {
    const previousNavItem = localStorage.getItem('previousNavItem');
    this.parentService.setCurrentNavItem(previousNavItem);
    this.updateUrl();
  }

  updateUrl(): void {
    this.router.navigate(['/parent/parent'], {
      queryParams: { navItem: this.currentNavItem },
    });
  }

  getImageUrl(activity: string): string {
    const imageUrls = {
      Tamil:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/tamil.svg',
      Telugu:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Telugu.png',
      Bible:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Bible.png',
      Carnatic:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Carnatic.png',
      Shloka:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Shloka.png',
      Chess:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Chess.png',
      Programming:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Programming.png',
      Maths:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Maths.png',
      Science:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Science.png',
      Yoga: 'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Yoga.png',
      Mridangam:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Miruthangam.svg',
      Hindi:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Hindi.svg',
    };

    return imageUrls[activity] || 'default-image-url'; // Provide a default image URL if the activity doesn't match
  }
}
