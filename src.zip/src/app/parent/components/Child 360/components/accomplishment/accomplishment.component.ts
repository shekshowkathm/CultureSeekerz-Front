import { Component } from '@angular/core';
import { HeaderComponent } from '../../../../../login-register/header/header.component';
import { ActivatedRoute, Router } from '@angular/router';
import { Child360Service } from '../../../../service/child360.service';
import { NgFor, NgIf } from '@angular/common';
import { ParentService } from '../../../../service/parent.service';

@Component({
  selector: 'app-accomplishment',
  standalone: true,
  templateUrl: './accomplishment.component.html',
  styleUrl: './accomplishment.component.scss',
  imports: [HeaderComponent, NgFor, NgIf],
})
export class AccomplishmentComponent {
  currentChildId: number;
  accomplishResponse: any[] = [];
  selectedActivity: string;
  currentNavItem: string;

  constructor(
    private router: Router,
    private child360Service: Child360Service,
    private activatedRoute: ActivatedRoute,
    private parentService: ParentService
  ) {}
  ngOnInit() {
    this.activatedRoute.paramMap.subscribe((params) => {
      this.currentChildId = +params.get('id');
    });
    this.getActivityForAccomplishment();
  }

  getActivityForAccomplishment() {
    const id = this.currentChildId;
    this.child360Service.getAccomplishment(id).subscribe((response) => {
      this.accomplishResponse = response;
    });
  }

  selectAnyActivity(activity: string) {
    this.selectedActivity = activity;
    this.router.navigate([
      'parent/accomplishment-details',
      this.currentChildId,
      this.selectedActivity,
    ]);
  }

  getImageUrl(activity: string): string {
    const imageUrls = {
      Tamil:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/tamil.svg',
      Telugu:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Telugu.png',
      Bible:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Bible.png',
      Carnatic:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Carnatic.png',
      Shloka:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Shloka.png',
      Chess:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Chess.png',
      Programming:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Programming.png',
      Maths:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Maths.png',
      Science:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Science.png',
      Yoga: 'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Yoga.png',
      Mridangam:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Miruthangam.svg',
      Hindi:
        'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/Hindi.svg',
    };

    return imageUrls[activity] || 'default-image-url'; // Provide a default image URL if the activity doesn't match
  }

  updateUrl(): void {
    // Navigate to the same route with currentNavItem as a parameter
    this.router.navigate(['/parent/parent'], {
      queryParams: { navItem: this.currentNavItem },
    });
  }

  navigateToChild360() {
    this.prevContainer();
    this.router.navigate(['/parent/parent']);
  }

  prevContainer() {
    const previousNavItem = localStorage.getItem('previousNavItem');
    this.parentService.setCurrentNavItem(previousNavItem);
    this.updateUrl();
  }
}
