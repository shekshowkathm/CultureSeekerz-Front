import {
  NgClass,
  NgFor,
  NgIf,
  NgStyle,
  NgSwitch,
  NgSwitchCase,
} from '@angular/common';
import { ChangeDetectorRef, Component, HostListener } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ParentService } from '../../service/parent.service';
import { ClassWithTeacherComponent } from '../../../user/class-with-teacher/class-with-teacher.component';
import { ActivityWithTeacherComponent } from '../../../user/activity-with-teacher/activity-with-teacher.component';
import { ProfileComponent } from '../profile/profile.component';
import { HomeComponent } from '../home/home.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ManageclassComponent } from '../manageclass/manageclass.component';
import Swal from 'sweetalert2';
import { ActivatedRoute, Router } from '@angular/router';
import { ActivityComponent } from '../../../user/activity/activity.component';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { TeacherProfileCardComponent } from '../../../user/teacher-profile-card/teacher-profile-card.component';
import { CookieService } from 'ngx-cookie-service';
import { Child360Component } from '../Child 360/components/child-360/child-360.component';

@Component({
  selector: 'app-parent-container',
  standalone: true,
  templateUrl: './parent-container.component.html',
  styleUrl: './parent-container.component.scss',
  imports: [
    ReactiveFormsModule,
    FormsModule,
    MatIconModule,
    NgIf,
    NgFor,
    MatTooltipModule,
    NgStyle,
    NgClass,
    NgSwitch,
    NgSwitchCase,
    ClassWithTeacherComponent,
    ActivityWithTeacherComponent,
    ProfileComponent,
    HomeComponent,
    ManageclassComponent,
    ActivityComponent,
    TeacherProfileCardComponent,
    Child360Component,
    HttpClientModule,
  ],
})
export class ParentContainerComponent {
  showCloseIcon: boolean = true;

  sideNavStatus: boolean = true;
  currentNavItem: string;
  isDesktopView: boolean = true;
  svgData: { [key: string]: SafeHtml } = {};

  navigationArrays = [
    {
      icon: 'home',
      items: 'Home',
    },
    {
      icon: 'account_circle',
      items: 'Profile',
    },
    // {
    //   icon: 'notifications',
    //   items: 'Notifications',
    // },
    // {
    //   icon: 'calendar_today',
    //   items: 'Calendar',
    // },
    {
      icon: 'widgets',
      items: 'Manage class',
    },
    {
      icon: 'supervisor_account',
      items: 'Parent class',
    },
    // {
    //   icon: 'widgets',
    //   items: 'Child requests',
    // },
    {
      icon: '360',
      items: 'Child 360',
    },
    // {
    //   icon: 'payment',
    //   items: 'Payments',
    // },
    // {
    //   icon: 'ballot',
    //   items: 'Current class',
    // },
    // {
    //   icon: 'people',
    //   items: 'Community',
    // },
    {
      icon: 'exit_to_app',
      items: 'Logout',
    },
  ];

  constructor(
    private parentService: ParentService,
    private router: Router,
    private sanitizer: DomSanitizer,
    private http: HttpClient,
    private cookieService: CookieService,
    private cdr: ChangeDetectorRef,
    private route: ActivatedRoute
  ) {
    this.loadSvgData();
  }

  changeNavItem(item: string) {
    if (item === 'Logout') {
      this.confirmLogout();
    } else {
      this.parentService.setCurrentNavItem(item);
      this.updateUrl();
    }
  }

  confirmLogout(): void {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You will be logged out!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, logout',
      cancelButtonText: 'No, cancel',
    }).then((result) => {
      if (result.isConfirmed) {
        this.logout();
      }
    });
  }

  logout(): void {
    this.cookieService.deleteAll();
    setTimeout(() => {
      localStorage.clear();
      sessionStorage.clear();
      document.cookie = '';
      this.cookieService.delete('route');
      this.cookieService.delete('params');
      this.parentService.setCurrentNavItem('Home');
      this.router.navigate(['/login']);
    }, 250);
    // this.authService.logout();
  }

  @HostListener('window:resize', ['$event'])
  onResize(event: any) {
    this.checkWidth();
  }

  ngOnInit() {
    this.parentService.currentNavItem.subscribe((navItem) => {
      this.cdr.detectChanges();
      this.currentNavItem = navItem;
    });
    this.checkWidth();
    const currentnavItem = localStorage.getItem('currentItem');

    this.parentService.setCurrentNavItem(currentnavItem);
    this.updateUrl();
  }

  updateUrl(): void {
    // Navigate to the same route with currentNavItem as a parameter
    this.router.navigate(['/parent/parent'], {
      queryParams: { navItem: this.currentNavItem },
    });
  }

  ngAfterViewInit(): void {
    // console.log('url change aagi irukka ? as view init method');
    // localStorage.setItem('currentItem', 'Home');
  }

  @HostListener('window:popstate', ['$event'])
  onPopState(event) {
    console.log('is url changed da ?');
    this.route.queryParams.subscribe((params) => {
      const navItem = params['navItem'];
      if (navItem) {
        this.parentService.setCurrentNavItem(navItem);
      }
    });
  }

  checkWidth() {
    const screenWidth = window.innerWidth;
    if (screenWidth < 769) {
      // Adjust this value as per your mobile view breakpoint
      this.mobileViewMethod();
    } else if (screenWidth >= 769 && screenWidth <= 1024) {
      // Adjust the range for tablet view as per your requirement
      this.mobileViewMethod();
    } else if (screenWidth >= 1024) {
      // Adjust the range for tablet view as per your requirement
      this.desktopViewMethod();
    } else {
      this.desktopViewMethod();
    }
  }

  mobileViewMethod() {
    // Method to trigger when viewport width is in mobile view
    this.sideNavStatus = false;
    this.isDesktopView = false;
  }

  desktopViewMethod() {
    // Method to trigger when viewport width is greater than mobile view
    this.sideNavStatus = true;
    this.isDesktopView = true;
  }

  closeSideNav() {
    this.showCloseIcon = false;
    this.changeWidth();
  }
  openSideNav() {
    this.showCloseIcon = true;
    this.changeWidth();
  }

  changeWidth() {
    this.sideNavStatus = !this.sideNavStatus;
  }

  loadSvgData() {
    this.http.get('assets/JsonFile/svgIcon.json').subscribe((data: any) => {
      this.svgData['customIcon1'] = this.sanitizer.bypassSecurityTrustHtml(
        data.customIcon1
      );
      this.svgData['customIcon2'] = this.sanitizer.bypassSecurityTrustHtml(
        data.customIcon2
      );
      this.svgData['customIcon3'] = this.sanitizer.bypassSecurityTrustHtml(
        data.customIcon3
      );
      this.svgData['customIcon4'] = this.sanitizer.bypassSecurityTrustHtml(
        data.customIcon4
      );
      this.svgData['customIcon5'] = this.sanitizer.bypassSecurityTrustHtml(
        data.customIcon5
      );
      this.svgData['customIcon6'] = this.sanitizer.bypassSecurityTrustHtml(
        data.customIcon6
      );
      this.svgData['customIcon7'] = this.sanitizer.bypassSecurityTrustHtml(
        data.customIcon7
      );
      this.svgData['customIcon8'] = this.sanitizer.bypassSecurityTrustHtml(
        data.customIcon8
      );
    });
  }

  prevContainer() {
    const previousNavItem = localStorage.getItem('previousNavItem');
    this.parentService.setCurrentNavItem(previousNavItem);
    this.updateUrl();
  }
}
