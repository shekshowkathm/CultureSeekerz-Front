import {
  ChangeDetectorRef,
  Component,
  ViewEncapsulation,
  Inject,
} from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { NgIf } from '@angular/common';
import { StudentRegister } from '../../../login-register/student-register';
import { ActivatedRoute, Router } from '@angular/router';
import { RegistrationService } from '../../../login-register/service/registration.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatOptionModule } from '@angular/material/core';

import { Seekerz } from '../../model/seekerz.class';
import { ParentService } from '../../service/parent.service';


@Component({
  selector: 'app-add-kids',
  standalone: true,
  imports: [
    MatIconModule,
    FormsModule,
    ReactiveFormsModule,
    NgIf,
    HttpClientModule,
    MatInputModule,
    MatSelectModule,
    MatOptionModule,
    
  ],
  providers: [HttpClient, RegistrationService, ParentService],
  templateUrl: './add-kids.component.html',
  styleUrl: './add-kids.component.scss',
})
export class AddKidsComponent {
  studentForm: FormGroup | undefined | any;
  student: StudentRegister = new StudentRegister();
  showOtpSection: boolean = true;
  showSuccessRej: boolean = true;
  showParentForm: boolean = false;
  keyFromQueryParams: string = '';
  otpForm: FormGroup | undefined | any;
  generalInfoResponse: any;
  otpValue: string = '';
  errorMessage: string | null = null;
  errorEmailMessage: string | null = null;
  role: string = '';
  otpMessage: boolean = false;
  public parentDetails: Seekerz = {
    id: 0,
    firstName: '',
    middleName: '',
    lastName: '',
    email: '',
    password: '',
    child: [],
    role: '',
    otp: '',
    status: false,
    streetAddress: '',
    city: '',
    stateProvince: '',
    postalCode: '',
    dob: '',
    mobileNumber: '',
    gender: '',
    age: '',
    timeZone: '',
  };

  constructor(
    private dialogRef: MatDialogRef<AddKidsComponent>,
    private Formbuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private registerService: RegistrationService,
    private parentService: ParentService,
    private cdr: ChangeDetectorRef,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    console.log(data);

    this.parentDetails.id = data.id;
    this.parentDetails.firstName = data.firstName;
    this.parentDetails.middleName = data.middleName;
    this.parentDetails.lastName = data.lastName;
    this.parentDetails.email = data.email;
    this.parentDetails.password = data.password;
    this.parentDetails.child = data.child;
    this.parentDetails.role = data.role;
    this.parentDetails.otp = data.otp;
    this.parentDetails.status = data.status;
    this.parentDetails.streetAddress = data.streetAddress;
    this.parentDetails.city = data.city;
    this.parentDetails.stateProvince = data.stateProvince;
    this.parentDetails.postalCode = data.postalCode;
    this.parentDetails.dob = data.dob;
    this.parentDetails.mobileNumber = data.mobileNumber;
    this.parentDetails.gender = data.gender;
    this.parentDetails.age = data.age;
    this.parentDetails.timeZone = data.timeZone;
    this.parentDetails;
  }

  ngOnInit(): void {
    this.otpForm = this.Formbuilder.group({
      // otp: ['', Validators.required],
    });
    this.FormValidation();
  }

  closeAddKids() {
    this.dialogRef.close();
  }

  FormValidation(): void {
    this.studentForm = this.Formbuilder.group({
      firstName: [this.student.firstName, Validators.required],
      middleName: [''],
      lastName: [this.student.lastName, Validators.required],
      email: [this.student.email, Validators.required],
      mobileNumber: [
        this.student.mobileNumber,
        [Validators.pattern('^[0-9]{10}$')],
      ],
      // age: [
      //   this.student.age,
      //   [Validators.min(1), Validators.max(999), this.maxLengthValidator(3)],
      // ],
      dob: [this.student.dob,[Validators.required]],
      gender: [this.student.gender, [Validators.required]],
      password: ['', [Validators.required, Validators.minLength(8)]],
      conformPassword: ['', Validators.required],
    });
    this.studentForm.setValidators(this.passwordMatchValidator.bind(this));
  }

  restrictToNumbers() {
    const mobileNoControl = this.studentForm.get('mobileNo');
    if (mobileNoControl) {
      const numericValue = mobileNoControl.value.replace(/[^0-9]/g, '');
      const isValid = /^\d{10}$/.test(numericValue);
      mobileNoControl.setValue(numericValue);
      mobileNoControl.setErrors(isValid ? null : { pattern: true });
    }
  }

  passwordMatchValidator(formGroup: FormGroup) {
    const passwordControl = formGroup.get('password');
    const conformPasswordControl = formGroup.get('conformPassword');

    if (passwordControl && conformPasswordControl) {
      const password = passwordControl.value;
      const conformPassword = conformPasswordControl.value;

      if (password !== conformPassword) {
        conformPasswordControl.setErrors({ passwordMismatch: true });
      } else {
        conformPasswordControl.setErrors(null);
      }
    }
  }

  validateMaxLength(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.value.length > 3) {
      input.value = input.value.slice(0, 3);
      this.studentForm.controls['age'].setValue(input.value);
    }
  }

  maxLengthValidator(maxLength: number) {
    return (control) => {
      const value = control.value;
      if (value && value.toString().length > maxLength) {
        return { maxLength: true };
      }
      return null;
    };
  }

  submitGeneralInfo(): void {
    if (this.studentForm.valid) {
      const formData = {
        ...this.studentForm.value,
        role: 'STUDENT',
        password: this.studentForm.get('password').value,
      };

      this.registerService.submitRegisterData(formData).subscribe({
        next: (response) => {
          if (response.response !== 'Email already exist') {
            this.showSuccessRej = false;
            // this.showOtpSection = true;
            this.studentForm.reset();
            const newChild = { id: response.id };
            this.parentDetails.child.push(newChild);

            this.updateParentDetails(this.parentDetails);
            this.generalInfoResponse = response;
          } else {
            this.errorEmailMessage =
              'Email already exists. Please use a different email.';
          }
        },
        error: (error) => {
          console.error('POST request failed:', error);
        },
      });
    } else {
      this.markFormGroupTouched(this.studentForm);
    }
  }

  successRej() {
    this.showSuccessRej = false;
    this.dialogRef.close();
    // this.showOtpSection = false;
  }

  updateParentDetails(parentDetails: any): void {
    this.parentService.addKidsToParent(parentDetails).subscribe({
      next: (response) => {},
      error: (error) => {},
    });
  }

  markFormGroupTouched(formGroup: FormGroup): void {
    Object.values(formGroup.controls).forEach((control) => {
      control.markAsTouched();
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }

  isInvalid(controlName: string): boolean {
    const control = this.studentForm.get(controlName);
    return control ? control.invalid && control.touched : false;
  }
  isInvalidOtp(): boolean {
    const control = this.otpForm.get('otp');
    return control ? control.invalid && control.touched : false;
  }
}
