import { Component, ElementRef, Input, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { ParentService } from '../../service/parent.service';
import { SharedService } from '../../../user/service/shared.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import {
  NgClass,
  NgFor,
  NgIf,
  NgStyle,
  NgSwitch,
  NgSwitchCase,
} from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { AddKidsComponent } from '../add-kids/add-kids.component';
import { AddKidRegisterComponent } from '../../../login-register/add-kid-register/add-kid-register.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { ManageclassComponent } from '../manageclass/manageclass.component';
import { RegistrationService } from '../../../login-register/service/registration.service';
import { CalendarSchedulerComponent } from '../../../user/calendar/calendar-scheduler/calendar-scheduler.component';

@Component({
  selector: 'app-profile',
  standalone: true,
  providers: [HttpClient],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.scss',
  imports: [
    MatButtonModule,
    FormsModule,
    ReactiveFormsModule,
    MatSidenavModule,
    MatListModule,
    MatIconModule,
    NgFor,
    NgSwitch,
    NgSwitchCase,
    NgIf,
    NgClass,
    NgStyle,
    MatTooltipModule,
    HttpClientModule,
    ManageclassComponent,
    CalendarSchedulerComponent,
  ],
})
export class ProfileComponent {
  public parentsDetails: any;
  public currentChild: number = 0;
  public nextChild: number = 0;
  public childDetails: any;
  public childDetailsArray: any;

  isActive: boolean = false;
  calendarProfile: boolean;
  liteColors: string[];

  @ViewChild('calendarContainer', { static: false }) set calendarContainerRef(
    calendarContainerRef: ElementRef
  ) {
    if (calendarContainerRef && this.calendarProfile) {
      this.calendarContainer = calendarContainerRef;
      this.scrollToCalendar();
    }
  }
  calendarContainer: ElementRef;
  i: number;

  constructor(
    private parentsService: ParentService,
    private dialog: MatDialog,
    private SharedService: SharedService,
    private registerService: RegistrationService
  ) {}

  ngOnInit() {
    this.registerService.calendarProfile$.subscribe((value) => {
      this.calendarProfile = value;
      console.log(this.calendarProfile);
    });
    this.getData();
  }
  ngAfterViewInit(): void {
    // if (this.calendarProfile) {
    //   console.log('is it scrolled');
    //   console.log(this.calendarContainer);
    //   if (this.calendarContainer) {
    //     this.calendarContainer.nativeElement.scrollIntoView({
    //       behavior: 'smooth',
    //       block: 'start',
    //     });
    //   }
    // }
  }

  scrollToCalendar(): void {
    if (this.calendarContainer) {
      this.calendarContainer.nativeElement.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
      });
    }
  }

  getData() {
    const id = localStorage.getItem('id');
    this.parentsService.getData(id).subscribe({
      next: (response) => {
        console.log(response, '55222222333333333');

        this.parentsDetails = response;
        this.childDetailsArray = this.parentsDetails.child;
        this.childDetails = this.childDetailsArray[this.currentChild];
        // this.addKids();
      },
      error: (error) => {
        console.error('Error:', error);
      },
    });
  }

  changeKids() {
    if (this.currentChild === this.childDetailsArray.length) {
      this.currentChild = 0;
      this.childDetails = this.childDetailsArray[this.currentChild];
    } else {
      this.currentChild = this.currentChild + 1;
      this.childDetails = this.childDetailsArray[this.currentChild];
    }
  }

  addKids() {
    this.dialog.closeAll();
    const dialogRef = this.dialog.open(AddKidsComponent, {
      width: 'auto',
      maxHeight: '90vh',
      data: this.parentsDetails,
    });

    dialogRef.afterClosed().subscribe((result) => {
      this.getData();
    });
  }
  prev() {
    if (this.parentsDetails.currentIndex > 0) {
      this.parentsDetails.currentIndex -= 2;
    }
  }

  next() {
    if (
      this.parentsDetails.currentIndex <
      this.parentsDetails.child.length - 2
    ) {
      this.parentsDetails.currentIndex += 2;
    }
  }
  toggleActive(student): void {
    console.log('ToogleActive');

    this.SharedService.sendData(student.id);
    if (this.parentsDetails && Array.isArray(this.parentsDetails.child)) {
      this.parentsDetails.child.forEach((child) => {
        child.isActive = false;
      });
      student.isActive = true;
    }
  }
  ParentViewCalendarIDPass(parentIdPass): void {
    this.SharedService.sendParentIdForCalendar(parentIdPass.id);
  }

  ngOnDestroy(): void {
    this.registerService.setcalendarProfile(false);
  }
  getColor(student: any): string {
    const index = this.parentsDetails.child.indexOf(student);
    const colors: string[] = [
      '#C2FCFF',
      '#D5E9FF',
      '#F9FBE7',
      '#CDE990',
      'purple',
      'skyblue',
      'cyan',
      'magenta',
      'yellow',
      'brown',
    ];
    return colors[index % colors.length];
  }
}
