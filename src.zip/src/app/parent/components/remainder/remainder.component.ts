import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RegistrationService } from '../../../login-register/service/registration.service';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { SharedService } from '../../../user/service/shared.service';
import { HeaderComponent } from "../../../login-register/header/header.component";
import { NgIf } from '@angular/common';
@Component({
    selector: 'app-remainder',
    standalone: true,
    templateUrl: './remainder.component.html',
    styleUrl: './remainder.component.scss',
    imports: [MatIconModule, MatButtonModule, HeaderComponent , NgIf]
})
export class RemainderComponent implements OnInit {
   
  studentId: number;
  remainder : any

  constructor(private router: Router , private route: ActivatedRoute, private registrationService: RegistrationService , private sharedService : SharedService){

  }

  ngOnInit(){
    this.route.queryParams.subscribe(params => {
      this.studentId = +params['studentId']; 
      this.getStudentIdForReminder(this.studentId);
    });
  }

  getStudentIdForReminder(studentId:number){
    console.log("Student id for reminder", studentId);
    this.registrationService.getReminderTeacherDetails(studentId).subscribe(
      response => {
        this.remainder = response
        console.log("One teacher details in Remainder", this.remainder);
        this.router.navigate(['/parent/remainder'], { queryParams: { studentId: studentId }});
      }
    );
  }

  formatDay(days: string[]) {
    return this.sharedService.getAbbreviatedDays(days);
  }
  }

 

