import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { ParentService } from '../../service/parent.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import {
  NgClass,
  NgFor,
  NgIf,
  NgStyle,
  NgSwitch,
  NgSwitchCase,
} from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { AddKidsComponent } from '../add-kids/add-kids.component';
@Component({
  selector: 'app-home',
  standalone: true,
  imports: [
    MatButtonModule,
    FormsModule,
    ReactiveFormsModule,
    MatSidenavModule,
    MatListModule,
    MatIconModule,
    NgFor,
    NgSwitch,
    NgSwitchCase,
    NgIf,
    NgClass,
    NgStyle,
    MatTooltipModule,
  ],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss',
})
export class HomeComponent {
  parentsDetails: any;

  constructor(
    private parentsService: ParentService,
    private dialog: MatDialog
  ) {}

  ngOnInit() {
    this.getData();
    // this.addKids();
  }

  getData() {
    const id = localStorage.getItem('id');
    this.parentsService.getData(id).subscribe({
     next: (response) => {
        this.parentsDetails = response;
        
      },
     error: (error) => {
        console.error('Error:', error);
      }
  });
  }

  addKids() {
    // Close any open dialogs if needed
    this.dialog.closeAll();

    const dialogRef = this.dialog.open(AddKidsComponent, {
      width: 'auto',
      height:'85vh'
    });

    dialogRef.afterClosed().subscribe((result) => {

    });
  }
}
