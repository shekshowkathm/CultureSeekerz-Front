import { ChangeDetectorRef, Component, HostListener } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import {
  NgClass,
  NgFor,
  NgIf,
  NgStyle,
  NgSwitch,
  NgSwitchCase,
} from '@angular/common';
import { HomeComponent } from '../home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { ProfileComponent } from '../profile/profile.component';
import { HeaderComponent } from '../../../login-register/header/header.component';
import { ParentService } from '../../service/parent.service';
import { ManageclassComponent } from '../manageclass/manageclass.component';
import { ActivityWithTeacherComponent } from '../../../user/activity-with-teacher/activity-with-teacher.component';
import { ClassWithTeacherComponent } from "../../../user/class-with-teacher/class-with-teacher.component";

@Component({
    selector: 'app-navbar',
    standalone: true,
    templateUrl: './navbar.component.html',
    styleUrl: './navbar.component.scss',
    imports: [
        FormsModule,
        ReactiveFormsModule,
        MatSidenavModule,
        MatListModule,
        MatIconModule,
        NgFor,
        NgSwitch,
        NgSwitchCase,
        NgIf,
        NgClass,
        NgStyle,
        MatTooltipModule,
        HomeComponent,
        HttpClientModule,
        ProfileComponent,
        HeaderComponent, ManageclassComponent, ActivityWithTeacherComponent,
        ClassWithTeacherComponent
    ]
})
export class NavbarComponent {
  isSideNavOpened: boolean = true;

  closeSideNav() {
    this.isSideNavOpened = !this.isSideNavOpened;
    
  }

  navigationArrays = [
    {
      icon: 'home',
      items: 'Home',
    },
    {
      icon: 'account_circle',
      items: 'Profile',
    },
    {
      icon: 'notifications',
      items: 'Notifications',
    },
    {
      icon: 'calendar_today',
      items: 'Calendar',
    },
    {
      icon: 'widgets',
      items: 'Manage class',
    },
    {
      icon: '360',
      items: 'Child 360',
    },
    {
      icon: 'payment',
      items: 'Payments',
    },
    {
      icon: 'ballot',
      items: 'Current class',
    },
    {
      icon: 'people',
      items: 'Community',
    },
    {
      icon: 'exit_to_app',
      items: 'Logout',
    },
  ];

  currentNavItem: string = 'Home';

  constructor(private parentService: ParentService) {}

  changeNavItem(item: string) {
    this.parentService.setCurrentNavItem(item);
  }

  onSidenavClose(event: any) {
    // Prevent full closing if it's half-opened
    if (this.isSideNavOpened && event === false) {
      event.preventDefault();
    }
  }

  @HostListener('window:resize', ['$event'])
  onResize(event: any) {
    this.checkWidth();
  }

  ngOnInit() {
    this.parentService.currentNavItem.subscribe((navItem) => {
      this.currentNavItem = navItem;
    });
    this.checkWidth();
  }

  checkWidth() {
    const screenWidth = window.innerWidth;
    if (screenWidth < 769) {
      // Adjust this value as per your mobile view breakpoint
      this.mobileViewMethod();
    } else if (screenWidth >= 769 && screenWidth <= 1024) {
      // Adjust the range for tablet view as per your requirement
      this.mobileViewMethod();
    } else {
      this.desktopViewMethod();
    }
  }

  mobileViewMethod() {
    // Method to trigger when viewport width is in mobile view

    this.isSideNavOpened = false;
  }

  desktopViewMethod() {
    // Method to trigger when viewport width is greater than mobile view

    this.isSideNavOpened = true;
  }
}
