import { ChangeDetectorRef, Component } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { NgClass, NgFor, NgIf } from '@angular/common';
import { ParentService } from '../../service/parent.service';
import { Router, RouterModule } from '@angular/router';
import { ClassWithTeacherComponent } from '../../../user/class-with-teacher/class-with-teacher.component';
import Swal from 'sweetalert2';
import { SharedService } from '../../../user/service/shared.service';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatTabsModule } from '@angular/material/tabs';
import { StudentManageClassComponent } from '../../../user/student-manage-class/student-manage-class.component';
import { ManageClass } from '../../../user/model/manage-class';
import { UserServiceService } from '../../../user/service/user-service.service';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import {
  FormBuilder,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { FeedbackUpdate } from '../../../user/model/trial-class';
import { JsonPipe } from '@angular/common';
@Component({
  selector: 'app-manageclass',
  standalone: true,
  imports: [
    MatIconModule,
    MatButtonModule,
    NgFor,
    NgIf,
    ClassWithTeacherComponent,
    RouterModule,
    MatTooltipModule,
    MatTabsModule,
    StudentManageClassComponent,
    FormsModule,
    ReactiveFormsModule,
    JsonPipe,
    ProgressSpinnerModule,NgClass
  ],
  templateUrl: './manageclass.component.html',
  styleUrl: './manageclass.component.scss',
})
export class ManageclassComponent {
  manageClassParentData: any;
  emptyArrayData: boolean = true;
  childId: number = 0;
  public parentsDetails: any;
  public currentChild: number = 0;
  public childDetails: any;
  public childDetailsArray: any;
  role: string = '';
  username: string = '';
  StudentManageClassComponent: any;
  truePaymentStatusData: ManageClass[] = [];
  falsePaymentStatusData: ManageClass[] = [];
  manageClassResponse: ManageClass[] = [];
  trueEmptyArrayData: boolean = true;
  falseEmptyArrayData: boolean = true;
  isStartDateValid: boolean = false;
  showFullDescription: boolean[] = [];
  trialClassData: any[] = [];
  classData: any[];
  liked: boolean = false;
  disliked: boolean = false;
  likeText: string = 'Like';
  hideFeedback: boolean = false;
  feedbackdetails: any;
  feedbackform: any;
  trialDataObject: FeedbackUpdate;
  trialDataObjects: FeedbackUpdate;
  displayMessage: boolean = false;
  loading: boolean = true;
  parentLoader: boolean = true;

  currentNavItem: string;

  constructor(
    private ParentService: ParentService,
    private sharedService: SharedService,
    private cdr: ChangeDetectorRef,
    private userService: UserServiceService,
    private Formbuilder: FormBuilder,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.ParentService.currentNavItem.subscribe((navItem) => {
      this.cdr.detectChanges();
      this.currentNavItem = navItem;
      console.log(this.currentNavItem);
      if (this.currentNavItem === 'Parent class') {
        this.parent();
      }
    });

    this.getData();
    this.role = localStorage.getItem('role');

    this.feedbackform = this.Formbuilder.group({
      feedback: ['', [Validators.required]],
    });
  }
  parenton: boolean = false;
  manageclass: boolean = false;
  parent() {
    this.trialClassData = [];
    this.manageClassResponse = [];
    this.manageclass = true;
    this.username = localStorage.getItem('username');
    this.getTrialClasses(this.username);
    this.displayMessage = true;
  }
  childOn() {
    this.parentLoader = true;
    this.manageclass = false;
    this.getData();
    this.displayMessage = false;
  }

  jsonGet() {
    return JSON.stringify(this.manageClassParentData);
  }

  getData() {
    const id = localStorage.getItem('id');
    this.ParentService.getData(id).subscribe({
      next: (response) => {
        this.parentsDetails = response;
        this.childDetailsArray = this.parentsDetails.child;
        this.currentChild = 0;
        this.childDetails = this.childDetailsArray[this.currentChild];
        this.changeKids();
      },
      error: (error) => {
        console.error('Error:', error);
      },
    });
  }

  changeKids() {
    this.trialClassData = [];
    this.manageClassResponse = [];
    this.manageClassParentData = [];
    if (this.currentChild < this.childDetailsArray.length - 1) {
      this.currentChild = this.currentChild + 1;
    } else {
      this.currentChild = 0;
    }
    this.childDetails = this.childDetailsArray[this.currentChild];
    console.log( this.childDetails,"mmmmmmmmmmmmmmm");
    
    this.manageClassParentGet(this.childDetails.id);
    this.getOneParticularManageClass(this.childDetails.id);
    this.sharedService.triggerFunction(this.childDetails.id);

    this.getTrialClasses(this.childDetails.email);
  }
  getOneParticularManageClass(id: any) {
    this.parentLoader = true;
    this.userService.getParticularStudent(id).subscribe({
      next: (response) => {
        this.manageClassResponse = response;
        this.parentLoader = false;
        console.log('manageClassResponse:', this.manageClassResponse);
        this.parentLoader = false;
        this.cdr.detectChanges();
      },
      error: (error) => {},
    });
  }

  toggleDescription(index: number, event: Event): void {
    event.preventDefault();
    this.showFullDescription[index] = !this.showFullDescription[index];
    event.stopPropagation();
  }
  // onButtonClick(studentData) {  
  //   window.open(studentData.dayAndTime.meetingLink, '_blank');
  //   const studentId = studentData.studentId;
  //   setTimeout(() => {
  //     this.ParentService.afterMeetingTigger(studentId).subscribe({
  //       next: (response) => {
  //     this.getOneParticularManageClass(this.childDetails.id);
  //       },
  //       error: (error) => {
  //         console.error(error);
  //       },
  //     });
  //   }, 30 * 60 * 1000); 
  // }
  onButtonClick(studentData) {
    window.open(studentData.dayAndTime.meetingLink, '_blank');
    const studentId = studentData.studentId;
    const token = localStorage.getItem('token'); 

    if (navigator.serviceWorker && navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'SET_TIMER',
        studentId: studentId,
        token: token,
        delay: 10 * 1000 
      });
    } else {
      console.error('Service worker not available.');
    }
  }



  formatDay(days: string[]) {
    return this.sharedService.getAbbreviatedDays(days);
  }
  manageClassParentGet(childId) {
    this.parentLoader = true;
    this.ParentService.manageClassParentGet(childId).subscribe({
      next: (response) => {
        this.parentLoader = false;
        this.manageClassParentData = response;
        this.parentLoader = false;
        console.log('manageClassParentData:', this.manageClassParentData);
      },
      error: (error) => {},
    });
  }
  checkRole(studentId, index: number) {
    console.log(index, 'index varuthu');

    if (this.role === 'PARENT') {
      const extractData = this.manageClassParentData[index];
      console.log(extractData, 'super appu');

      const ageGroupOptions = extractData.ageGroup
        .map((age) => `<option value="${age}">${age}</option>`)
        .join('');
      const classTypeOptions = extractData.classType
        .map((type) => `<option value="${type}">${type}</option>`)
        .join('');

      Swal.fire({
        title: 'Would you like to enroll in this class?',
        icon: 'question',
        showCancelButton: true,
        html: `
        <div>
          <label for="ageGroup-select">Age Group:</label> <br>
        <select id="ageGroup-select" class="swal2-input"swal2-input" style="width: 50%; padding: 5px; border-radius: 5px; border: 2px solid #ccc; margin-bottom: 20px;">
          ${ageGroupOptions}
        </select>
        <br/>
        </div>
        <div>
          <label for="classType-select">Class Type:</label> <br>
        <select id="classType-select" class="swal2-input" style="width: 50%; padding: 5px; border-radius: 5px; border: 2px solid #ccc; margin-bottom: 20px;">
          ${classTypeOptions}
        </select>
        </div>
      `,
        confirmButtonText: 'Yes, enroll',
        cancelButtonText: 'No, cancel',
      }).then((result) => {
        if (result.isConfirmed) {
          const selectedAgeGroup: any =
            document.getElementById('ageGroup-select');
          const selectedClassType: any =
            document.getElementById('classType-select');
          const ageGroup = selectedAgeGroup.value;
          const classType = selectedClassType.value;
          this.parentPaymentPost(studentId, ageGroup, classType);
        } else {
        }
      });
      this.getData();
    }
  }
  parentPaymentPost(studentId: any, ageGroup: string, classType: string) {
    this.ParentService.parentPaymentPut(
      studentId,
      ageGroup,
      classType
    ).subscribe({
      next: (response) => {
        Swal.fire({
          title: 'Allset! You will receive confirmation within 1 business day',
          icon: 'info',
          confirmButtonText: 'Ok',
        });
      },
      error: (error) => {},
    });
    this.getData();
  }
  getTrialClasses(studentEmail: string) {
    this.userService.getTrialClass(studentEmail).subscribe({
      next: (response) => {
        this.trialClassData = response;
        this.loading = false;
        this.cdr.detectChanges();
      },

      error: (error) => {},
    });
  }
  formatDays(days: string[]): string {
    return this.sharedService.getAbbreviatedDays(days);
  }
  trialClassLink(link: string) {
    window.location.href = link;
  }

  removeClass(addClasses) {
    Swal.fire({
      title: 'Confirm Class Removal',
      text: 'Are you sure you want to delete this class?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete!',
      cancelButtonText: 'No, cancel',
    }).then((result) => {
      if (result.isConfirmed) {
        this.deleteMethod(addClasses);
      }
    });
  }

  deleteMethod(id) {
    this.userService.deleteItem(id).subscribe({
      next: (response) => {
        this.getData();
        // this.separateDataByPaymentStatus();
        this.cdr.detectChanges();
      },
      error: (error) => {},
    });
  }

  goToTeacherProfileCardByID(teacher) {
    // console.log(teacher);

    localStorage.setItem('teacherprofilecardid', teacher.classId.toString());
    this.ParentService.setCurrentNavItem('teacherprofilecard');
  }

  // like and dislike
  toggleLike(index: number) {
    // Toggle the like state for the item at the specified index
    this.trialClassData[index].liked = !this.trialClassData[index].liked;
  }
  toggleDislike(index: number) {
    // Toggle the like state for the item at the specified index
    this.trialClassData[index].disliked = !this.trialClassData[index].disliked;
  }
  hideFeedbackInput(index: number) {
    this.trialClassData[index].disliked = false;
  }
  handleDislike(index: number) {
    // Check if disliked is true, if yes, set liked to false
    if (this.trialClassData[index].disliked) {
      this.trialClassData[index].liked = false;
    }
  }

  submitDislikeFeedback(index: number, trialData: FeedbackUpdate): void {
    const feedbackvalue = this.feedbackform.get('feedback').value;
    // console.log(feedbackvalue,'ygqygd');
    this.trialDataObject = trialData;
    this.trialDataObject.feedback = feedbackvalue;

    this.userService.updatefeedback(this.trialDataObject).subscribe({
      next: (response) => {
        this.feedbackform.reset();
        console.log(trialData);
        // console.log(response, 'response');
      },
      error: (error) => {
        console.error(error);
      },
    });
  }
  isJoinable(startDate: string, startTime: string): boolean {
    const currentDateTime = new Date();
    const slotDateTime = new Date(startDate + 'T' + startTime);
    return currentDateTime.getTime() >= slotDateTime.getTime();
  }
  isJoinableForParentEnroll(
    startDate: string,
    startTime: string,
    paymentStatus
  ): boolean {
    const currentDateTime = new Date();
    const slotDateTime = new Date(startDate + 'T' + startTime);
    // console.log(currentDateTime.getTime() >= slotDateTime.getTime() && paymentStatus);

    return currentDateTime.getTime() >= slotDateTime.getTime() && paymentStatus;
  }
  addlike(i: number, trialData: FeedbackUpdate): void {
    const addlike = this.feedbackform.get('feedback').setValue('liked');
    this.trialDataObjects = trialData;
    this.trialDataObjects.feedback = addlike;
    this.submitDislikeFeedback(i, this.trialDataObjects);
  }
  openSweetAlert() {
    console.log('111111111111');
    Swal.fire({
      title: 'Reschedule',
      text: 'Do you want to reschedule this event?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, reschedule it!',
      cancelButtonText: 'No, keep it',
    }).then((result) => {
      if (result.isConfirmed) {
        const reschedulestudentId = this.childDetails.personalId;
        this.ParentService.reschedulePut(reschedulestudentId).subscribe({
          next: (response) => {
            console.log(response, 'reschedule triggered');
          },
          error: (error) => {
            console.error(error);
          },
        });
        Swal.fire(
          'Rescheduled!',
          'Your event has been rescheduled.',
          'success'
        );
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire('Cancelled', 'Your event is not rescheduled.', 'error');
      }
    });
  }
}
