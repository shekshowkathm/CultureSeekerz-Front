import { ChangeDetectorRef, Component } from '@angular/core';
import { HeaderComponent } from '../../../login-register/header/header.component';
import { NavbarComponent } from '../navbar/navbar.component';
import { ParentContainerComponent } from '../parent-container/parent-container.component';
import { FooterComponent } from '../../../login-register/components/footer/footer.component';
import { NgIf } from '@angular/common';
import { ParentService } from '../../service/parent.service';

@Component({
  selector: 'app-parent-layout',
  standalone: true,
  imports: [
    HeaderComponent,
    NavbarComponent,
    ParentContainerComponent,
    FooterComponent,
    NgIf,
  ],
  templateUrl: './parent-layout.component.html',
  styleUrl: './parent-layout.component.scss',
})
export class ParentLayoutComponent {
  currentNavItem: string;
  constructor(
    private parentService: ParentService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.parentService.currentNavItem.subscribe((navItem) => {
      this.cdr.detectChanges();
      this.currentNavItem = navItem;
    });
  }
}
