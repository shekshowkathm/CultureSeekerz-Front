export class Seekerz {
  id!: number;
  firstName!: string;
  middleName!: string;
  lastName!: string;
  email!: string;
  password!: string;
  child!: { id: string }[];
  role!: string;
  otp!: string;
  status!: boolean;
  streetAddress!: string;
  city!: string;
  stateProvince!: string;
  postalCode!: string;
  dob!: string;
  mobileNumber!: string;
  gender!: string;
  age!: string;
  timeZone!: string;
}
