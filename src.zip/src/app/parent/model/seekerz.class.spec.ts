import { Seekerz } from './seekerz.class';

describe('Seekerz', () => {
  it('should create an instance', () => {
    expect(new Seekerz()).toBeTruthy();
  });
});
