import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { NavbarComponent } from './components/navbar/navbar.component';
import { PictComponent } from './components/pict/pict.component';
import { ParentLayoutComponent } from './components/parent-layout/parent-layout.component';
import { routeAuthGuard } from '../route-guard/route-auth.guard';
import { RemainderComponent } from './components/remainder/remainder.component';
import { CommonModule } from '@angular/common';
import { AccomplishmentComponent } from './components/Child 360/components/accomplishment/accomplishment.component';
import { LearningProgressComponent } from './components/Child 360/components/learning-progress/learning-progress.component';
import { GoalsFeedbackComponent } from './components/Child 360/components/goals-feedback/goals-feedback.component';
import { DetailedAccomplishmentComponent } from './components/Child 360/components/detailed-accomplishment/detailed-accomplishment.component';
import { Child360Component } from './components/Child 360/components/child-360/child-360.component';

const routes: Routes = [
  { path: 'navbar', component: NavbarComponent },
  { path: 'pict', component: PictComponent },
  {
    path: 'parent',
    component: ParentLayoutComponent,
    data: { allowedRoles: ['PARENT'] },
    canActivate: [routeAuthGuard],
  },
  {
    path: 'accomplishment/:id',
    component: AccomplishmentComponent,
    data: { allowedRoles: ['PARENT'] },
    canActivate: [routeAuthGuard],
  },
  { path: 'child360', component : Child360Component},
  { path: 'remainder', component: RemainderComponent },
  { path: 'goals_and_feedback/:id' , component: GoalsFeedbackComponent},
  { path: 'learningProgress/:id', component: LearningProgressComponent },
  { path: 'accomplishment-details/:id/:activity', component: DetailedAccomplishmentComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ParentRoutingModule {}
