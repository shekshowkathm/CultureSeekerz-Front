import { TestBed } from '@angular/core/testing';

import { Child360Service } from './child360.service';

describe('Child360Service', () => {
  let service: Child360Service;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Child360Service);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
