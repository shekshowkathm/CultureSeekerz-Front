import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment.development';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class Child360Service {
  public ageLearningProgress =
    environment.localdomain + '/student/learningProgressByAge/';
  public activityLearningProgress =
    environment.localdomain + '/student/learningProgressByActivity/';
  public showAllActivity = environment.localdomain + '/student/getActivity/';
  public goalsAndFeedback =
    environment.localdomain + '/student/goalsandfeedback/';
  public goalsAndFeedbackByAge =
    environment.localdomain + '/student/goalsandfeedbackByage/';
  public accomplishment = environment.localdomain + '/student/accomplishment/';
  public activityInAccomplishment =
    environment.localdomain + '/student/accomplishmentByactivity/';
  constructor(private httpClient: HttpClient) {}

  private getRequestOptions(): { headers: HttpHeaders } {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + localStorage.getItem('token'),
    });
    return { headers };
  }

  // This function is for age wise learning progress API
  getAgeLearningProgress(childId: number): Observable<any[]> {
    const requestOptions = this.getRequestOptions();
    const url = `${this.ageLearningProgress}${childId}`;
    return this.httpClient.get<any[]>(url, requestOptions);
  }

  // This function is for activity wise learning progress API
  getLearningProgressByActivity(childId: number, activity: string) {
    const requestOptions = this.getRequestOptions();
    const progressByActivity = `${this.activityLearningProgress}${childId}/${activity}`;
    return this.httpClient.get<any[]>(progressByActivity, requestOptions);
  }

  // This function is for show all activity in learning progress module
  getAllActivity(childId: number): Observable<any[]> {
    const requestOptions = this.getRequestOptions();
    const activityUrl = `${this.showAllActivity}${childId}`;
    return this.httpClient.get<any[]>(activityUrl, requestOptions);
  }

  //This function is for goals and feedback component
  getGolasAndFeedback(childId: number): Observable<any[]> {
    const requestOptions = this.getRequestOptions();
    const goalsAndFeedbackUrl = `${this.goalsAndFeedback}${childId}`;
    return this.httpClient.get<any[]>(goalsAndFeedbackUrl, requestOptions);
  }

  //This function is for goals and feedback component for Age wise
  getGolasAndFeedbackByAgeWise(
    childId: number,
    activity: string,
    age
  ): Observable<any[]> {
    const requestOptions = this.getRequestOptions();
    const goalsAndFeedbackUrl = `${this.goalsAndFeedbackByAge}${childId}/${activity}/${age}`;
    return this.httpClient.get<any[]>(goalsAndFeedbackUrl, requestOptions);
  }

  //This function is for accomplishments
  getAccomplishment(childId: number): Observable<any[]> {
    const requestOptions = this.getRequestOptions();
    const accomplishmentUrl = `${this.accomplishment}${childId}`;
    return this.httpClient.get<any[]>(accomplishmentUrl, requestOptions);
  }

  getActivityInAccomplishments(childNumber: number, activity: string) {
    const requestOptions = this.getRequestOptions();
    const activityAccomplishUrl = `${this.activityInAccomplishment}${childNumber}/${activity}`;
    return this.httpClient.get<any[]>(activityAccomplishUrl, requestOptions);
  }

  //getting images
  getSvgImages() {
    return this.httpClient.get<any>('assets/JsonFile/activityIcon.json');
  }
}
