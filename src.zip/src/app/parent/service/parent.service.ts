import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, catchError, map } from 'rxjs';
import { Seekerz } from '../model/seekerz.class';
import { environment } from '../../../environments/environment.development';

@Injectable({
  providedIn: 'root',
})
export class ParentService {
  public parentApi = environment.localdomain + '/seekerz/get';
  public addKidsApi = environment.localdomain + '/seekerz/update';
  public manageClassParentGetApi =
    environment.localdomain + '/student/getChildClass';
  public parentPaymentApi =
    environment.localdomain + '/student/parentapproveclass';

  private currentNavItemSubject!: BehaviorSubject<string>;
  public currentNavItem!: Observable<string>;
  classwithTeacherID: string = '';
  public getParentURL = environment.localdomain + '/seekerz/get/';
  public kidUpdateAPI = environment.localdomain + '/seekerz/update';
  public rescheduleClassAPI = environment.localdomain + '/student/reschedule'
  public afterMettingTiggerAPI = environment.localdomain + '/student/joinClass'

  constructor(private http: HttpClient) {
    const currentnavItem = localStorage.getItem('currentItem');

    this.currentNavItemSubject = new BehaviorSubject<string>(currentnavItem);
    this.currentNavItem = this.currentNavItemSubject.asObservable();
  }

  private getRequestOptions(): { headers: HttpHeaders } {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + localStorage.getItem('token'),
    });
    return { headers };
  }

  getData(id: any): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<any>(this.getParentURL + id, requestOptions);
  }

  addKidsToParent(seekerzObject: Seekerz): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.put<any>(this.kidUpdateAPI, seekerzObject);
  }
  /**
   * @param person For Navbar function
   * @returns
   */
  setCurrentNavItem(navItem: string) {
    // Set item in localStorage
    localStorage.setItem('previousNavItem', this.currentNavItemSubject.value);
    console.log('currentNavItem:', this.currentNavItemSubject.value);
    this.currentNavItemSubject.next(navItem);
  }
  setclassWithTeacherID(navItem: string) {
    this.classwithTeacherID = navItem;
  }
  /**
   *@param manageClassParentGetApi
   * @returns
   */
  manageClassParentGet(childId: number) {
    const requestOptions = this.getRequestOptions();
    let timeZone = localStorage.getItem('timezone')
    if(!timeZone){
      timeZone = 'Ist'
    }
    const apiUrlWithChildId = `${this.manageClassParentGetApi}/${childId}/${timeZone}`;
    return this.http.get<any>(apiUrlWithChildId, requestOptions);
  }
  /**
   * @param studentId
   * @returns
   */
  parentPaymentPut(studentId: any,ageGroup: string, classType: string): Observable<any> {

    const params = new HttpParams()
        .set('studentId',String(studentId))
        .set('ageGroup', ageGroup)
        .set('classType', classType);
        const requestOptions = {...this.getRequestOptions(),params:params};
    const apiUrl = `${this.parentPaymentApi}`;
    return this.http.put<any>(apiUrl,{},requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError)
    );
  }
  /**
   * @param studentId
   * @returns
   */
  reschedulePut(studentId: any){
    const requestOptions = this.getRequestOptions();
    const rescheduleURL = `${this.rescheduleClassAPI}/${studentId}`;
    return this.http.put<any>(rescheduleURL,{},requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError)
    );
  }
  /**
   * After join the meeting the api will tigger
   */
  afterMeetingTigger(studentId: any){
    const requestOptions = this.getRequestOptions();
    const rescheduleURL = `${this.afterMettingTiggerAPI}/${studentId}`;
    console.log(rescheduleURL,"lllllllllllllllllllllservice");
    return this.http.put<any>(rescheduleURL,{},requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError)
    );
  }

  /**
   * @param error
   */
  private handleError(error: any): Observable<never> {
    console.error('An error occurred:', error);
    throw error;
  }

}
