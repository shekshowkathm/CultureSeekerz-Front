import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ParentRoutingModule } from './parent-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { LoginRegisterModule } from '../login-register/login-register.module';
import { ParentService } from './service/parent.service';
import { UserModule } from '../user/user.module';
import { ActivityComponent } from '../user/activity/activity.component';
import { ReactiveFormsModule } from '@angular/forms';
import { RegistrationService } from '../login-register/service/registration.service';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ParentRoutingModule,
    HttpClientModule,
    LoginRegisterModule,
    UserModule,
    ActivityComponent,
    ReactiveFormsModule,
  ],
  providers: [ParentService,RegistrationService],
})
export class ParentModule {}
