import { Injectable } from '@angular/core';
import { CalendarSchedulerEvent } from 'angular-calendar-scheduler';
import { environment } from '../../../environments/environment.development';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, catchError, map } from 'rxjs';
import { DatePipe } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class CalendarService {
  public getCalendarForParentApi = environment.localdomain + '/student/parentCalendar';
  public getCalendarForTeacherApi = environment.localdomain + '/teacher/teacherCalender'
  public getCalendarForStudentApi = environment.localdomain + '/student/studentcalendar';
  public GetAllChildPaymentApi = environment.localdomain + '/student/retrieveClasses';
  private colorMap: { [studentName: string]: string } = {};
  private colors: string[] = ['#C2FCFF','#D5E9FF','#F9FBE7','#CDE990','purple','skyblue','cyan','magenta','yellow','brown'];


  constructor(private http: HttpClient) { }
  private getRequestOptionsWithToken(): { headers: HttpHeaders } {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + localStorage.getItem('token'),
    });
    return { headers };
  }
    /**
   * @param error
   */
    private handleError(error: any): Observable<never> {
      console.error('An error occurred:', error);
      throw error;
    }

    getColorForStudent(studentName: string): string {
      if (this.colorMap.hasOwnProperty(studentName.toLowerCase())) {
        return this.colorMap[studentName.toLowerCase()];
      } else {
        const colorIndex = Object.keys(this.colorMap).length % this.colors.length;
        const color = this.colors[colorIndex];
        this.colorMap[studentName.toLowerCase()] = color;
        return color;
      }
    }

  // getEvents(parentOrChildId: string, role: 'PARENT' | 'TEACHER' | 'CHILD'): Promise<CalendarSchedulerEvent[]> {
  //   const requestOptions = this.getRequestOptionsWithToken();
  //   let apiUrl: string;
  //   let getTimeZone = localStorage.getItem('timezone');
  //   if (role === 'PARENT') {
  //     apiUrl = `${this.getCalendarForParentApi}/${parentOrChildId}/${getTimeZone}`;
  //   } else if(role === 'TEACHER'){
  //     apiUrl = `${this.getCalendarForTeacherApi}/${parentOrChildId}`;
  //   }else {
  //     apiUrl = `${this.getCalendarForStudentApi}/${parentOrChildId}/${getTimeZone}`;
  //   }
  //   return this.http.get<any>(apiUrl, requestOptions).pipe(
  //     map((response: any) => {
  //       const events: CalendarSchedulerEvent[] = [];
  //       response.forEach((item: any, index: number) => {
  //         const {
  //           studentName,
  //           teacherName,
  //           activity,
  //           day,
  //           startTime,
  //           endTime,
  //           startDate,
  //           endDate,
  //           paymentStatus,
  //           daysMore,
  //           // meetingLink,
  //         } = item;
 
  //         const startDateTime = this.parseDateAndTime(startDate, startTime);          
  //         const endDateTime = this.parseDateAndTime(endDate, endTime);          
  //         const occurrences = this.calculateOccurrences(startDateTime,endDateTime,day);          
  //         const formattedDate = new DatePipe('en-US').transform(startDateTime, 'd MMMM yyyy');          
  //         occurrences.forEach((occurrence, occurrenceIndex) => {
  //           const event: CalendarSchedulerEvent = {
  //             id: `${index + 1}-${occurrenceIndex + 1}`,
  //             start: occurrence.start,
  //             end: occurrence.end,
  //             title:  `${studentName}, ${activity}, ${formattedDate}`,
  //             content: `${studentName}, Teacher Name: ${teacherName}`,
  //             payment:paymentStatus,
  //             daysMore:daysMore,
  //             teacherName:teacherName,
  //             color: {
  //               primary: this.getColorForStudent(studentName),
  //               secondary: this.getColorForStudent(studentName),
  //               secondaryText: '#FF7C00',
  //             },
  //           };
  //           events.push(event);            
  //         });                    
  //       });
  //       console.log(events,"hhhhhhhhhhhhhhhhhhhhhhhhhhh");
  //       return events;
  //     }),

  //     ////////////////
  //     map((response: any) => {
  //       const events: CalendarSchedulerEvent[] = [];
  //       const isTeacher = role === 'TEACHER';
  //       response.forEach((item: any, index: number) => {
  //           const {
  //               activity,
  //               startDate,
  //               endDate,
  //               startTime,
  //               endTime,
  //               meetingLink,
  //               day,
  //               students
  //           } = item;
  //           const eventStudents = students.map((student: any) => ({
  //               name: student.name,
  //               rescheduleStatus: student.rescheduleStatus
  //           }));
  //           const startDateTime = this.parseDateAndTime(startDate, startTime);
  //           const endDateTime = this.parseDateAndTime(endDate, endTime);
  //           const occurrences = this.calculateOccurrences(startDateTime, endDateTime, day);
  //           const formattedDate = new DatePipe('en-US').transform(startDateTime, 'd MMMM yyyy');
  //           occurrences.forEach((occurrence, occurrenceIndex) => {
  //               const event: CalendarSchedulerEvent = {
  //                   id: `${index + 1}-${occurrenceIndex + 1}`,
  //                   start: occurrence.start,
  //                   end: occurrence.end,
  //                   title: `${''}, ${activity}, ${formattedDate}`,
  //                   content: formattedDate, 
  //                   color: {
  //                       primary: '#FFE0C2',
  //                       secondary: '#FFE0C2',
  //                       secondaryText: '#FF7C00',
  //                   },
  //                   students: eventStudents 
  //               };
  //               events.push(event);
  //           });
  //       });
  //       return events;
  //   }),
    
  //   ).toPromise();    
  // }
  getEvents(parentOrChildId: string, role: 'PARENT' | 'TEACHER' | 'CHILD'): Promise<CalendarSchedulerEvent[]> {
    const requestOptions = this.getRequestOptionsWithToken();
    let apiUrl: string;
    const getTimeZone = localStorage.getItem('timezone');
    
    if (role === 'PARENT') {
      apiUrl = `${this.getCalendarForParentApi}/${parentOrChildId}/${getTimeZone}`;
    } else if (role === 'TEACHER') {
      apiUrl = `${this.getCalendarForTeacherApi}/${parentOrChildId}`;
    } else {
      apiUrl = `${this.getCalendarForStudentApi}/${parentOrChildId}/${getTimeZone}`;
    }
    return this.http.get<any>(apiUrl, requestOptions).pipe(
      map((response: any) => {
        const events: CalendarSchedulerEvent[] = [];
        response.forEach((item: any, index: number) => {
          const startDateTime = this.parseDateAndTime(item.startDate, item.startTime);
          const endDateTime = this.parseDateAndTime(item.endDate, item.endTime);
          const occurrences = this.calculateOccurrences(startDateTime, endDateTime, item.day);
          const formattedDate = new DatePipe('en-US').transform(startDateTime, 'd MMMM yyyy');
  
          occurrences.forEach((occurrence, occurrenceIndex) => {
            let event: CalendarSchedulerEvent;
  
            if (role === 'PARENT' || role === 'CHILD') {
  
              const { studentName, teacherName, activity, paymentStatus, daysMore, studentId, meetingLink } = item;
  
              event = {
                id: `${index + 1}-${occurrenceIndex + 1}`,
                start: occurrence.start,
                end: occurrence.end,
                title: `${studentName}, ${activity}, ${formattedDate}`,
                content: `${studentName}, Teacher Name: ${teacherName}`,
                payment: paymentStatus,
                daysMore: daysMore,
                teacherName: teacherName,
                studentId: studentId,
                meetingLink: meetingLink,

                color: {
                  primary: this.getColorForStudent(studentName),
                  secondary: this.getColorForStudent(studentName),
                  secondaryText: '#FF7C00',
                },
              };
            } else if (role === 'TEACHER') {
  
              const { activity, students, enrolledStudentCount } = item;
              const eventStudents = students.map((student: any) => ({
                name: student.name,
                rescheduleStatus: student.rescheduleStatus
              }));
  
              event = {
                id: `${index + 1}-${occurrenceIndex + 1}`,
                start: occurrence.start,
                end: occurrence.end,
                title: `${''}, ${activity}, ${formattedDate}`,
                content: formattedDate,
                enrolledStudentCount: enrolledStudentCount,
                color: {
                  primary: '#FFE0C2',
                  secondary: '#FFE0C2',
                  secondaryText: '#FF7C00',
                },
                students: eventStudents
              };
            }
  
            events.push(event);
          });
        });
        return events;
      })
    ).toPromise();
  }
  
 
calculateOccurrences(startDate: Date, endDate: Date, dayOfWeek: string): { start: Date; end: Date }[] {
  const occurrences: { start: Date; end: Date }[] = [];
  const startHours = startDate.getHours();
  const startMinutes = startDate.getMinutes();
  const endHours = endDate.getHours();
  const endMinutes = endDate.getMinutes();

  for (let current = new Date(startDate); current <= endDate; current.setDate(current.getDate() + 1)) {
      if (current.getDay() === this.getDayOfWeek(dayOfWeek)) {
          const start = new Date(current);
          const end = new Date(current);
          end.setHours(startHours + (endHours - startHours), startMinutes + (endMinutes - startMinutes));
          occurrences.push({ start, end });
      }
  }

  return occurrences;
}


  private getDayOfWeek(dayOfWeekStr: string): number {
    switch (dayOfWeekStr.substr(0, 3)) {
        case 'Sun':
            return 0;
        case 'Mon':
            return 1;
        case 'Tue':
            return 2;
        case 'Wed':
            return 3;
        case 'Thu':
            return 4;
        case 'Fri':
            return 5;
        case 'Sat':
            return 6;
        default:
            return -1;
    }
}

  private parseDateAndTime(dateStr: string, timeStr: string): Date {
    const [day, month, year] = dateStr.split('-').map(Number);
    const [hours, minutes] = timeStr.match(/\d+/g).map(Number);
    const isPM = /pm/i.test(timeStr);
    const adjustedHours = isPM && hours !== 12 ? hours + 12 : hours;
    return new Date(year, month - 1, day, adjustedHours, minutes);
  }


  allChildPayment(childId, currentMonth:number): Observable<any> {
    const requestOptions = this.getRequestOptionsWithToken();
    const apiUrl = `${this.GetAllChildPaymentApi}/${childId}/${currentMonth}`;
    return this.http.get<any>(apiUrl, requestOptions);
  }
}

