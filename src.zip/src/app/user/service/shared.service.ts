import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SharedService {

  constructor() { }

  getAbbreviatedDays(days: string[]): string {
    const dayAbbreviations = {
      "Mon": "Mon",
      "Tue": "Tue",
      "Wed": "Wed",
      "Thu": "Thu",
      "Fri": "Fri",
      "Sat": "Sat",
      "Sun": "Sun"
    };
  
    const sortedDays = days.map(day => dayAbbreviations[day]).sort((a, b) => {
      const order = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
      return order.indexOf(a) - order.indexOf(b);
    });
  
    let formattedDays = '';
  
    for (let i = 0; i < sortedDays.length; i++) {
      if (i === 0) {
        formattedDays += sortedDays[i];
      } else if (i === sortedDays.length - 1) {
        const currentDayIndex = Object.keys(dayAbbreviations).indexOf(sortedDays[i]);
        const previousDayIndex = Object.keys(dayAbbreviations).indexOf(sortedDays[i - 1]);
  
        if (currentDayIndex - previousDayIndex === 1) {
          formattedDays += ` - ${sortedDays[i]}`;
        } else {
          formattedDays += `, ${sortedDays[i]}`;
        }
      } else {
        const currentDayIndex = Object.keys(dayAbbreviations).indexOf(sortedDays[i]);
        const previousDayIndex = Object.keys(dayAbbreviations).indexOf(sortedDays[i - 1]);
        const nextDayIndex = Object.keys(dayAbbreviations).indexOf(sortedDays[i + 1]);
  
        if (currentDayIndex - previousDayIndex === 1 && nextDayIndex - currentDayIndex === 1) {
          continue; 
        } else {
          formattedDays += `, ${sortedDays[i]}`;
        }
      }
    }
  
    return formattedDays;
  } 
  
  
  private triggerSource = new Subject<void>();
  trigger$ = this.triggerSource.asObservable();
  triggerFunction(childId) {
    this.triggerSource.next(childId);
  }

  /**
   * parent component to calendar scheduler component send child data and trigger function 
   */
  private childDataPass = new Subject<any>();
  childData$ = this.childDataPass.asObservable();
  sendData(childData: any): void {    
    this.childDataPass.next(childData);
  }
  private parentDataPass = new Subject<any>();
  parentDataPass$ = this.parentDataPass.asObservable();
  sendParentIdForCalendar(ParentId: string): void{
    this.parentDataPass.next(ParentId);
  }
}
