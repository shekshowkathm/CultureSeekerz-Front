import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, map } from 'rxjs';
import { environment } from '../../../environments/environment.development';
import { BookTrial, TrialClass } from '../model/trial-class';
import { ManageClass } from '../model/manage-class';

@Injectable({
  providedIn: 'root',
})
export class UserServiceService {
  public activityApi = environment.localdomain + '/activeclass/getbyactivity';
  public classTeacherApi = environment.localdomain + '/activeclass/getActiveClass';
  public classSearchApi = environment.localdomain + '/activeclass/search';
  public teacherProfileCardApi = environment.localdomain + '/activeclass/getActiveClass/' //this api is for teacher profile card monthly calender
  public classTopicApi = environment.localdomain + '/activeclass/extracttopic';
  public trialTeacherAPI = environment.localdomain + '/teacher/gettrialclassteachers';
  public trialFilterTeacherAPI = environment.localdomain + '/activeclass/trialclassSearch';
  public getTeacherData = environment.localdomain + '/teacher/getTeachers';
  public getAgeGroupApi = environment.localdomain + '/activeclass/getagegroup';
  public sendTrialAPI = environment.localdomain + '/trailclass/add';
  public paymentPostAPI = environment.localdomain + '/student/add';
  public homePageTeacherGet = environment.localdomain + '/activeclass/getactiveclass/';
  public getOneStudentManageClassAPi = environment.localdomain + '/student/get/';
  public getTrialClassApi = environment.localdomain + '/trailclass/gettrialclass';
  public deleteClassAPI = environment.localdomain + '/student/remove/';
  public feedbackAPI = environment.localdomain + '/trailclass/addfeedback';
  private timeZoneLocal:string;
  constructor(private http: HttpClient) {
    this.timeZoneLocal = localStorage.getItem('timezone');
  }

  private getRequestOptions(): { headers: HttpHeaders } {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });
    return { headers };
  }
  private getRequestOptionsWithToken(): { headers: HttpHeaders } {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + localStorage.getItem('token'),
    });
    return { headers };
  }

  /**
   * @param person Activity With Teacher
   * @returns
   */
  activityWithTeacher(activityNameParams: string): Observable<TrialClass[]> {
    const requestOptions = this.getRequestOptions();
    let timeZone = localStorage.getItem('timezone');
    if(!timeZone){
      timeZone="Los_Angeles";
    }

    const apiUrl = `${this.activityApi}/${activityNameParams}/${timeZone}`;
    return this.http.get<TrialClass[]>(apiUrl, requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError)
    );
  }
  /**
   * @param activityNameParams
   * @returns class topic
   */
  getActivityClassTopic(activityNameParams: string): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const apiUrl = `${this.classTopicApi}/${activityNameParams}`;
    return this.http.get(apiUrl, requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError)
    );
  }
  /**
   * @param person Activity With Teacher search
   * @returns
   */
  activityWithClassSearch(searchPayload: any): Observable<TrialClass[]> {
    const requestOptions = this.getRequestOptions();
    const apiUrl = `${this.classSearchApi}`;
    return this.http.post<TrialClass[]>(apiUrl, searchPayload, requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError)
    );
  }
  /**
   * @param activityNameParams
   * @returns teacher Data
   */
  getTeacherActivity(activityNameParams) {
    const requestOptions = this.getRequestOptions();
    const apiUrl = `${this.getTeacherData}/${activityNameParams}`;
    return this.http.get<any>(apiUrl, requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError)
    );
  }
  /**
   * get ageGroug Wise
   */
  getAgeGroup(activityNameParams: string): Observable<TrialClass[]> {
    const requestOptions = this.getRequestOptions();
    let time = localStorage.getItem('timezone');
    if(!time){
      time = 'Los_Angeles';
    }
    const apiUrl = `${this.getAgeGroupApi}/${activityNameParams}/${time}`;
    return this.http.get<TrialClass[]>(apiUrl, requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError)
    );
  }

  /**
   * @returns trial class
   */
  trialTeacher() : Observable <BookTrial[]>{
    const requestOptions = this.getRequestOptions();
    let getTimeZone = this.timeZoneLocal || "Los_Angeles";
    const apiUrl = `${this.trialTeacherAPI}/${getTimeZone}`;
    return this.http.get<BookTrial[]>(apiUrl, requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError)
    );
  }

  trialTeacherFilter(selectedActivity) : Observable <BookTrial[]>{
    const requestOptions = this.getRequestOptions();
    let getTimeZone = localStorage.getItem('timezone') || "Los_Angeles";
    const apiUrl = `${this.trialFilterTeacherAPI}/${selectedActivity}/${getTimeZone}`;
    return this.http.get<BookTrial[]>(apiUrl, requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError)
    );
  }

  getParticularStudent(id: any) :Observable <ManageClass[]>{
    const requestOptions = this.getRequestOptionsWithToken();
    let getTimeZone = localStorage.getItem('timezone') || "Los_Angeles";
    const apiUrl = `${this.getOneStudentManageClassAPi}${id}/${getTimeZone}`;
    return this.http.get<ManageClass[]>(apiUrl, requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError)
    );
  }
  /**
   * @param object
   * @returns send mail
   */
  sendEmail(object: any): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.post<any>(this.sendTrialAPI, object, requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError)
    );
  }
  /**
   * @param teacherIdParams
   * @returns teacherprofile data
   */

  getTeacherProfileCard(classId: string): Observable<any> {
    const requestOptions = this.getRequestOptions();
    let timeZonee = localStorage.getItem('timezone')
    if(!timeZonee){
      timeZonee='Los_Angeles'
    }
    const apiUrl = `${this.teacherProfileCardApi}${classId}/${timeZonee}`;

    return this.http.get(apiUrl, requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError)
    );
  }


  /**
   * @param person Get data class and teacher
   * @returns
   */
  getClassWithTeacher(classIdParams: string): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const apiUrl = `${this.classTeacherApi}/${classIdParams}`;
    return this.http.get(apiUrl, requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError)
    );
  }
  /**
 * @param person POST payemnts
 * @returns
 */

  paymentPostTrigger(object: any): Observable<any> {
    const requestOptions = this.getRequestOptionsWithToken();
    return this.http.post(this.paymentPostAPI, object, { ...requestOptions, responseType: 'text' }).pipe(
      map((response: any) => response),
      catchError(this.handleError)
    );
  }


  /**
   * @returns Get teacher for home page
   */
  homeTeacherGet(): Observable<any> {
    const requestOptions = this.getRequestOptions();
    let getTimeZone = localStorage.getItem('timezone') || "Los_Angeles";
    const apiUrl = `${this.homePageTeacherGet}${getTimeZone}`;
    return this.http.get(apiUrl, requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError)
    );
  }
  /**
   * @param studentEmail
   * @returns trial classes details
   */
  getTrialClass(studentEmail: string): Observable<any> {
    const requestOptions = this.getRequestOptionsWithToken();
    const apiUrl = `${this.getTrialClassApi}/${studentEmail}`;
    return this.http.get(apiUrl, requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError)
    );
  }
  /**
   * @param error
   */
  private handleError(error: any): Observable<never> {
    console.error('An error occurred:', error);
    throw error;
  }

  deleteItem(itemId): Observable<void> {
    const requestOptions = this.getRequestOptionsWithToken();
    return this.http.delete<void>(this.deleteClassAPI+itemId,requestOptions);
  }
  updatefeedback(trialData:any): Observable<void>{
    const requestOptions = this.getRequestOptionsWithToken();
    const apiUrl =`${this.feedbackAPI}`
    return this.http.put<void>(apiUrl,trialData,requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError));

  }
}
