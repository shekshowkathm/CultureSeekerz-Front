import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnDestroy,
} from '@angular/core';
import { HeaderComponent } from '../../login-register/header/header.component';
import { MatIconModule } from '@angular/material/icon';
import { NgFor, NgIf, ViewportScroller } from '@angular/common';
import { UserServiceService } from '../service/user-service.service';
import Swal from 'sweetalert2';
import { FormsModule } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { RouterModule } from '@angular/router';
import { BookTrial, TrialClass } from '../model/trial-class';
import { SharedService } from '../service/shared.service';
import { CookieService } from 'ngx-cookie-service';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ParentService } from '../../parent/service/parent.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-trail-class',
  standalone: true,
  imports: [
    HeaderComponent,
    MatIconModule,
    NgFor,
    NgIf,
    FormsModule,
    RouterModule,
    ProgressSpinnerModule,
  ],
  templateUrl: './trail-class.component.html',
  styleUrl: './trail-class.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TrailClassComponent implements OnDestroy {
  FreeTrialParms: string = '';
  filteringActive: boolean = false;
  filteringActiveagegroup: boolean = false;
  selectedActivity: string = '';
  selectedActivityagegroup: string = '';
  filteredData: BookTrial[] = [];
  ageGroupParams: string;
  agegroupWise: TrialClass[] = [];
  bookTrial: BookTrial[] = []; //for get method
  emptyTrialClassArrayData: boolean = true;
  showFullDescription: boolean[] = [];
  role: string = '';
  highestFees: string[] = [];
  filteredDataageGroup: TrialClass[] = [];
  event: any;
  paramsString: string = '';
  filterDataLoaded: boolean = true;
  private subscription: Subscription;
  constructor(
    private userServiceService: UserServiceService,
    private cdr: ChangeDetectorRef,
    private router: Router,
    private route: ActivatedRoute,
    private sharedService: SharedService,
    private cookieService: CookieService,
    private parentService: ParentService,
    private viewportScroller: ViewportScroller
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe((params) => {
      this.ageGroupParams = params['ageGroup'];
      this.FreeTrialParms = params['FreeTrial'];
    });
    this.allFunction();
    this.role = localStorage.getItem('role');
    this.route.url.subscribe((segments) => {
      segments.forEach((segment) => {
        if (segment.path === 'classWithTeacher') {
        }
      });
    });
  }

  allFunction() {
    if (this.ageGroupParams) {
      this.subscription = this.userServiceService
        .getAgeGroup(this.ageGroupParams)
        .subscribe({
          next: (response: TrialClass[]) => {
            this.agegroupWise = response;
            this.filterDataLoaded = false;
            this.ageGroupfilterData();
            this.cdr.detectChanges();
          },
          error: (error) => {
            console.error('Error:', error);
          },
        });
    } else if (this.FreeTrialParms) {
      this.trialClassTeacherAll();
    }
  }
  trialClassTeacherAll() {
    this.emptyTrialClassArrayData = false;
    this.bookTrial = [];
    this.subscription = this.userServiceService.trialTeacher().subscribe({
      next: (response: BookTrial[]) => {
        this.bookTrial = response;
        this.filterDataLoaded = false;
        this.emptyTrialClassArrayData = this.bookTrial.length === 0;
        this.cdr.detectChanges();
      },
      error: (error) => {
        console.error('Error:', error);
      },
    });
  }

  handleInputChange(event: any) {
    this.filteringActive = true;
    this.filterDataLoaded = true;
    this.emptyTrialClassArrayData = false;
    this.trialFilterGetFunction(), this.cdr.detectChanges();
    // this.emptyTrialClassArrayData = true;
  }

  trialFilterGetFunction() {
    this.filterDataLoaded = true;
    this.filteredData = [];
    if (this.selectedActivity === '') {
      this.filteringActive = false;
      this.trialClassTeacherAll();
      this.cdr.detectChanges();
    } else {
      console.log('else');
      this.subscription = this.userServiceService
        .trialTeacherFilter(this.selectedActivity)
        .subscribe({
          next: (response: BookTrial[]) => {
            this.filteredData = response;
            this.filterDataLoaded = false;
            this.emptyTrialClassArrayData = this.filteredData.length === 0;
            this.filterDataLoaded = false;

            this.cdr.detectChanges();
          },
          error: (error) => {
            console.error('Error:', error);
          },
        });
    }
  }

  // filter for age grouping
  inputChangeageGroup(event: any) {
    this.filteringActiveagegroup = true;
    this.ageGroupfilterData();
    this.cdr.detectChanges();
    this.emptyTrialClassArrayData = true;
  }

  ageGroupfilterData(): void {
    if (this.selectedActivityagegroup === '') {
      this.filteredDataageGroup = this.agegroupWise.slice();
    } else {
      this.filteredDataageGroup = this.agegroupWise.filter(
        (teacherageGroup) => {
          return (
            teacherageGroup.scheduleClass &&
            teacherageGroup.scheduleClass.activity ===
              this.selectedActivityagegroup
          );
        }
      );
    }
  }

  triggerFreeDemo(teacher: any) {
    const storedUsername = localStorage.getItem('username');
    Swal.fire({
      title: 'Please provide your email or username',
      input: 'text',
      inputValue: storedUsername,
      inputPlaceholder: 'Enter your email',
      showCloseButton: true,
      showCancelButton: true,
      confirmButtonText: 'Submit',
      cancelButtonText: 'Sign in',
      showLoaderOnConfirm: true,
      preConfirm: (email) => {
        if (!email) {
          Swal.showValidationMessage('Email is required');
        } else {
          this.sendMail(email, teacher);
        }
      },
    }).then((result) => {
      if (result.dismiss === Swal.DismissReason.cancel) {
        this.router.navigate(['/login']);
      }
    });
  }

  sendMail(email: string, teacher: any) {
    console.log(teacher, 'pppppppppppp');

    if (this.isEmailValid(email)) {
      const object = {
        requestEmail: email,
        teacherName: teacher.teacherResponse.name,
        teacherEmail: teacher.teacherResponse.email,
        activity: teacher.scheduleClass.activity,
        classId: teacher.classId,
        teacherUniqueId: teacher.teacherResponse.teacherUniqueId,
      };
      this.userServiceService.sendEmail(object).subscribe({
        next: (response) => {
          Swal.fire(
            'Thank you for your request!',
            'We will email you with available options within 1 business day.',
            'success'
          );
        },
        error: (error) => {
          Swal.fire('Error!', 'Failed to send email.', 'error');
        },
      });
    } else {
      const object = {
        requestEmail: email,
        teacherName: teacher.teacherResponse.name,
        teacherEmail: teacher.teacherResponse.email,
        activity: teacher.scheduleClass.activity,
        classId: teacher.classId,
        userName: email,
        teacherUniqueId: teacher.scheduleClass.classUniqueId,
      };
      this.userServiceService.sendEmail(object).subscribe({
        next: (response) => {
          Swal.fire(
            'Thank you for your request!',
            'We will email you with available options within 1 business day.',
            'success'
          );
        },
        error: (error) => {
          Swal.fire('Error!', 'Failed to send email.', 'error');
        },
      });
    }
  }

  isEmailValid(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  getDescriptionContent(about: string, index: number): string {
    if (this.showFullDescription && this.showFullDescription[index]) {
      return about;
    } else {
      return about.slice(0, 120) + '...';
    }
  }

  toggleDescription(index: number): void {
    if (this.showFullDescription) {
      this.showFullDescription[index] = !this.showFullDescription[index];
    }
  }

  //enroll function starts here
  checkRole(classId, event: Event) {
    event.preventDefault();
    event.stopPropagation();

    if (this.role === 'PARENT') {
      Swal.fire({
        title: 'Are you sure you want to enroll in the class?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, enroll it',
        cancelButtonText: 'No, cancel',
      }).then((result) => {
        if (result.isConfirmed) {
          Swal.fire({
            title:
              'We will email you with available options within 1 business day.',
            icon: 'info',
            confirmButtonText: 'Ok',
          });
        } else {
        }
      });
    } else if (!this.role) {
      Swal.fire({
        icon: 'info',
        title: 'Unlock by Signing up or Logging in!',
        showCloseButton: true,
        showCancelButton: true,
        confirmButtonText: 'Go to register',
        cancelButtonText: 'Sign in',
        reverseButtons: true,
      }).then((result) => {
        if (result.isConfirmed) {
          // Redirect to register page
          this.router.navigate(['/login-reg/toregistration']);
        } else if (result.dismiss === Swal.DismissReason.cancel) {
          // Redirect to login page
          this.router.navigate(['/login']);
        }
      });
    } else if (this.role === 'STUDENT') {
      const age = localStorage.getItem('age');
      const ageNumber = parseFloat(age);
      if (ageNumber >= 18) {
        Swal.fire({
          title: 'Are you sure you want to enroll in the class?',
          icon: 'question',
          showCancelButton: true,
          confirmButtonText: 'Yes, enroll it',
          cancelButtonText: 'No, cancel',
        }).then((result) => {
          if (result.isConfirmed) {
            const StudentID = localStorage.getItem('id');
            const studenObject = {
              studentInfo: {
                id: StudentID,
              },
              activeClass: {
                id: classId,
              },
              enable: true,
            };
            this.paymentPost(studenObject);
          } else {
          }
        });
      } else {
        Swal.fire({
          title: 'Do you want to enroll in this class?',
          text: 'It will be notified to your parent',
          icon: 'question',
          showCancelButton: true,
          confirmButtonText: 'Ok, enroll it',
          cancelButtonText: 'Cancel',
        }).then((result) => {
          if (result.isConfirmed) {
            const StudentID = localStorage.getItem('id');
            const studenObjects = {
              studentInfo: {
                id: StudentID,
              },
              activeClass: {
                id: classId,
              },
              enable: false,
            };
            this.paymentPost(studenObjects);
          } else {
          }
        });
      }
    }
  }

  paymentPost(object: any) {
    this.userServiceService.paymentPostTrigger(object).subscribe({
      next: (response) => {
        Swal.fire({
          title: 'Our admin will contact you',
          icon: 'info',
          confirmButtonText: 'Ok',
        });
      },
      error: (error) => {},
    });
  }

  formatDays(days: string[]): string {
    return this.sharedService.getAbbreviatedDays(days);
  }

  // getFeeForAgeGroup(ageGroup: string, fees: any[]): string {
  //   const matchedFee = fees.find(fee => fee.ageGroup.toLowerCase() === ageGroup.toLowerCase());
  //   return matchedFee ? matchedFee.amount : 'N/A';
  // }

  // calculateHighestFees() {
  //   this.highestFees = [];
  //   this.bookTrial.forEach((teacher) => {
  //     let maxFeeRange = '';
  //     let maxUpperLimit = -1;
  //     Object.values(teacher.scheduleClass).forEach((schedule: any) => {
  //       if (schedule.fees) {
  //         const feeRange = schedule.fees.split(' - ');
  //         if (feeRange.length === 2) {
  //           const lowerLimit = parseInt(feeRange[0]);
  //           const upperLimit = parseInt(feeRange[1]);
  //           if (
  //             !isNaN(lowerLimit) &&
  //             !isNaN(upperLimit) &&
  //             upperLimit > maxUpperLimit
  //           ) {
  //             maxFeeRange = schedule.fees;
  //             maxUpperLimit = upperLimit;
  //           }
  //         }
  //       }
  //     });
  //     this.highestFees.push(maxFeeRange !== '' ? maxFeeRange : 'N/A');
  //   });
  // }

  getFeeRangeForAgeGroup(ageGroup: string): string {
    switch (ageGroup) {
      case 'KG and Elementary':
        return '8-10';
      case 'Middle School':
        return '9-11';
      case 'High School':
        return '9-12';
      default:
        return 'N/A';
    }
  }

  ngOnDestroy(): void {
    if (localStorage.length === 0) {
      this.route.queryParams.subscribe((params) => {
        const ageGroup = params['ageGroup'];
        const FreeTrial = params['FreeTrial'];
        if (!ageGroup || ageGroup.trim() === '') {
          this.paramsString = FreeTrial;
        } else {
          this.paramsString = ageGroup;
        }
      });
      this.cookieService.set('route', 'trailclass');
      this.cookieService.set('params', this.paramsString);
    } else {
    }
    if (this.subscription) {
      this.subscription.unsubscribe();
      console.log('unsubsribed');
    }
  }

  navigateToTeacherProfileClasses(classId: number) {
    const role = localStorage.getItem('role');
    if (role === 'PARENT') {
      localStorage.setItem('teacherprofilecardid', classId.toString());
      this.parentService.setCurrentNavItem('teacherprofilecard');
    } else {
      this.router
        .navigate(['/teacherProfileCard'], {
          queryParams: { classId: classId.toString() },
        })
        .then(() => {
          this.viewportScroller.scrollToPosition([0, 0]);
        });
    }
  }
}
