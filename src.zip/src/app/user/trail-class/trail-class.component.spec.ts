import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrailClassComponent } from './trail-class.component';

describe('TrailClassComponent', () => {
  let component: TrailClassComponent;
  let fixture: ComponentFixture<TrailClassComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TrailClassComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(TrailClassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
