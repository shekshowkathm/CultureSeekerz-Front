import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { Router, RouterModule } from '@angular/router';
import { ParentService } from '../../parent/service/parent.service';

@Component({
  selector: 'app-activity',
  standalone: true,
  imports: [RouterModule, MatIconModule],
  templateUrl: './activity.component.html',
  styleUrl: './activity.component.scss',
})
export class ActivityComponent {
  activity: { [key: string]: SafeHtml } = {};
  constructor(
    private sanitizer: DomSanitizer,
    private http: HttpClient,
    private router: Router,
    private parentService: ParentService
  ) {
    this.loadActivitySvgData();
  }

  loadActivitySvgData() {
    this.http
      .get('assets/JsonFile/activityIcon.json')
      .subscribe((data: any) => {
        this.activity['telugu'] = this.sanitizer.bypassSecurityTrustHtml(
          data.telugu
        );
      });
  }

  scrollAmount: number = 100;
  scrollContainer(direction: 'left' | 'right'): void {
    const container = document.querySelector('.activity_icons');
    if (container) {
      container.scrollLeft +=
        direction === 'left' ? -this.scrollAmount : this.scrollAmount;
    }
  }

  navigateToActivity(activity: string) {
    const role = localStorage.getItem('role');

    if (role === 'PARENT') {
      localStorage.setItem('currentActivity', activity);
      this.parentService.setCurrentNavItem('activitywithteacher');
      
    } else {
      this.router.navigate(['/activityWithTeacher'], {
        queryParams: { Activity: activity, class: activity },
      });
    }
  }
}
