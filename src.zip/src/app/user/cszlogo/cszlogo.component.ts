import { Component } from '@angular/core';

@Component({
  selector: 'app-cszlogo',
  standalone: true,
  imports: [],
  templateUrl: './cszlogo.component.html',
  styleUrl: './cszlogo.component.scss'
})
export class CszlogoComponent {

}
