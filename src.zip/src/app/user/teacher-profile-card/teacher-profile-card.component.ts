import { ChangeDetectorRef, Component, OnDestroy } from '@angular/core';
import { HeaderComponent } from '../../login-register/header/header.component';
import { ActivatedRoute, Router } from '@angular/router';
import { UserServiceService } from '../service/user-service.service';
import { MatIconModule } from '@angular/material/icon';
import { NgFor, NgIf } from '@angular/common';
import { MatTabsModule } from '@angular/material/tabs';
import Swal from 'sweetalert2';
import { DatePipe } from '@angular/common';
import { TeacherProfile } from '../model/teacher-profile';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatCardModule } from '@angular/material/card';
import { MatNativeDateModule } from '@angular/material/core';
import { CalendarModule } from 'primeng/calendar';
import { FormsModule } from '@angular/forms';
import { ParentService } from '../../parent/service/parent.service';
import { Subscription, catchError, throwError } from 'rxjs';
import { CookieService } from 'ngx-cookie-service';
@Component({
  selector: 'app-teacher-profile-card',
  standalone: true,
  templateUrl: './teacher-profile-card.component.html',
  styleUrl: './teacher-profile-card.component.scss',
  imports: [
    HeaderComponent,
    MatIconModule,
    MatCardModule,
    MatNativeDateModule,
    NgFor,
    MatTabsModule,
    NgIf,
    ProgressSpinnerModule,
    NgIf,
    MatProgressSpinnerModule,
    MatDatepickerModule,
    CalendarModule,
    FormsModule,
    DatePipe,
  ],
})
export class TeacherProfileCardComponent implements OnDestroy {
  teacherProfileData: TeacherProfile = new TeacherProfile();
  classWithTeacherID: string = '';
  role: string = '';
  classIdParams: string = '';
  classTeacherData: any = null;
  filterDataLoaded: boolean = false;
  selected: Date | null;
  date: Date[] | undefined;
  selectedDate: Date;
  availableTimeSlots: {
    startTime: string;
    dayAndTimeId: number;
    endTime: string;
  }[] = [];
  classId: number;
  selectedTimeSlotId: number;
  children: any;
  selectedChildId: number | null = null;
  childSelected: boolean = false;
  paramsString: string;
  userTimeZone: string;
  selectedStartTime: string;
  selectedEndTime: string;
  minDate: Date;
  private subscription: Subscription;
  constructor(
    private route: ActivatedRoute,
    private userServiceService: UserServiceService,
    private router: Router,
    private parentService: ParentService,
    private cookieService: CookieService
  ) {
    this.minDate = new Date();
  }

  ngOnInit(): void {
    this.selectedDate = new Date();
    const role = localStorage.getItem('role');
    if (role === 'PARENT') {
      this.getChildDetail();
      const teacherprofilecardid = localStorage.getItem('teacherprofilecardid');
      console.log(teacherprofilecardid, 'teacherprofilecardid');

      if (teacherprofilecardid) {
        this.getTeacherProfileCard(parseInt(teacherprofilecardid, 10));
      }
    } else {
      this.route.queryParams.subscribe((params) => {
        const classId = params['classId'];
        if (classId) {
          this.getTeacherProfileCard(parseInt(classId, 10));
        }
      });
    }
    this.role = localStorage.getItem('role');

    this.route.url.subscribe((segments) => {
      segments.forEach((segment) => {
        if (segment.path === 'classWithTeacher') {
        }
      });
    });

    this.timeZoneChanger();
  }

  timeZoneChanger() {
    const storedTimeZone = localStorage.getItem('timezone');
    if (storedTimeZone === 'IST') {
      this.userTimeZone = 'IST';
    } else if (storedTimeZone === 'Chicago') {
      this.userTimeZone = 'Central Time';
    } else if (storedTimeZone === 'New_York') {
      this.userTimeZone = 'Eastern Time';
    } else if (storedTimeZone === 'Denver') {
      this.userTimeZone = 'Mountain Time';
    } else if (storedTimeZone === 'Los_Angeles') {
      this.userTimeZone = 'Pacific Time';
    } else {
      this.userTimeZone = 'Pacific Time';
    }
  }

  onSelectDate(date: Date | null): void {
    this.selectedDate = date || new Date();
    this.selectedTimeSlotId = null;
    this.selectedChildId = null;
    this.childSelected = false;
    this.loadAvailableTimeSlotsForDay(this.selectedDate);
  }

  selectTimeSlot(timeSlot: any): void {
    this.selectedStartTime = timeSlot.startTime;
    this.selectedEndTime = timeSlot.endTime;
    this.selectedTimeSlotId = timeSlot.dayAndTimeId;
    const scheduleClass = this.teacherProfileData.scheduleClass;
    if (scheduleClass) {
      Object.values(scheduleClass).forEach((classInfo: any) => {
        if (Array.isArray(classInfo.dayAndTimeDTO)) {
          if (
            classInfo.dayAndTimeDTO.some(
              (time: any) => time.dayAndTimeId === this.selectedTimeSlotId
            )
          ) {
            this.classId = classInfo.classId;
          }
        }
      });
    }
  }

  private loadAvailableTimeSlotsForDay(date: Date): void {
    if (!this.teacherProfileData || !this.teacherProfileData.scheduleClass) {
      return;
    }
    const day = this.getDayFromDate(date);
    this.availableTimeSlots = this.getAvailableTimeSlotsForDay(day);
  }

  private getDayFromDate(date: Date): string {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const dayIndex = date.getDay();
    return days[dayIndex];
  }

  private getAvailableTimeSlotsForDay(
    day: string
  ): { startTime: string; dayAndTimeId: number; endTime: string }[] {
    const availableTimeSlots: {
      startTime: string;
      dayAndTimeId: number;
      endTime: string;
    }[] = [];

    const scheduleClass = this.teacherProfileData.scheduleClass;
    if (scheduleClass) {
      Object.entries(scheduleClass).forEach(([key, value]) => {
        if (key === 'day' && Array.isArray(value) && value.includes(day)) {
          const dayAndTimeDTO = scheduleClass.dayAndTimeDTO;
          if (Array.isArray(dayAndTimeDTO)) {
            dayAndTimeDTO.forEach((timeSlot) => {
              if (timeSlot.day === day) {
                const endTime = timeSlot.endTime
                availableTimeSlots.push({
                  startTime: timeSlot.startTime,
                  dayAndTimeId: timeSlot.dayAndTimeId,
                  endTime: endTime,
                });
              }
            });
          }
        }
      });
    }
    return availableTimeSlots;
  }
  getTeacherProfileCard(classId: number, desiredClassId?: number) {
    this.subscription = this.userServiceService
      .getTeacherProfileCard(classId.toString())
      .subscribe({
        next: (response: any) => {
          this.filterDataLoaded = true;
          this.teacherProfileData = response;
          console.log('Teacher profile card data', this.teacherProfileData);
          if (desiredClassId !== undefined && response.scheduleClass) {
            const scheduleClass = response.scheduleClass;
            for (const day in scheduleClass) {
              if (Object.prototype.hasOwnProperty.call(scheduleClass, day)) {
                const classInfo = scheduleClass[day];
                if (typeof classInfo === 'object' && classInfo.dayAndTimeDTO) {
                  const selectedClass = classInfo.dayAndTimeDTO.find(
                    (timeSlot: any) => timeSlot.classId === desiredClassId
                  );
                  if (selectedClass) {
                    this.classId = selectedClass.classId;
                    break;
                  }
                }
              }
            }
          }
          this.loadAvailableTimeSlotsForDay(this.selectedDate);
        },
        error: (error) => {
          console.error('Error fetching teacher profile:', error);
        },
      });
  }

  checkRole(classId: number) {
    console.log('check role class id', classId);

    console.log(this.selectedStartTime);
    console.log(this.selectedEndTime);
    const responseData = this.teacherProfileData.scheduleClass
    const selectedAgeGroup = Array.isArray(responseData.ageGroup) ? responseData.ageGroup : [responseData.ageGroup];
    const classTypeSelected = Array.isArray(responseData.classType) ? responseData.classType : [responseData.classType];
    const ageGroupOptions = selectedAgeGroup.map(group => `<option value="${group}">${group}</option>`).join('');
    const classTypeOptions = classTypeSelected.map(type => `<option value="${type}">${type}</option>`).join('');

    if (!this.selectedTimeSlotId && this.availableTimeSlots.length > 0) {
      Swal.fire({
        title: 'Please select a time slot',
        icon: 'warning',
        confirmButtonText: 'OK',
      });
      return;
    }

    if (this.role === 'PARENT' && !this.selectedChildId) {
      Swal.fire({
        title: 'Please select a child to enroll',
        icon: 'warning',
        confirmButtonText: 'OK',
      });
      return;
    }

    // Prompt for enrollment confirmation
    Swal.fire({
      // title: 'Are you sure you want to enroll in the class?',
      title: 'Confirming your enrollment in the class?',
      icon: 'question',
      showCancelButton: true,
      html: `
      <div>
        <label for="ageGroup-select">Age Group:</label> <br>
      <select id="ageGroup-select" class="swal2-input"swal2-input" style="width: 50%; padding: 5px; border-radius: 5px; border: 2px solid #ccc; margin-bottom: 20px;">
        ${ageGroupOptions}
      </select>
      <br/>
      </div>
      <div>
        <label for="classType-select">Class Type:</label> <br>
      <select id="classType-select" class="swal2-input" style="width: 50%; padding: 5px; border-radius: 5px; border: 2px solid #ccc; margin-bottom: 20px;">
         ${classTypeOptions}
      </select>
      </div>
    `,
      confirmButtonText: 'Yes, enroll',
      cancelButtonText: 'No, cancel',
      preConfirm: () => {
        const ageSelected = (document.getElementById('ageGroup-select') as HTMLSelectElement).value;
        const classSelected = (document.getElementById('classType-select') as HTMLSelectElement).value;
        if (!ageSelected || !classSelected) {
          Swal.showValidationMessage('Please select both age group and class type');
        }
        return { ageSelected, classSelected };
      }
    }).then((result) => {
      if (result.isConfirmed && result.value) {
        const { ageSelected, classSelected } = result.value;

        // Prepare payload for enrollment
        const studentId = localStorage.getItem('id');
        const formattedStartDate = this.formatDate(this.selectedDate);


        const enrollmentPayload = {
          studentInfo: { id: this.selectedChildId },
          activeClass: { id: this.teacherProfileData.scheduleClass.classId },
          dayAndTime: { id: this.selectedTimeSlotId },
          studentStartDate: formattedStartDate,
          studentEndDate: formattedStartDate,
          enable: true,
          studentStartTime: this.selectedStartTime,
          studentEndTime: this.selectedEndTime,
          ageGroup:ageSelected,
          classType:classSelected,
        };
        // Send enrollment request
        this.paymentPost(enrollmentPayload);
        this.reset();
      }
    });

    if (!this.role) {
      Swal.fire({
        title: 'To join Sign in or Register',
        icon: 'info',
        showCloseButton: true,
        showCancelButton: true,
        confirmButtonText: 'Go to Register',
        cancelButtonText: 'Sign In',
      }).then((result) => {
        if (result.isConfirmed) {
          this.router.navigate(['/login-reg/toregistration']);
        } else if (result.dismiss === Swal.DismissReason.cancel) {
          console.log('login ku pocha ?');

          this.router.navigate(['/login-reg/login']);
        }
      });
    } else if (this.role === 'STUDENT') {
      const age = localStorage.getItem('age');
      const ageNumber = parseFloat(age);
      if (ageNumber >= 18) {
        Swal.fire({
          // title: 'Are you sure you want to enroll in the class?',
          title: 'Confirming your enrollment in the class?',
          icon: 'question',
          showCancelButton: true,
          confirmButtonText: 'Yes, enroll',
          cancelButtonText: 'No, cancel',
        }).then((result) => {
          if (result.isConfirmed) {
            const StudentID = localStorage.getItem('id');
            const selectedDate = this.selectedDate;
            const formattedStartDate = this.formatDate(selectedDate);
            const studenObject = {
              studentInfo: {
                id: StudentID,
              },
              activeClass: {
                // id: classId,
                id: this.teacherProfileData.scheduleClass.classId,
              },
              dayAndTime: {
                id: this.selectedTimeSlotId,
              },
              studentStartDate: formattedStartDate,
              studentEndDate: formattedStartDate,
              enable: true,
              studentStartTime: this.selectedStartTime,
              studentEndTime: this.selectedEndTime,


            };
            this.paymentPost(studenObject);
            this.reset();
          } else {
          }
        });
      } else {
        Swal.fire({
          title: 'Confirming your enrollment in the class?',
          text: 'It will be notified to your parent',
          icon: 'question',
          showCancelButton: true,
          confirmButtonText: 'Yes, enroll',
          cancelButtonText: 'No, Cancel',
        }).then((result) => {
          if (result.isConfirmed) {
            const StudentID = localStorage.getItem('id');
            const selectedDate = this.selectedDate;
            const formattedStartDate = this.formatDate(selectedDate);
            const studenObjects = {
              studentInfo: {
                id: StudentID,
              },
              activeClass: {
                // id: classId,
                id: this.teacherProfileData.scheduleClass.classId,
              },
              dayAndTime: {
                id: this.selectedTimeSlotId,
              },
              studentStartDate: formattedStartDate,
              studentEndDate: formattedStartDate,
              enable: false,
              studentStartTime: this.selectedStartTime,
              studentEndTime: this.selectedEndTime,
            };
            this.paymentPost(studenObjects);
            this.reset();
          } else {
          }
        });
      }
    }
  }

  paymentPost(object: any) {
    this.userServiceService.paymentPostTrigger(object).subscribe({
      next: (response) => {
        console.log(response);

        if (response === 'Already Enroll') {
          Swal.fire({
            title: 'You have already enrolled',
            text: 'Please select other classes',
            timer: 1000,
            timerProgressBar: false,
            icon: 'info',
            showConfirmButton: false,
          });
        } else {
          Swal.fire({
            title:
              'Allset! You will receive confirmation within 1 business day ',
            icon: 'info',
            confirmButtonText: 'Ok',
          });
        }
      },
      error: (error) => {},
    });
  }

  formatDate(date: Date): string {
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear();
    return `${year}-${month}-${day}`;
  }

  getChildDetail() {
    const parentId = localStorage.getItem('id');
    if (parentId) {
      this.parentService.getData(parentId).subscribe(
        (response) => {
          console.log(response);
          this.children = response.child;
          console.log(this.children, '222222222222222');
        },
        (error) => {
          console.error('Error fetching child details:', error);
        }
      );
    } else {
      console.error('Parent ID not found in localStorage');
    }
  }

  selectChild(childId: number) {
    this.selectedChildId = childId;
    this.childSelected = true;
  }

  isLoggedIn(): boolean {
    return localStorage.getItem('role') !== null;
  }

  reset() {
    this.selectedTimeSlotId = null;
    this.selectedChildId = null;
  }

  ngOnDestroy(): void {
    if (localStorage.length === 0) {
      this.route.queryParams.subscribe((params) => {
        const teacherId = params['classId'];
        this.paramsString = teacherId;
      });
      this.cookieService.set('route', 'teacherProfileCard');
      this.cookieService.set('params', this.paramsString);
    } else {
    }
    if (this.subscription) {
      this.subscription.unsubscribe();
      console.log('unsubsribed');
    }
  }

  showParentProfile() {
    this.parentService.setCurrentNavItem('Profile');
  }
}
