import { NgFor, NgIf } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import Swal from 'sweetalert2';
import { UserServiceService } from '../../service/user-service.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { StringArray } from 'aws-sdk/clients/rdsdataservice';

@Component({
  selector: 'app-parent-enroll',
  standalone: true,
  imports: [
    MatIconModule,
    FormsModule,
    ReactiveFormsModule,
    NgIf,
    NgFor,
    MatButtonModule,
    HttpClientModule,
  ],
  templateUrl: './parent-enroll.component.html',
  styleUrl: './parent-enroll.component.scss',
  providers: [HttpClient, UserServiceService],
})
export class ParentEnrollComponent {
  objectData = {
    childArray: [],
    ageGroup: [] as string | string[],
      classType: [] as string | string[],
  };
  selectedUser: string;
  classTypeSelected: string;
  ageGroupSelected: string;
  isAgeGroupString: boolean = false;
  isClassTypeString: boolean = false;
  objectToPass;
  day: string;
  startTime: string;
typeof: any;

  constructor(
    public dialogRef: MatDialogRef<ParentEnrollComponent>,

    @Inject(MAT_DIALOG_DATA) public data: any,
    private userServiceService: UserServiceService
  ) {
    console.log(data, '0000000000000');
    this.objectData = data || {
      childArray: [],
      ageGroup: [] as string | string[],
      classType: [] as string | string[],
    };
    this.objectToPass ={...data};
    this.isAgeGroupString = typeof this.objectData.ageGroup === 'string';
    this.isClassTypeString = typeof this.objectData.classType === 'string';
    this.day = data.day;
    this.startTime = data.startTime;

  }

  ngOnInit(): void {
    console.log(this.selectedUser);
  }

  onCloseClick(): void {
    this.dialogRef.close();
  }

  submitForm() {
    console.log('Selected User:', this.selectedUser);
    // You can perform further actions here
    console.log(this.objectToPass, 'checking');

    delete this.objectToPass.childArray;
    delete this.objectToPass.day;

    // delete this.objectToPass.startTime;


    this.objectToPass.studentInfo.id = this.selectedUser;
    if (typeof this.objectData.ageGroup === 'string') {
      this.objectToPass.ageGroup = this.objectData.ageGroup;
    } else if (Array.isArray(this.objectData.ageGroup)) {
      this.objectToPass.ageGroup = this.ageGroupSelected;
    }

    // Handle classType
    if (typeof this.objectData.classType === 'string') {
      this.objectToPass.classType = this.objectData.classType;
    } else if (Array.isArray(this.objectData.classType)) {
      this.objectToPass.classType = this.classTypeSelected;
    }



    this.paymentPost(this.objectToPass, this.day, this.startTime);
  }

  paymentPost(object: any, day: string, startTime: string) {
    this.userServiceService.paymentPostTrigger(object).subscribe({
      next: (response) => {
        console.log(object);
        console.log(response);
        if (response === 'Already Enrolled') {
          Swal.fire({
            title: 'You have already enrolled',
            text: 'Please select other classes',
            timer: 2000,
            timerProgressBar: false,
            icon: 'info',
            showConfirmButton: false,
          });
        } else {
          Swal.fire({
            title: 'Admin will contact you',
            icon: 'info',
            confirmButtonText: 'Ok',
          });
        }

        this.onCloseClick();
      },
      error: (error) => {},
    });
  }


}
