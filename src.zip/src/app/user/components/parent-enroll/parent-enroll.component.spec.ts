import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParentEnrollComponent } from './parent-enroll.component';

describe('ParentEnrollComponent', () => {
  let component: ParentEnrollComponent;
  let fixture: ComponentFixture<ParentEnrollComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ParentEnrollComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ParentEnrollComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
