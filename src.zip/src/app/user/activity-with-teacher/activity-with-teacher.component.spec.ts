import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivityWithTeacherComponent } from './activity-with-teacher.component';

describe('ActivityWithTeacherComponent', () => {
  let component: ActivityWithTeacherComponent;
  let fixture: ComponentFixture<ActivityWithTeacherComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ActivityWithTeacherComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ActivityWithTeacherComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
