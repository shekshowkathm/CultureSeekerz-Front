import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnDestroy,
} from '@angular/core';
import { HeaderComponent } from '../../login-register/header/header.component';
import { MatIconModule } from '@angular/material/icon';
import { NgFor, NgIf, ViewportScroller } from '@angular/common';
import { RouterModule } from '@angular/router';
import { StyleClassModule } from 'primeng/styleclass';
import { CarouselModule } from 'primeng/carousel';
import { trigger, style, transition, animate } from '@angular/animations';
import { ActivatedRoute, Router } from '@angular/router';
import { UserServiceService } from '../service/user-service.service';
import { SearchModel } from '../model/search-model';
import { FormsModule } from '@angular/forms';
import { ParentService } from '../../parent/service/parent.service';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';
import Swal from 'sweetalert2';
import { SharedService } from '../service/shared.service';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { TrialClass } from '../model/trial-class';
import { CookieService } from 'ngx-cookie-service';
import { ParentEnrollComponent } from '../components/parent-enroll/parent-enroll.component';
import { MatDialog } from '@angular/material/dialog';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-activity-with-teacher',
  standalone: true,
  imports: [
    HeaderComponent,
    MatIconModule,
    NgIf,
    NgFor,
    CarouselModule,
    StyleClassModule,
    RouterModule,
    FormsModule,
    ProgressSpinnerModule,
  ],
  templateUrl: './activity-with-teacher.component.html',
  styleUrl: './activity-with-teacher.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [
    trigger('slide', [
      transition('* => left', [
        style({ transform: 'translateX(100%)' }),
        animate('300ms ease-out', style({ transform: 'translateX(0)' })),
      ]),
      transition('* => right', [
        style({ transform: 'translateX(-100%)' }),
        animate('300ms ease-out', style({ transform: 'translateX(0)' })),
      ]),
    ]),
  ],
})
export class ActivityWithTeacherComponent implements OnDestroy {
  activityNameParams: string = '';
  activityData: TrialClass[] = [];
  classSearchData: TrialClass[] = [];
  filteringActive: boolean = false;
  searchModel: SearchModel = new SearchModel();
  emptyArrayData: boolean = true;
  role: string = '';
  activity: { [key: string]: SafeHtml } = {};
  showFullDescription: boolean[] = [];
  filterDataLoaded: boolean = false;
  selectedDays: {
    [classId: number]: { day: string; startTime: string } | null;
  } = {};
  weekDays: { day: string; date: number }[] = [];

  currentDate: Date = new Date();
  childDataid: number;
  selectedValueReset: any = {
    day: 'Day',
    skillLevel: 'Skill Level',
    cost: 'Cost',
    cos: 'Class Type',
    co: 'Age Group',
    availableTime: 'Available Time (In IST)',
  };
  public parentsDetailsAndChild: any;
  childDataButton: boolean[] = [];
  childTrialDataButton: boolean[] = [];
  teacher: any;
  selectedDate: { [classId: number]: number | null } = {};
  userTimeZone: string;
  isNormalDestroy: boolean = true;
  private subscription: Subscription;
  ageGroup: string | string[] = [];
  classType: string | string[] = [];
  selectedAgeGroup: any;
  selectedClassType: any;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private userServiceService: UserServiceService,
    private cdr: ChangeDetectorRef,
    private parentService: ParentService,
    private sanitizer: DomSanitizer,
    private http: HttpClient,
    private sharedService: SharedService,
    private ParentService: ParentService,
    private cookieService: CookieService,
    public dialog: MatDialog,
    private viewportScroller: ViewportScroller
  ) {
    this.loadActivitySvgData();
  }

  ngOnInit(): void {
    this.role = localStorage.getItem('role');
    if (this.role === 'PARENT') {
      const cuurrentActivity = localStorage.getItem('currentActivity');
      this.activityNameParams = cuurrentActivity;
      this.getData();
    } else {
      this.route.queryParams.subscribe((params) => {
        this.activityNameParams = params['Activity'];
      });
    }
    this.getActivityWithTeacher();
    /**
     * enroll
     */
    this.role = localStorage.getItem('role');
    this.route.url.subscribe((segments) => {
      segments.forEach((segment) => {
        if (segment.path === 'classWithTeacher') {
        }
      });
    });
    this.calculateWeekDays();
    const mondayIndex = this.weekDays.findIndex((day) => day.day === 'Mon');
    if (mondayIndex !== -1) {
      this.selectDate(this.teacher, this.weekDays[mondayIndex].date);
    }
    this.timeZoneChanger();
  }

  timeZoneChanger() {
    const storedTimeZone = localStorage.getItem('timezone');
    if (storedTimeZone === 'IST') {
      this.userTimeZone = 'IST';
    } else if (storedTimeZone === 'Chicago') {
      this.userTimeZone = 'Central Time';
    } else if (storedTimeZone === 'New_York') {
      this.userTimeZone = 'Eastern Time';
    } else if (storedTimeZone === 'Denver') {
      this.userTimeZone = 'Mountain Time';
    } else if (storedTimeZone === 'Los_Angeles') {
      this.userTimeZone = 'Pacific Time';
    } else {
      this.userTimeZone = 'Pacific Time';
    }
  }

  /**
   * svg icon get from json folder
   */
  loadActivitySvgData() {
    this.http
      .get('assets/JsonFile/activityIcon.json')
      .subscribe((data: any) => {
        this.activity['bible'] = this.sanitizer.bypassSecurityTrustHtml(
          data.bible
        );
        this.activity['carnatic'] = this.sanitizer.bypassSecurityTrustHtml(
          data.carnatic
        );
        this.activity['sloga'] = this.sanitizer.bypassSecurityTrustHtml(
          data.sloga
        );
        this.activity['chess'] = this.sanitizer.bypassSecurityTrustHtml(
          data.chess
        );
        this.activity['programming'] = this.sanitizer.bypassSecurityTrustHtml(
          data.programming
        );
        this.activity['maths'] = this.sanitizer.bypassSecurityTrustHtml(
          data.maths
        );
        this.activity['science'] = this.sanitizer.bypassSecurityTrustHtml(
          data.science
        );
        this.activity['telugu1'] = this.sanitizer.bypassSecurityTrustHtml(
          data.telugu1
        );
        this.activity['yoga'] = this.sanitizer.bypassSecurityTrustHtml(
          data.yoga
        );
        this.activity['Mridangam'] = this.sanitizer.bypassSecurityTrustHtml(
          data.Mridangam
        );
        this.activity['Hindi'] = this.sanitizer.bypassSecurityTrustHtml(
          data.Hindi
        );
      });
  }

  toggleTime(classId: number, day: string, date: number) {
    console.log('Selected day', day);
    const startTimes = this.getStartTimes(this.teacher, day);
    if (startTimes.length === 0) {
      console.log('No available times for', day);
    }
    if (this.selectedDays[classId] && this.selectedDays[classId].day === day) {
      this.selectedDays[classId] = null;
      this.selectedDate[classId] = null;
    } else {
      this.selectedDays[classId] = { day: day, startTime: null };
      this.selectedDate[classId] = date;
      this.selectDate(this.teacher, date);
    }
  }

  selectDate(teacher: any, date: number) {
    if (teacher && teacher.scheduleClass) {
      const classId = teacher.scheduleClass.classId;
      const day = this.weekDays.find((day) => day.date === date);
      if (day) {
        this.toggleTime(classId, day.day, date);
      }
    }
  }

  isSelectedDate(teacher: any, date: number): boolean {
    return (
      teacher &&
      teacher.scheduleClass &&
      this.selectedDate[teacher.scheduleClass.classId] === date
    );
  }

  selectStartTime(
    teacher: any,
    day: string,
    startTime: string,
    dayAndTimeId: number,
    endTime: string,
    classType?: string | string[],
    ageGroup?: string | string[]
  ) {
    console.log(classType, ageGroup, 'jjjjjjjjjjjjjj');

    const selectedDate = this.getSelectedDate(day);
    const formattedDate = this.formatDate(selectedDate);
    this.selectedDays[teacher.scheduleClass.classId] = {
      day: day,
      startTime: startTime,
    };
    this.checkRole(
      teacher.scheduleClass.classId,
      event,
      day,
      startTime,
      dayAndTimeId,
      formattedDate,
      endTime,
      classType,
      ageGroup
    );
  }

  getSelectedDate(day: string): Date {
    const currentDate = new Date();
    const dayIndex = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(
      day
    );
    const dayDifference = dayIndex - currentDate.getDay();
    const selectedDate = new Date(
      currentDate.getFullYear(),
      currentDate.getMonth(),
      currentDate.getDate() + dayDifference
    );
    return selectedDate;
  }

  formatDate(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    // return `${year}-${month}-${day}`;
    return `${year}-${month}-${day}`;
  }

  isSelectedDay(teacher: any, day: string): boolean {
    return (
      teacher.scheduleClass &&
      this.selectedDays[teacher.scheduleClass.classId]?.day === day
    );
  }

  isSelectedTime(teacher: any, day: string, startTime: string): boolean {
    const selectedDay = this.selectedDays[teacher.scheduleClass.classId];
    return (
      selectedDay &&
      selectedDay.day === day &&
      selectedDay.startTime === startTime
    );
  }

  getStartTimes(
    teacher: any,
    day: string
  ): {
    day: string;
    startTime: string;
    dayAndTimeId: number;
    endTime: string;
  }[] {
    if (
      teacher &&
      teacher.scheduleClass &&
      teacher.scheduleClass.dayAndTimeDTO
    ) {
      const filteredDTO = teacher.scheduleClass.dayAndTimeDTO.filter(
        (dto) => dto.day === day
      );
      const startTimes = filteredDTO.map((dto) => {
        console.log('DayAndTime ID:', dto.dayAndTimeId);
        return {
          day: day,
          startTime: dto.startTime,
          dayAndTimeId: dto.dayAndTimeId,
          endTime: dto.endTime,
        };
      });
      return startTimes;
    } else {
      return [];
    }
  }

  confirmEnrollment(
    teacher: any,
    day: string,
    startTime: string,
    dayAndTimeId: number,
    formattedDate
  ) {
    Swal.fire({
      title: 'Confirming your enrollment in the class?',
      showCancelButton: true,
      confirmButtonText: 'Yes, enroll',
      cancelButtonText: 'No, cancel',
      reverseButtons: true,
      icon: 'question',
      preConfirm: () => {
        // this.paymentPost(teacher.scheduleClass, day, startTime);
        this.checkRole(
          teacher.scheduleClass.classId,
          null,
          day,
          startTime,
          dayAndTimeId,
          formattedDate,
          '',
          this.classType,
          this.ageGroup
        );
      },
    });
  }

  /**
   * get activity with teacher
   */
  getActivityWithTeacher() {
    this.subscription = this.userServiceService
      .activityWithTeacher(this.activityNameParams)
      .subscribe({
        next: (response) => {
          this.teacher = response;
          //  console.log("teacher data " , this.teacher)
          this.activityData = response;
          this.filterDataLoaded = true;
          if (Array.isArray(response) && response.length === 0) {
            this.emptyArrayData = false;
          }
          this.cdr.detectChanges();
        },
        error: (error) => {},
      });
  }

  getFullDayName(abbreviation: string): string {
    const daysMap: { [key: string]: string } = {
      Mon: 'Monday',
      Tue: 'Tuesday',
      Wed: 'Wednesday',
      Thu: 'Thursday',
      Fri: 'Friday',
      Sat: 'Saturday',
      Sun: 'Sunday',
    };
    return daysMap[abbreviation] || '';
  }

  getDescriptionContent(description: string, index: number): string {
    if (this.showFullDescription && this.showFullDescription[index]) {
      return description;
    } else {
      return description.slice(0, 200) + '...';
    }
  }

  toggleDescription(index: number): void {
    if (this.showFullDescription) {
      this.showFullDescription[index] = !this.showFullDescription[index];
    }
  }

  playDemoVideo(videoUrl: string, event: Event) {
    event.stopPropagation();
    if (videoUrl) {
      window.open(videoUrl, '_blank');
    }
  }

  navigateToTeacherProfileClasses(classId: number) {
    const role = localStorage.getItem('role');
    console.log('ClassId', classId);
    if (role === 'PARENT') {
      localStorage.setItem('teacherprofilecardid', classId.toString());
      this.parentService.setCurrentNavItem('teacherprofilecard');
      this.viewportScroller.scrollToPosition([0, 0]);
    } else {
      this.router.navigate(['/teacherProfileCard'], {
        queryParams: { classId: classId.toString() },
      });
      this.viewportScroller.scrollToPosition([0, 0]);
    }
  }

  /**
   * @param event
   * @param field search
   */
  handleInputChange(event: any, field: string) {
    this.filterDataLoaded = false;
    this.filteringActive = true;
    const selectedValue = event.target.value;

    if (
      selectedValue !== 'Age Group' &&
      selectedValue !== 'Skill Level' &&
      selectedValue !== 'Class Type' &&
      selectedValue !== 'Day' &&
      selectedValue !== 'Available Time (In IST)'
    ) {
      this.searchModel[field] = selectedValue;
      if (selectedValue !== 'Age Group' && selectedValue !== 'Class Type') {
        this.searchModel[field] = selectedValue;
        this.classSearch();

        if (field === 'ageGroup') {
          this.selectedAgeGroup = selectedValue;
          console.log(this.selectedAgeGroup, 'age group varauthu');
        } else if (field === 'classType') {
          this.selectedClassType = selectedValue;
          console.log(this.selectedClassType, 'classType varuthu');

          console.log(
            this.selectedClassType,
            this.selectedAgeGroup,
            'filter value varutha'
          );
        }

        this.cdr.detectChanges();
      } else {
        this.resetFilters();
        this.cdr.detectChanges();
      }
    }
  }

  resetFilters() {
    this.selectedValueReset = {
      day: 'Day',
      skillLevel: 'Skill Level',
      cost: 'Cost',
      cos: 'Class Type',
      co: 'Age Group',
      availableTime: 'Available Time (In IST)',
      activity: 'Activity',
    };

    this.searchModel = {
      day: null,
      skillLevel: '',
      classType: '',
      ageGroup: '',
      availableTime: null,
      activity: '',
      timeZone: '',
    };
    this.filteringActive = false;
    this.classSearchData = [];
    this.emptyArrayData = true;
    this.cdr.detectChanges();
    this.classSearch();
    this.getActivityWithTeacher();
  }

  classSearch() {
    const getTimeZone = localStorage.getItem('timezone') || 'Los_Angeles';
    this.searchModel.timeZone ||= getTimeZone;
    const fieldsToCheck = [
      'day',
      'skillLevel',
      'classType',
      'ageGroup',
      'availableTime',
      'activity',
    ];
    fieldsToCheck.forEach((field) => {
      if (!this.searchModel[field]) {
        if (field === 'activity') {
          this.searchModel[field] = this.activityNameParams;
        } else {
          this.searchModel[field] = null;
        }
      }
    });
    if (this.filteringActive) {
      this.userServiceService
        .activityWithClassSearch(this.searchModel)
        .subscribe({
          next: (response) => {
            this.emptyArrayData = true;
            this.classSearchData = response;
            this.filterDataLoaded = true;
            if (Array.isArray(response) && response.length === 0) {
              this.emptyArrayData = false;
            }
            this.cdr.detectChanges();
          },
          error: (error) => {},
        });
    } else {
      this.classSearchData = [];
      this.cdr.detectChanges();
    }
  }

  navigateToClassWithTeacher(teacherId: string) {
    const role = localStorage.getItem('role');
    if (role === 'PARENT') {
      this.parentService.setclassWithTeacherID(teacherId);
      this.parentService.setCurrentNavItem('classwithteacher');
    } else {
      this.router.navigate(['/teacherProfileCard'], {
        queryParams: { teacherId: teacherId },
      });
    }
  }

  /**
   * Enroll function
   */
  getData() {
    const id = localStorage.getItem('id');
    this.ParentService.getData(id).subscribe({
      next: (response) => {
        this.parentsDetailsAndChild = response;
      },
      error: (error) => {
        console.error('Error:', error);
      },
    });
  }

  childAddButton(index: number) {
    this.childDataButton[index] = !this.childDataButton[index];
  }

  childAddTrialButton(index: number) {
    this.childTrialDataButton[index] = !this.childTrialDataButton[index];
  }

  checkRole(
    classId,
    event: Event,
    day: string,
    startTime: string,
    dayAndTimeId,
    formattedDate: string,
    endTime: string,
    classType: string | string[],
    ageGroup: string | string[]
  ) {
    // event.preventDefault();
    // event.stopPropagation();
    // if (event) {
    //   event.preventDefault();
    //   event.stopPropagation();
    // }
    console.log('check role triggered');
    console.log(endTime);

    if (this.role === 'PARENT') {
      const studenObject = {
        studentInfo: {
          id: '',
        },
        activeClass: {
          id: classId,
        },
        dayAndTime: {
          id: dayAndTimeId,
        },
        enable: true,
        studentStartDate: formattedDate,
        studentEndDate: formattedDate,
        childArray: this.parentsDetailsAndChild.child,
        day: day,
        studentStartTime: startTime,
        studentEndTime: endTime,
        classType: this.selectedClassType || classType,
        ageGroup: this.selectedAgeGroup || ageGroup,
      };
      const dialogRef = this.dialog.open(ParentEnrollComponent, {
        width: 'auto',
        height: 'auto',
        data: studenObject,
      });

      dialogRef.afterClosed().subscribe((result) => {
        console.log(studenObject, 'paren');
        console.log('The dialog was closed');
      });
      //   Swal.fire({
      //     title: 'Are you sure you want to enroll in the class?',
      //     html: `
      //     <select id="childSelect" class="form-control">
      //         <option value="" disabled selected>Select a child</option>
      //         ${this.parentsDetailsAndChild.child
      //           .map(
      //             (child) =>
      //               `<option value="${child.id}">${child.firstName} ${child.lastName}</option>`
      //           )
      //           .join('')}
      //     </select>
      // `,
      //     icon: 'question',
      //     showCancelButton: true,
      //     confirmButtonText: 'Yes, enroll it',
      //     cancelButtonText: 'No, cancel',
      //   }).then((result) => {
      //     if (result.isConfirmed) {
      //       const selectedChildId = (
      //         document.getElementById('childSelect') as HTMLSelectElement
      //       ).value;
      //       const selectedChild = this.parentsDetailsAndChild.child.find(
      //         (child) => child.id === parseInt(selectedChildId)
      //       );

      //       if (!selectedChildId) {
      //         Swal.fire({
      //           icon: 'error',
      //           title: 'Oops...',
      //           text: 'Please select a child to enroll.',
      //         });
      //         return;
      //       } else {
      //         const studenObject = {
      //           studentInfo: {
      //             id: selectedChildId,
      //           },
      //           activeClass: {
      //             id: classId,
      //           },
      //           dayAndTime: {
      //             id: dayAndTimeId,
      //           },
      //           enable: true,
      //           studentStartDate: formattedDate,
      //           studentEndDate: formattedDate,
      //         };
      //         this.paymentPost(studenObject, day, startTime);
      //       }

      //     } else {
      //       console.log('Enrollment canceled.');
      //     }
      //   });
    } else if (!this.role) {
      Swal.fire({
        icon: 'info',
        title: 'To join  this class you need to sign in / register',
        showCloseButton: true,
        showCancelButton: true,
        confirmButtonText: 'Go to register',
        cancelButtonText: 'Sign in',
        reverseButtons: true,
      }).then((result) => {
        if (result.isConfirmed) {
          // Redirect to register page
          this.router.navigate(['/login-reg/toregistration']);
        } else if (result.dismiss === Swal.DismissReason.cancel) {
          // Redirect to login page
          this.router.navigate(['/login']);
        }
        this.isNormalDestroy = false;
        console.log('save cuurent teacher routing');
        console.log(classId);
        this.saveParticularTeacherRouting(classId);
      });
    } else if (this.role === 'STUDENT') {
      const age = localStorage.getItem('age');
      const ageNumber = parseFloat(age);
      if (ageNumber >= 18) {
        Swal.fire({
          title: 'Confirming your enrollment in the class?',
          icon: 'question',
          showCancelButton: true,
          confirmButtonText: 'Yes, enroll',
          cancelButtonText: 'No, cancel',
        }).then((result) => {
          if (result.isConfirmed) {
            const StudentID = localStorage.getItem('id');
            const studenObject = {
              studentInfo: {
                id: StudentID,
              },
              activeClass: {
                id: classId,
              },

              // enable: true,

              dayAndTime: {
                id: dayAndTimeId,
              },
              enable: true,
              studentStartDate: formattedDate,
              studentEndDate: formattedDate,
              studentStartTime: startTime,
              studentEndTime: endTime,
              classType: classType || this.selectedClassType,
              ageGroup: ageGroup || this.selectedAgeGroup,
            };
            // this.paymentPost(studenObject);
            this.paymentPost(studenObject, day, startTime);
          } else {
          }
        });
      } else {
        Swal.fire({
          title: 'Confirming your enrollment in the class?',
          text: 'It will be notified to your parent',
          icon: 'question',
          showCancelButton: true,
          confirmButtonText: 'Yes, enroll',
          cancelButtonText: 'Cancel',
        }).then((result) => {
          if (result.isConfirmed) {
            const StudentID = localStorage.getItem('id');
            const studenObjects = {
              studentInfo: {
                id: StudentID,
              },
              activeClass: {
                id: classId,
              },

              dayAndTime: {
                id: dayAndTimeId,
              },
              studentStartDate: formattedDate,
              studentEndDate: formattedDate,

              enable: false,
              studentStartTime: startTime,
              studentEndTime: endTime,
              classType: '',
              ageGroup: '',
            };
            this.paymentPost(studenObjects, day, startTime);
          } else {
          }
        });
      }
    }
  }

  paymentPost(object: any, day: string, startTime: string) {
    this.userServiceService.paymentPostTrigger(object).subscribe({
      next: (response) => {
        console.log(response);

        if (response === 'Already Enrolled') {
          Swal.fire({
            title: 'You have already enrolled',
            text: 'Please select other classes',
            timer: 1000,
            timerProgressBar: false,
            icon: 'info',
            showConfirmButton: false,
          });
        } else {
          Swal.fire({
            title:
              'Allset! You will receive confirmation within 1 business day ',
            icon: 'info',
            confirmButtonText: 'Ok',
          });
        }
      },
      error: (error) => {},
    });
  }

  /**
   * book a free trial
   */
  triggerFreeDemo(teacherObj, childData): void {
    event.preventDefault();
    event.stopPropagation();
    const teacher = teacherObj;
    if (teacher && teacher.teacherResponse.trailClass) {
      const storedUsername = localStorage.getItem('username');
      Swal.fire({
        title: 'Please provide your email or username',
        input: 'text',
        inputValue: storedUsername,
        inputPlaceholder: 'Enter your email',
        showCloseButton: true,
        showCancelButton: false,
        confirmButtonText: 'Send Email',
        cancelButtonText: 'Sign in',
        showLoaderOnConfirm: true,
        preConfirm: (email) => {
          if (!email) {
            Swal.showValidationMessage('Email is required');
          } else {
            this.sendMail(email, teacher, childData);
          }
        },
      }).then((result) => {
        if (result.isConfirmed) {
          // Redirect to register page
        } else if (result.dismiss === Swal.DismissReason.cancel) {
          // Redirect to login page
          this.router.navigate(['/login']);
        }
      });
    } else {
    }
  }
  sendMail(email: string, teacher: any, childData) {
    console.log(teacher);

    if (this.isEmailValid(email)) {
      const object = {
        requestEmail: email,
        teacherName: teacher.teacherResponse.name,
        teacherEmail: teacher.teacherResponse.email,
        teacherPhoneNumber: '',
        activity: teacher.scheduleClass.activity,
        userName: childData.email,
        // teacherId: teacher.teacherId,
        classId: teacher.classId,
        teacherUniqueId: teacher.teacherResponse.teacherUniqueId,
      };
      this.userServiceService.sendEmail(object).subscribe({
        next: (response) => {
          Swal.fire(
            'Thank you for your request!',
            'Allset! You will receive confirmation within 1 business day ',
            'success'
          );
        },
        error: (error) => {
          Swal.fire('Error!', 'Failed to send email.', 'error');
        },
      });
    } else {
      console.log('Child username pa');

      const object = {
        requestEmail: null,
        teacherName: teacher.teacherResponse.name,
        teacherEmail: teacher.teacherResponse.email,
        teacherPhoneNumber: '',
        activity: teacher.scheduleClass.activity,
        userName: email,
        // teacherId: teacher.teacherId,
        classId: teacher.classId,
        teacherUniqueId: teacher.scheduleClass.classUniqueId,
      };
      this.userServiceService.sendEmail(object).subscribe({
        next: (response) => {
          Swal.fire(
            'Thank you for your request!',
            'Allset! You will receive confirmation within 1 business day ',
            'success'
          );
        },
        error: (error) => {
          Swal.fire('Error!', 'Failed to send email.', 'error');
        },
      });
    }
  }

  isEmailValid(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  formatDays(days: string[]): string {
    return this.sharedService.getAbbreviatedDays(days);
  }

  activePopupIndex: number = -1;

  togglePopup(index: number, show: boolean) {
    if (show) {
      this.activePopupIndex = index;
    } else {
      this.activePopupIndex = -1;
    }
  }

  ngOnDestroy(): void {
    console.log('ng destroy');

    if (localStorage.length === 0 && this.isNormalDestroy) {
      this.route.queryParams.subscribe((params) => {
        const activityWithTeacher = params['Activity'];
        this.activityNameParams = activityWithTeacher;
        const classParam = params['class'];
        const queryString = `activityWithTeacher?Activity=${activityWithTeacher}&class=${classParam}`;
      });
      this.cookieService.set('route', 'activityWithTeacher');
      this.cookieService.set('params', this.activityNameParams);
    } else {
    }
    if (this.subscription) {
      this.subscription.unsubscribe();
      console.log('unsubsribed');
    }
  }

  calculateWeekDays() {
    const currentDate = new Date();
    const currentDay = currentDate.getDay();
    const weekDaysOrder = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    const startDate = new Date(currentDate);
    startDate.setDate(currentDate.getDate() - currentDay);

    this.weekDays = [];

    for (let i = 0; i < 7; i++) {
      const nextDate = new Date(startDate);
      nextDate.setDate(startDate.getDate() + i);
      const dayName = weekDaysOrder[nextDate.getDay()];
      this.weekDays.push({ day: dayName, date: nextDate.getDate() });
    }
  }

  getDayName(dayIndex: number): string {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    return days[dayIndex];
  }

  saveParticularTeacherRouting(classId) {
    console.log('is it teacher class routing saved ?');

    this.cookieService.set('route', 'teacherProfileCard');
    this.cookieService.set('params', classId);

    /****
     *
     * this.route.queryParams.subscribe((params) => {
        const teacherId = params['classId'];
        this.paramsString = teacherId;
      });
      this.cookieService.set('route', 'teacherProfileCard');
      this.cookieService.set('params', this.paramsString);
     *
     * **/
  }
}
