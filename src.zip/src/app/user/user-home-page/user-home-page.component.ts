import { Component, OnDestroy} from '@angular/core';
import { HeaderComponent } from '../../login-register/header/header.component';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { ActivityComponent } from '../activity/activity.component';
import { Router, RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { NgFor, NgIf } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FooterComponent } from "../../login-register/components/footer/footer.component";
import { UserServiceService } from '../service/user-service.service';
import { SharedService } from '../service/shared.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-user-home-page',
  standalone: true,
  imports: [HeaderComponent, ActivityComponent, NgFor, MatIconModule, RouterModule,NgIf,FooterComponent],
  templateUrl: './user-home-page.component.html',
  styleUrl: './user-home-page.component.scss',
  animations: [
    trigger('imageSlide', [
      state('start', style({ transform: 'translateX(0)' })),
      state('end', style({ transform: 'translateX(-100%)' })),
      transition('start <=> end', animate('1s ease-out'))
    ])
  ]
})
export class UserHomePageComponent implements OnDestroy {
  currentImageIndex: number = 0;
  animationState: string = 'start';
  svgData: { [key: string]: SafeHtml } = {};
  getTeacherData: any[] = [];
  descriptionText: any;
  showFullDescription: boolean[] = [];
  highestFees: string[] = [];
  role: string = '';
  private subscription: Subscription;
  constructor(private http: HttpClient, private UserServiceService: UserServiceService, private sanitizer: DomSanitizer , private sharedService : SharedService,private router :Router) { this.loadSvgData() }
  ngOnDestroy(): void {
      if (this.subscription) {
        this.subscription.unsubscribe();
        console.log('unsubsribed');
      }
  }
  ngOnInit(): void {
    this.getAllTeacherData();
    this.startSlideshow();
    this.checkLocalStorage();
  }
  loadSvgData() {
    this.http.get('assets/JsonFile/svgIcon.json').subscribe((data: any) => {
      this.svgData['customIcon1'] = this.sanitizer.bypassSecurityTrustHtml(data.customIcon1);
      this.svgData['customIcon2'] = this.sanitizer.bypassSecurityTrustHtml(data.customIcon2);
      this.svgData['customIcon3'] = this.sanitizer.bypassSecurityTrustHtml(data.customIcon3);
      this.svgData['customIcon4'] = this.sanitizer.bypassSecurityTrustHtml(data.customIcon4);
      this.svgData['customIcon5'] = this.sanitizer.bypassSecurityTrustHtml(data.customIcon5);
      this.svgData['customIcon6'] = this.sanitizer.bypassSecurityTrustHtml(data.customIcon6);
      this.svgData['customIcon7'] = this.sanitizer.bypassSecurityTrustHtml(data.customIcon7);
      this.svgData['customIcon8'] = this.sanitizer.bypassSecurityTrustHtml(data.customIcon8);
    });
  }
  images: string[] = [
    'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/CZImage2.webp',
    'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/CZImage3.webp',
    'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/CZImage1.webp',
  ];
  startSlideshow(): void {
    setInterval(() => {
      this.showNextImage();
    }, 10000);
  }
  showNextImage(): void {
    this.animationState = 'end';
    setTimeout(() => {
      this.currentImageIndex = (this.currentImageIndex + 1) % this.images.length;
      this.animationState = 'start';
    }, 1000);
  }
  selectImage(index: number): void {
    this.animationState = 'end';
    setTimeout(() => {
      this.currentImageIndex = index;
      this.animationState = 'start';
    }, 1000);
  }
  getAllTeacherData() {
    console.log("heyyyy im coming");
    this.subscription = this.UserServiceService.homeTeacherGet().subscribe({
      next:(response) => {
        this.getTeacherData = response;
      },
      error:(error) => {
      }
  });
  }
  truncateText(text: string, characters: number): string {
    if (text.length <= characters) {
      return text;
    }
    const truncatedText = text.slice(0, characters);
    return truncatedText + '...';
  }
  toggleDescription(index: number) {
    this.showFullDescription[index] = !this.showFullDescription[index];
  }
  getDescriptionContent(description: string, index: number): string {
    if (!description) {
      return '';
    }
    return this.showFullDescription[index] ? description : this.truncateText(description, 140);
  }
  formatDays(days: string[]): string {
    return this.sharedService.getAbbreviatedDays(days);
  }
  checkLocalStorage(): void {
    const localRole = localStorage.getItem('role');
    if (!localRole) {
      console.log('Local storage is empty');
    } else {
      console.log('Local storage is not empty');
      this.role = localStorage.getItem('role');
      if (this.role === 'PARENT') {
        this.router.navigate(['/parent/parent']);
      }
      else if (this.role === 'STUDENT') {
        this.router.navigate(['/studenthome']);
      }
      else if (this.role === 'TEACHER') {
        this.router.navigate(['/teacher/home']);
      }
    }
  }
}
