import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClassWithTeacherComponent } from './class-with-teacher.component';

describe('ClassWithTeacherComponent', () => {
  let component: ClassWithTeacherComponent;
  let fixture: ComponentFixture<ClassWithTeacherComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ClassWithTeacherComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ClassWithTeacherComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
