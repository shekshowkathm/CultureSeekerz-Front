import { Component, OnDestroy } from '@angular/core';
import { HeaderComponent } from '../../login-register/header/header.component';
import { UserServiceService } from '../service/user-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { NgFor, NgIf } from '@angular/common';
import Swal from 'sweetalert2';
import { ParentService } from '../../parent/service/parent.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-class-with-teacher',
  standalone: true,
  imports: [HeaderComponent, MatIconModule, NgFor, NgIf],
  templateUrl: './class-with-teacher.component.html',
  styleUrl: './class-with-teacher.component.scss',
})
export class ClassWithTeacherComponent implements OnDestroy {
  classIdParams: string = '';
  classTeacherData: any = null;
  role: string = '';

  classWithTeacherID: string = '';
  private subscription: Subscription;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private parentService: ParentService,
    private userServiceService: UserServiceService
  ) {}
  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
      console.log('unsubsribed');
    }
  }

  ngOnInit(): void {
    const role = localStorage.getItem('role');
    if (role === 'PARENT') {
      this.classWithTeacherID = this.parentService.classwithTeacherID;
      this.classIdParams = this.parentService.classwithTeacherID;
    } else {
      this.route.queryParams.subscribe((params) => {
        this.classIdParams = params['teacherId'];
      });
    }

    this.getClassWithTeacher();
    this.role = localStorage.getItem('role');
    this.route.url.subscribe((segments) => {
      segments.forEach((segment) => {
        if (segment.path === 'classWithTeacher') {
        }
      });
    });
  }
  getClassWithTeacher() {
    this.subscription = this.userServiceService.getClassWithTeacher(this.classIdParams).subscribe({
      next: (response) => {
        this.classTeacherData = response;
      },
      error: (error) => {
      }
  });
  }
  checkRole() {
    if (this.role === 'PARENT') {
      Swal.fire({
        title: 'Are you sure you want to enroll in the class?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, enroll it',
        cancelButtonText: 'No, cancel',
      }).then((result) => {
        if (result.isConfirmed) {
          Swal.fire({
            title: 'Our admin will contact you',
            icon: 'info',
            confirmButtonText: 'Ok',
          });
        } else {
        }
      });
    } else if (!this.role) {
      Swal.fire({
        title: 'To register for this class you need to register',
        icon: 'info',
        showCancelButton: true,
        confirmButtonText: 'Go to Register',
        cancelButtonText: 'Cancel',
      }).then((result) => {
        if (result.isConfirmed) {
          this.router.navigate(['/login-reg/toregistration']);
        } else {
        }
      });
    } else if (this.role === 'STUDENT') {
      const age = localStorage.getItem('age');
      const ageNumber = parseFloat(age);
      if (ageNumber >= 18) {
        Swal.fire({
          title: 'Are you sure you want to enroll in the class?',
          icon: 'question',
          showCancelButton: true,
          confirmButtonText: 'Yes, enroll it',
          cancelButtonText: 'No, cancel',
        }).then((result) => {
          if (result.isConfirmed) {
            const StudentID = localStorage.getItem('id');
            const studenObject = {
              studentInfo: {
                id: StudentID,
              },
              activeClass: {
                id: this.classTeacherData.classId,
              },
              enable: true,
            };
            this.paymentPost(studenObject);
          } else {
          }
        });
      } else {
        Swal.fire({
          title: 'Do you want to enroll in this class?',
          text: 'It will be notified to your parent',
          icon: 'question',
          showCancelButton: true,
          confirmButtonText: 'Ok, enroll it',
          cancelButtonText: 'Cancel',
        }).then((result) => {
          if (result.isConfirmed) {
            const StudentID = localStorage.getItem('id');
            const studenObjects = {
              studentInfo: {
                id: StudentID,
              },
              activeClass: {
                id: this.classTeacherData.classId,
              },
              enable: false,
            };
            this.paymentPost(studenObjects);
          } else {
          }
        });
      }
    }
  }

  paymentPost(object: any) {
    this.userServiceService.paymentPostTrigger(object).subscribe({
     next: (response) => {
        Swal.fire({
          title: 'Our admin will contact you',
          icon: 'info',
          confirmButtonText: 'Ok',
        });
      },
      error: (error) => {
      }
  });
  }
}
