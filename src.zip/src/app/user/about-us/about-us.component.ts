import { Component } from '@angular/core';
import { HeaderComponent } from '../../login-register/header/header.component';
import { FooterComponent } from '../../login-register/components/footer/footer.component';
import { NgIf } from '@angular/common';
import { ProgressSpinnerModule } from 'primeng/progressspinner';

@Component({
  selector: 'app-about-us',
  standalone: true,
  imports: [HeaderComponent,FooterComponent,NgIf,ProgressSpinnerModule],
  templateUrl: './about-us.component.html',
  styleUrl: './about-us.component.scss'
})
export class AboutUsComponent {
  imageLoaded: boolean = false;

  constructor() {
  }
  ngOnInit() {
    this.loadImage();
  }
  loadImage() {
    const img = new Image();
    img.onload = () => {
      this.imageLoaded = true;
    };
    img.src = "https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/media/svgviewer-output (1).svg";
  }
}
