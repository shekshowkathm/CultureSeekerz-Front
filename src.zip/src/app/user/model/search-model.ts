export class SearchModel {
  day: string|null;
  availableTime:string|null;
  skillLevel:string| null;
  classType: string|null;
  ageGroup:string|null;
  activity: string | null = null;
  timeZone: string;
}
