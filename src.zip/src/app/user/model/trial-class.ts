import { ScheduleClass } from "../../teacher-module/modelClass/schedule-class";

// age group class kg & elementary , middle school and high school class
export class TrialClass {
    teacherId : number ;
    teacherResponse : TeacherResponse
    scheduleClass : ScheduleClass
    classId: number ;
    specializedIn: string[];
}

export class TeacherResponse{
     name : string;
     email : string ;
     dob : string ;
     gender : string ;
     experience : string ;
     specializedIn : string[];
     additionalQualification : string ;
     mode : string ;
     profile : string ;
     about : string ;
     trailClass : boolean ;
     teacherId : number ;
     scheduleClass? : null ;
     b_Ed : boolean ;
     ug : string ;
     pg : string ;
     m_Ed : boolean;
     teacherUniqueId : string
}

export class BookTrial {
    name : string ;
    email : string ;
    activity : string;
    dob : string ;
    gender : string ;
    experience : string ;
    specializedIn : string [] ;
    additionalQualification : string ;
    mode : string ;
    profile : string ;
    about : string ;
    trialClass : boolean ;
    teacherId : number ;
    scheduleClass : ScheduleClass;
    b_Ed : boolean ;
    ug : string ;
    pg : string ;
    m_Ed : boolean ;
    teacherResponse : TeacherResponse
}

export class FeedbackUpdate{
  id: number;
  teacherName: string;
  teacherEmail: string;
  activity: string;
  meetingLink: string | null;
  time: Date | null;
  date: Date | null;
  requestEmail: string;
  userName: string;
  teacherId: number;
  feedback: string;
  liked: any;
  disliked: any;
}

