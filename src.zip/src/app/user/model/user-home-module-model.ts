import { ScheduleClass } from "../../teacher-module/modelClass/schedule-class";

export class UserHomeModuleModel {
    about: string = ''; 
    additionalQualification: string = ''; 
    b_Ed: boolean = false; 
    dob: string = ''; 
    email: string = ''; 
    experience: string = ''; 
    gender: string = ''; 
    m_Ed: boolean = false; 
    mode: string = ''; 
    name: string = ''; 
    pg: string = ''; 
    profile: string = ''; 
    scheduleClass: ScheduleClass[] = [];
    specializedIn: string[] = []; 
    teacherId: number = 0; 
    trailClass: boolean = false;
    ug: string = ''; 
}
