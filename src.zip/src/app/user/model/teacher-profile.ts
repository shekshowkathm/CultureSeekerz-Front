import { ScheduleClass } from "../../teacher-module/modelClass/schedule-class";
import { TeacherResponse } from "./trial-class";

export class TeacherProfile {
      name : string = '';
      email : string = '';
      dob : string = '';
      gender : string = '';
      experience : string = '';
      specializedIn : string = '';
      additionalQualification : string = '';
      mode : string = '';
      profile : string = '';
      about : string = '';
      trailClass : boolean = false;
      teacherId: number = 0;
      scheduleClass: ScheduleClass;
      teacherResponse : TeacherResponse;
      b_Ed: boolean = false;
      ug: string = '';
      pg: string = '';
      m_Ed: boolean = false;
}

