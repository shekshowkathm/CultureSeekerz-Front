

export class ManageClass {
    className : string;
    // fees : Fees [] = [] ;
    description : string ;
    demoVideo : string ;
    activity : string ;
    classImage : string ;
    seats : number ;
    availableSeats : number ;
    day : string [];
    classId : number ;
    skilllevel : string ;
    classType : string | string [] = [];;
    ageGroup : string | string [] = [];
    students? : null ;
    approve : boolean ;
    fees : string;
    teacherUniqueId:string
    classUniqueId :string;
    teacher : {
        teacherName : string ;
        teacherEmail : string ;
        teacherProfile : string ;
        teacherPhoneNumber : string ;
        teacherId : number ;
    }
    availableTime : string [];
    studentId : number ;
    studentResponse : {
        studentName : string ;
        studentEmail : string ;
        studentNumber : string ;
        gender : string ;
        age : number ;
        timeZone : string ;
        attendStatus : boolean;

        slotResponse : {
            slotId : number ;
            time : string ;
            meetingLink : string ;
            startDate : string ;
            endDate : string ;
            duration : string ;
        }
        dayAndTime : {
            startTime : string;
            endTime : string;
            meetingLink : string;
        }
        selectedDate : string;
        studentId : number ;
    }
    slotResponse? : null
    isButtonDisabled: boolean = true;

}
