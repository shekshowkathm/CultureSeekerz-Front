export class UserModel {
  activityNameParams!:string;
}
