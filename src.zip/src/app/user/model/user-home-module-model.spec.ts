import { UserHomeModuleModel } from './user-home-module-model';

describe('UserHomeModuleModel', () => {
  it('should create an instance', () => {
    expect(new UserHomeModuleModel()).toBeTruthy();
  });
});
