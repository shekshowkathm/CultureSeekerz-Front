import { TrialClass } from './trial-class';

describe('TrialClass', () => {
  it('should create an instance', () => {
    expect(new TrialClass()).toBeTruthy();
  });
});
