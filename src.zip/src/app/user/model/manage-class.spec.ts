import { ManageClass } from './manage-class';

describe('ManageClass', () => {
  it('should create an instance', () => {
    expect(new ManageClass()).toBeTruthy();
  });
});
