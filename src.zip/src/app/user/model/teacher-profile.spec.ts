import { TeacherProfile } from './teacher-profile';

describe('TeacherProfile', () => {
  it('should create an instance', () => {
    expect(new TeacherProfile()).toBeTruthy();
  });
});
