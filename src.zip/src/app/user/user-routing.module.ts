import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ActivityComponent } from './activity/activity.component';
import { ActivityWithTeacherComponent } from './activity-with-teacher/activity-with-teacher.component';
import { CszlogoComponent } from './cszlogo/cszlogo.component';
import { TeacherProfileCardComponent } from './teacher-profile-card/teacher-profile-card.component';
import { ClassWithTeacherComponent } from './class-with-teacher/class-with-teacher.component';
import { StudentManageClassComponent } from './student-manage-class/student-manage-class.component';
import { UserHomePageComponent } from './user-home-page/user-home-page.component';
import { TrailClassComponent } from './trail-class/trail-class.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { routeAuthGuard } from '../route-guard/route-auth.guard';
import { CalendarSchedulerComponent } from './calendar/calendar-scheduler/calendar-scheduler.component';

const routes: Routes = [
  {
    path: '',
    component: UserHomePageComponent,
    data: { allowedRoles: ['userAndStudentPage'] },
    canActivate: [routeAuthGuard],
  },
  {
    path: 'studenthome',
    component: UserHomePageComponent,
    data: { allowedRoles: ['userAndStudentPage'] },
    canActivate: [routeAuthGuard],
    pathMatch: 'full',
  },
  { path: 'activity', component: ActivityComponent },
  {
    path: 'activityWithTeacher',
    component: ActivityWithTeacherComponent,
    data: { allowedRoles: ['userAndStudentPage'] },
    canActivate: [routeAuthGuard],
  },
  {
    path: 'trailclass',
    component: TrailClassComponent,
    data: { allowedRoles: ['userAndStudentPage'] },
    canActivate: [routeAuthGuard],
  },
  { path: 'appheader', component: CszlogoComponent },
  {
    path: 'teacherProfileCard',
    component: TeacherProfileCardComponent,
    data: { allowedRoles: ['userAndStudentPage'] },
    canActivate: [routeAuthGuard],
  },
  {
    path: 'classWithTeacher',
    component: ClassWithTeacherComponent,
    data: { allowedRoles: ['userAndStudentPage'] },
    canActivate: [routeAuthGuard],
  },
  {
    path: 'manageclass',
    component: StudentManageClassComponent,
    data: { allowedRoles: ['STUDENT'] },
    canActivate: [routeAuthGuard],
  },
  { path: 'aboutus', component: AboutUsComponent },
  { path: 'calendarscheduler', component: CalendarSchedulerComponent },
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class UserRoutingModule {}
