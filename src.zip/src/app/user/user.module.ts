import { CUSTOM_ELEMENTS_SCHEMA, LOCALE_ID, NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { UserRoutingModule } from './user-routing.module';
import { ActivityComponent } from './activity/activity.component';
import {StyleClassModule} from 'primeng/styleclass';
import { CarouselModule } from 'primeng/carousel';
import { TagModule } from 'primeng/tag';
import { UserServiceService } from './service/user-service.service';
import { LoginRegisterModule } from '../login-register/login-register.module';
import { CalendarModule, DateAdapter, MOMENT } from 'angular-calendar';
import { FormsModule } from '@angular/forms';
// import { FlatpickrModule } from 'angularx-flatpickr';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
import { SchedulerModule } from 'angular-calendar-scheduler';
import moment from 'moment';
import { CalendarService } from './service/calendar.service';
import { SharedService } from './service/shared.service';
import { Child360Service } from '../parent/service/child360.service';




@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    UserRoutingModule,
    LoginRegisterModule,
    ActivityComponent,
    StyleClassModule,
    CarouselModule,
    TagModule,
    FormsModule,
    // FlatpickrModule.forRoot(),
    CalendarModule.forRoot({
      provide: DateAdapter,
      useFactory: adapterFactory,
    }),
    SchedulerModule.forRoot({ locale: 'en', headerDateFormat: 'daysRange' }),
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  exports: [
    ActivityComponent,
  ],
  providers: [
    UserServiceService,
    CalendarService,
    SharedService,
    DatePipe,
    Child360Service,
    { provide: LOCALE_ID, useValue: 'en-US' },
    { provide: MOMENT, useValue: moment }
  ],

})
export class UserModule { }
