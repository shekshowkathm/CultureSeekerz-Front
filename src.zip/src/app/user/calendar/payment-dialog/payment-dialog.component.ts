import { Component, Inject } from '@angular/core';
import { ParentService } from '../../../parent/service/parent.service';
import { StudentData } from '../model/patment-child-data';
import { NgFor, NgIf } from '@angular/common';
import { MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { AllClasspaymentComponent } from '../all-classpayment/all-classpayment.component';

@Component({
  selector: 'app-payment-dialog',
  standalone: true,
  imports: [NgIf, NgFor],
  templateUrl: './payment-dialog.component.html',
  styleUrl: './payment-dialog.component.scss'
})
export class PaymentDialogComponent {

  student: StudentData;

  constructor(
    private parentsService: ParentService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialog: MatDialog
  ){}

  ngOnInit() {
    this. childMonthlyPayment();
  }
  childMonthlyPayment() {
    const id = localStorage.getItem('id');
    this.parentsService.getData(id).subscribe({
      next: (response:StudentData) => {
        this.student = response;
      },
      error: (error) => {
        console.error('Error:', error);
      },
    });
  }

  openAllClasspaymentComponent(childData:{}) {    
    const dialogRef = this.dialog.open(AllClasspaymentComponent, {
      data: childData
    });

    dialogRef.afterClosed().subscribe(result => {
    });
  }
}
