import { Component, Inject } from '@angular/core';
import { CalendarService } from '../../../user/service/calendar.service'
import { Enrollment, MonthlyAmount, PatmentChildData, PaymentHistory } from '../model/patment-child-data';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { NgFor, NgIf } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-all-classpayment',
  standalone: true,
  imports: [NgFor,MatIconModule,NgIf],
  templateUrl: './all-classpayment.component.html',
  styleUrl: './all-classpayment.component.scss'
})
export class AllClasspaymentComponent {
  // allEnrolledClasses: PaymentHistory[] = [];
  allEnrolledClasses: MonthlyAmount = new MonthlyAmount();
  student: any;
  currentMonth: number;
  pastMonths: { number: number, name: string }[] = [];
  selectedMonthName: string;

  constructor(
    private CalendarService: CalendarService,
    public dialogRef: MatDialogRef<AllClasspaymentComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {}
  ){
    this.student = data;
  }

  ngOnInit() {
    this.monthCurrentPast(); 
    this.allChildPayment(this.currentMonth-1);
  }

  monthCurrentPast(){
    const date = new Date();
    this.currentMonth = date.getMonth();
    const monthNames = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul',
      'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    for (let i = 0; i < this.currentMonth; i++) {
      this.pastMonths.push({ number: i + 0, name: monthNames[i] });
    }   
  }
  getMonthName(month: number): string {
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    return monthNames[month];
  }
  allChildPayment(month: number) {
    // const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    // this.selectedMonthName = monthNames[month];
    this.selectedMonthName = this.getMonthName(month-1);
    
    const id = this.student.id
    this.currentMonth = month;
    this.CalendarService.allChildPayment(id,this.currentMonth).subscribe({
      next: (response:MonthlyAmount) => {
        this.allEnrolledClasses = response;
      },
      error: (error) => {
        console.error('Error:', error);
      },
    });
  }
  selectMonth(month: number): void {
    // const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    // this.selectedMonthName = monthNames[month];
    this.selectedMonthName = this.getMonthName(month-1);
    this.allChildPayment(month);
  }
}
