import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllClasspaymentComponent } from './all-classpayment.component';

describe('AllClasspaymentComponent', () => {
  let component: AllClasspaymentComponent;
  let fixture: ComponentFixture<AllClasspaymentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AllClasspaymentComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AllClasspaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
