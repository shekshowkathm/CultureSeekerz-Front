import { CUSTOM_ELEMENTS_SCHEMA, ChangeDetectorRef, Component, ElementRef, Inject, LOCALE_ID, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CalendarView, CalendarDateFormatter,DateAdapter } from 'angular-calendar';
import { CalendarSchedulerEvent, CalendarSchedulerEventAction, CalendarSchedulerViewComponent, DAYS_IN_WEEK, SchedulerDateFormatter, SchedulerEventTimesChangedEvent, SchedulerModule, SchedulerViewDay, SchedulerViewHour, SchedulerViewHourSegment, addPeriod, endOfPeriod, startOfPeriod, subPeriod } from 'angular-calendar-scheduler';
import { addMonths, endOfDay, endOfWeek, startOfWeek, subWeeks } from 'date-fns';
import { Subject } from 'rxjs';
import { CommonModule, NgClass, NgFor, NgIf, NgSwitch, NgSwitchCase } from '@angular/common';
import { CalendarService } from '../../service/calendar.service';
import { SharedService } from '../../service/shared.service';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialog } from '@angular/material/dialog';
import { CalendarEventDialogComponent } from '../calendar-event-dialog/calendar-event-dialog.component';
import { MatNativeDateModule } from '@angular/material/core';
import { HeaderComponent } from '../../../login-register/header/header.component';
import { ActivatedRoute, Router } from '@angular/router';
import { PaymentDialogComponent } from '../payment-dialog/payment-dialog.component';
 
 
@Component({
  selector: 'app-calendar-scheduler',
  standalone: true,
  imports: [HeaderComponent,NgSwitch,NgSwitchCase,FormsModule,NgClass,NgFor,NgIf,CommonModule,SchedulerModule,MatTooltipModule,MatDatepickerModule,MatNativeDateModule ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  templateUrl: './calendar-scheduler.component.html',
  styleUrl: './calendar-scheduler.component.scss',
  providers: [{
    provide: CalendarDateFormatter,
    useClass: SchedulerDateFormatter
  }]
})
export class CalendarSchedulerComponent {
  title = 'Angular Calendar Scheduler Demo';
  CalendarView = CalendarView;
  view: string = 'month';
  // view: CalendarView = CalendarView.Week;
  viewDate: Date = new Date();
  viewDays: number = DAYS_IN_WEEK;
  refresh: Subject<any> = new Subject();
  locale: string = 'en';
  hourSegments: number = 1;
  weekStartsOn: number = 1;
  startsWithToday: boolean = true;
  activeDayIsOpen: boolean = true;
  excludeDays: number[] = []; // [0];
  weekendDays: number[] = [0,6];
  dayStartHour: number = 0;
  dayEndHour: number = 24;
  // minDate: Date = new Date();
  minDate: Date = startOfWeek(subWeeks(new Date(), 20));
  maxDate: Date = endOfDay(addMonths(new Date(), 20));
  dayModifier: Function;
  hourModifier: Function;
  monthModifier: Function;
  segmentModifier: Function;
  eventModifier: Function;
  prevBtnDisabled: boolean = false;
  nextBtnDisabled: boolean = false;
  currentWeekStartDate: Date;
  currentWeekEndDate: Date;
  role: string = '';
  currentChildId: Number; 
 
 
  events: CalendarSchedulerEvent[];
  @ViewChild(CalendarSchedulerViewComponent) calendarScheduler: CalendarSchedulerViewComponent;
  constructor(@Inject(LOCALE_ID) locale: string, private CalendarService: CalendarService, private dateAdapter: DateAdapter,private SharedService: SharedService,private cdr: ChangeDetectorRef, private el: ElementRef, private dialog: MatDialog, private route: ActivatedRoute, private router: Router) {
    this.locale = locale;
 
    this.dayModifier = ((day: SchedulerViewDay): void => {
        if (!this.isDateValid(day.date)) {
            day.cssClass = 'cal-disabled';
        }
    }).bind(this);
 
    this.hourModifier = ((hour: SchedulerViewHour): void => {
        if (!this.isDateValid(hour.date)) {
            hour.cssClass = 'cal-disabled';
        }
    }).bind(this);
 
    this.segmentModifier = ((segment: SchedulerViewHourSegment): void => {
        if (!this.isDateValid(segment.date)) {
            segment.isDisabled = true;
        }
    }).bind(this);
    this.eventModifier = ((event: CalendarSchedulerEvent): void => {
        event.isDisabled = !this.isDateValid(event.start);
        event.isClickable = true;
    }).bind(this);
    this.dateOrViewChanged();
  }
 
  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.currentChildId = params['childId'];
    });
    this.role = localStorage.getItem('role');
    this.currentWeekStartDate = startOfWeek(this.viewDate);
    this.currentWeekEndDate = endOfWeek(this.viewDate);
    if(this.role === 'PARENT' && !this.currentChildId){
      const localStorageID = localStorage.getItem('id');
      this.CalendarService.getEvents(localStorageID, 'PARENT').then((data: any[]) => {
        this.events = data.map((eventData: any) => {            
            const actions = this.createActions(eventData.daysMore, eventData.payment);
            return {
                ...eventData,
                actions: actions
            };
        });
    });
    }else if(this.currentChildId){
      this.toggleActiveForChildData(this.currentChildId)
    }else if(this.role === 'TEACHER'){
      const localStorageID = localStorage.getItem('teacherID');
      this.CalendarService.getEvents(localStorageID, 'TEACHER').then((data: any[]) => {
        this.events = data.map((eventData: any) => {    
            const eventRescheduleStatus = eventData.students.some((student: any) => student.rescheduleStatus);
            const actions = this.createActions(eventData.daysMore, eventRescheduleStatus);
            return {
                ...eventData,
                actions: actions
            };
        });
    });
    }

    this.SharedService.parentDataPass$.subscribe(parentDataPass => {
      this.toggleActiveForParentData(parentDataPass);      
    });
    this.SharedService.childData$.subscribe(childData => {
        this.toggleActiveForChildData(childData);
      }); 
  }
  toggleActiveForParentData(parentDataPass){
    this.CalendarService.getEvents(parentDataPass, 'PARENT').then((data: any[]) => {
      this.events = data.map((eventData: any) => {
        const actions = this.createActions(eventData.daysMore, eventData.payment);
        return {
            ...eventData,
            actions: actions
        };
    });
});
  }
  payment:boolean;
  toggleActiveForChildData(childData){
    
    this.CalendarService.getEvents(childData, 'CHILD').then((data: any[]) => {
        this.events = data.map((eventData: any) => {
          const actions = this.createActions(eventData.daysMore, eventData.payment);
          return {
              ...eventData,
              actions: actions
          };
      });
    });
  }

  activeButton: number = 7;
  dayChangeWise: boolean = false;
  weekChangeWise: boolean = true;
  viewDaysOptionChanged(viewDays: number): void {
    this.calendarScheduler.setViewDays(viewDays);
    this.dayChangeWise = viewDays === 1;
    this.weekChangeWise = viewDays !== 1;
    this.activeButton = viewDays;
  }
 
  changeDate(date: Date): void {
      this.viewDate = date;
      this.dateOrViewChanged();
  }
 
  changeView(view: CalendarView): void {
      this.view = view;
      this.dateOrViewChanged();
  }
 
  dateOrViewChanged(): void {
      if (this.startsWithToday) {
          this.prevBtnDisabled = !this.isDateValid(subPeriod(this.dateAdapter, CalendarView.Day/*this.view*/, this.viewDate, 1));
          this.nextBtnDisabled = !this.isDateValid(addPeriod(this.dateAdapter, CalendarView.Day/*this.view*/, this.viewDate, 1));
      } else {
          this.prevBtnDisabled = !this.isDateValid(endOfPeriod(this.dateAdapter, CalendarView.Day/*this.view*/, subPeriod(this.dateAdapter, CalendarView.Day/*this.view*/, this.viewDate, 1)));
          this.nextBtnDisabled = !this.isDateValid(startOfPeriod(this.dateAdapter, CalendarView.Day/*this.view*/, addPeriod(this.dateAdapter, CalendarView.Day/*this.view*/, this.viewDate, 1)));
      }
 
      if (this.viewDate < this.minDate) {
          this.changeDate(this.minDate);
      } else if (this.viewDate > this.maxDate) {
          this.changeDate(this.maxDate);
      }
  }
 
  private isDateValid(date: Date): boolean {
      return /*isToday(date) ||*/ date >= this.minDate && date <= this.maxDate;
  }
 
  viewDaysChanged(viewDays: number): void {
      this.viewDays = viewDays;
  }
 
  dayHeaderClicked(day: SchedulerViewDay): void {
  }
 
  hourClicked(hour: SchedulerViewHour): void {
  }
 
  segmentClicked(action: string, segment: SchedulerViewHourSegment): void {
  }
 
//   eventClicked(action: string, event: CalendarSchedulerEvent): void {
//     console.log('eventClicked Action', action);
//     console.log('eventClicked Event', event);
// }

  eventTimesChanged({ event, newStart, newEnd }: SchedulerEventTimesChangedEvent): void {
      let ev = this.events.find(e => e.id === event.id);
      ev.start = newStart;
      ev.end = newEnd;
  }

  dialogOpen:boolean = false;
  lastClickedEvent: CalendarSchedulerEvent;
  // eventClicked(action: string, event: CalendarSchedulerEvent): void {
  //   // this.CalendarService.showBrowserNotification('Event Clicked', 'You clicked on an event.');
  //   if (this.lastClickedEvent === event && this.dialogOpen) return;
  //   const dialogRef = this.dialog.open(CalendarEventDialogComponent, {
  //     data: { event },
  //   });
  //   this.lastClickedEvent = event;
  //   this.dialogOpen = true;
  //   dialogRef.afterClosed().subscribe(() => this.dialogOpen = false);
  // }
  eventClicked(action: string, event: CalendarSchedulerEvent): void {    
    // this.CalendarService.showBrowserNotification('Event Clicked', 'You clicked on an event.');
    if (this.lastClickedEvent === event && this.dialogOpen) return;
    
    const dialogRef = this.dialog.open(CalendarEventDialogComponent, {
      hasBackdrop: true, // Enables backdrop
      backdropClass: 'backdrop-class', // Custom class for backdrop if needed
      width: 'auto',
      data: { event },
      closeOnNavigation: true // Closes dialog on navigation
    });
    this.lastClickedEvent = event;
    this.dialogOpen = true;
    
    dialogRef.backdropClick().subscribe(() => {
      dialogRef.close();
    });
    
    dialogRef.afterClosed().subscribe(() => this.dialogOpen = false);
  }
createActions(daysMore: string, payment: boolean): CalendarSchedulerEventAction[] {
  const whenValu = payment ? 'enabled' : 'disabled';
  const whenValue = daysMore === null || daysMore === 'Expired' || daysMore === 'Yet to pay' || daysMore === '-'  || daysMore === undefined ? 'disabled' : 'enabled';
  return [
      {
          when: whenValue,
          label: '<span class="valign-center"><i class="material-icons md-18 md-icon-notifications">notifications</i></span>',
          title: 'Show Reminder',
          cssClass: 'md-icon-notifications',
          onClick: (event: CalendarSchedulerEvent): void => {
              if (event.daysMore) {
                  this.showEventReminder(event);
              }
          }
      },
      {
        when: whenValu,
        label: '<span class="valign-center"><i class="material-icons md-18 md-icon-payment">notifications</i></span>',
        title: 'Show Reminder',
        cssClass: 'md-icon-payment',
        onClick: (event: CalendarSchedulerEvent): void => {
            if (event.daysMore) {
                this.showEventReminder(event);
            }
        }
      }
  ];
}
showEventReminder(event: CalendarSchedulerEvent): void {
  const dialogRef = this.dialog.open(CalendarEventDialogComponent, {
      data: { event },
  });
}
 
prevAndNextButn: string = 'today';
  navigate(direction: 'prev' | 'next' | 'today', dayChangeWise: boolean): void {
    this.prevAndNextButn = direction;
    const period = dayChangeWise ? CalendarView.Day : CalendarView.Week;
    const newDate = direction === 'prev' ? subPeriod(this.dateAdapter, period, this.viewDate, 1) :
                    direction === 'next' ? addPeriod(this.dateAdapter, period, this.viewDate, 1) :
                    new Date();
 
    this.changeDate(newDate);
    this.currentWeekStartDate = dayChangeWise ? newDate : startOfWeek(newDate);
    this.currentWeekEndDate = dayChangeWise ? newDate : endOfWeek(newDate);
    this.cdr.detectChanges();
  }
 
  onDateInputChange(event: any): void {
    const selectedDate = new Date(event.target.value);
    if (this.isDateValid(selectedDate)) {
      this.currentWeekStartDate = selectedDate;
      this.currentWeekEndDate = endOfWeek(selectedDate);
      this.changeDate(selectedDate);
    }
  }
  showDatePicker = false;
  toggleInput() {
    this.showDatePicker = !this.showDatePicker;
  }


  bookNewClass() {
    this.router.navigate(['/parent/parent']);
  }
  openPaymentDialog() {
    const dialogRef = this.dialog.open(PaymentDialogComponent, {
      data: { /* your data here */ }
    });

    dialogRef.afterClosed().subscribe(result => {
    });
  }
}