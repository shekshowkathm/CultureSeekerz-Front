import { PatmentChildData } from './patment-child-data';

describe('PatmentChildData', () => {
  it('should create an instance', () => {
    expect(new PatmentChildData()).toBeTruthy();
  });
});
