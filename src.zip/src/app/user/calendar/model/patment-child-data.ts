export class PatmentChildData {
        age: number;
        dob: Date | null;
        email: string;
        firstName: string;
        gender: string;
        id: number;
        lastName: string;
        middleName: string;
        mobileNumber: string;
        otp: string | null;
        parentId: number;
        password: string;
        personalId: number;
        role: string;
        status: boolean;
        timeZone: string;
        uniqueId: string; 
}
export class StudentData {
  child: PatmentChildData[];
}

export class Enrollment {
  activeClassId: number;
  activity: string;
  enrolledOn: string;
  fees: string;
  paid: boolean;
  teacherName: string;
}

export interface PaymentHistory {
  activeClassId: number;
  activity: string;
  enrolledOn: string;
  fees: number;
  paid: boolean;
  teacherName: string;
}

export class MonthlyAmount {
  monthlyAmount: number;
  paymentHistory: PaymentHistory[];
}
