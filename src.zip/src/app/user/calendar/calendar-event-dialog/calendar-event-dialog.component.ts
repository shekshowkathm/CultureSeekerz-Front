import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { CalendarSchedulerEvent } from 'angular-calendar-scheduler';
import {
  trigger,
  state,
  style,
  transition,
  animate,
} from '@angular/animations';
import { NgClass, NgFor, NgIf } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import Swal from 'sweetalert2';
import { ParentService } from '../../../parent/service/parent.service';

@Component({
  selector: 'app-calendar-event-dialog',
  standalone: true,
  imports: [NgIf, MatIconModule, NgFor, NgClass],
  templateUrl: './calendar-event-dialog.component.html',
  styleUrl: './calendar-event-dialog.component.scss',
  animations: [
    trigger('fadeInOut', [
      state(
        'void',
        style({
          opacity: 0,
          transform: 'translateY(-20px)',
        })
      ),
      state(
        '*',
        style({
          opacity: 1,
          transform: 'translateY(0)',
        })
      ),
      transition('void => *', animate('0.3s ease-in-out')),
      transition('* => void', animate('0.3s ease-in-out')),
    ]),
  ],
})
export class CalendarEventDialogComponent {
  event: CalendarSchedulerEvent;
  startTime: string;
  endTime: string;
  eventTitle: string;
  title: string;
  Activity: string;
  date: string;
  studentNameRe: { name: string; rescheduleStatus: boolean }[] = [];
  constructor(
    private ParentService: ParentService,
    public dialogRef: MatDialogRef<CalendarEventDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.event = data.event;

    this.startTime = this.event.start.toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    });
    this.endTime = this.event.end.toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    });
    const eventTitle = this.event.title;
    const parts = eventTitle.split(', ');
    this.title = parts[0];
    this.Activity = parts[1];
    this.date = parts[2];
    this.studentNameRe = this.event.students;
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  // joinMeeting(meetinglink: string) {
  //   window.open(meetinglink, '_blank');
  //   const studentId = this.data.event.studentId;
  //   console.log(studentId,"kkkkkkkkkkkkkk");
  //   setTimeout(() => {
  //     this.ParentService.afterMeetingTigger(studentId).subscribe({
  //       next: (response) => {
  //     console.log(studentId,"kkkkkkkkkkkkkk");

  //       },
  //       error: (error) => {
  //         console.error(error);
  //       },
  //     });
  //   },10* 1000); 
  // }

  joinMeeting(meetinglink: string) {
    window.open(meetinglink, '_blank');
    const studentId = this.data.event.studentId;
    const token = localStorage.getItem('token'); 

    if (navigator.serviceWorker && navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'SET_TIMER',
        studentId: studentId,
        token: token,
        delay: 10 * 1000 
      });
    } else {
      console.error('Service worker not available.');
    }
  }

  openSweetAlert() {
    Swal.fire({
      title: 'Reschedule',
      text: 'Do you want to reschedule this event?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, reschedule it!',
      cancelButtonText: 'No, keep it',
    }).then((result) => {
      if (result.isConfirmed) {
        const reschedulestudentId = this.data.event.studentId;
        this.ParentService.reschedulePut(reschedulestudentId).subscribe({
          next: (response) => {},
          error: (error) => {
            console.error(error);
          },
        });
        Swal.fire(
          'Event Rescheduling',
          'An admin will reach out to you shortly to arrange a new date and time for the selected event to be rescheduled.',
          'info'
        );
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire('Cancelled', 'Your event is not rescheduled.', 'error');
      }
    });
  }
}
