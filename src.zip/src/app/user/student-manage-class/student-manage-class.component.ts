import { ChangeDetectorRef, Component, Input, OnDestroy } from '@angular/core';
import { HeaderComponent } from '../../login-register/header/header.component';
import { NgClass, NgFor, NgIf } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { UserServiceService } from '../service/user-service.service';
import { MatTabsModule } from '@angular/material/tabs';
import { MatIconModule } from '@angular/material/icon';
import { SharedService } from '../service/shared.service';
import { ManageClass } from '../model/manage-class';
import { Subscription } from 'rxjs';
import Swal from 'sweetalert2';
import { MatTooltipModule } from '@angular/material/tooltip';
import { Router } from '@angular/router';
import { MatInputModule } from '@angular/material/input';
import { FormBuilder, FormsModule, ReactiveFormsModule, Validators,FormControl } from '@angular/forms';
import { FeedbackUpdate } from '../model/trial-class';
import { ParentService } from '../../parent/service/parent.service';


@Component({
  selector: 'app-student-manage-class',
  standalone: true,
  imports: [
    HeaderComponent,
    NgFor,
    MatButtonModule,
    NgIf,
    NgClass,
    MatTabsModule,
    MatIconModule,
    MatTooltipModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule
  ],
  templateUrl: './student-manage-class.component.html',
  styleUrl: './student-manage-class.component.scss',
})
export class StudentManageClassComponent {
  truePaymentStatusData: ManageClass[] = [];
  falsePaymentStatusData: ManageClass[] = [];
  trueEmptyArrayData: boolean = true;
  trueTrialEmptyArrayData: boolean = true;
  falseEmptyArrayData: boolean = true;
  isStartDateValid: boolean = false;
  manageClassResponse: ManageClass[] = [];
  showFullDescription: boolean[] = [];

  role: string = '';
  emailid: string = '';
  studentId: string = '';
  childId: string = '';
  private subscription: Subscription;
  refreshData: boolean = false;
  trialClassData: any[] = [];
 classData: any[];
 liked: boolean = false;
 disliked : boolean = false
  likeText: string = 'Like';


  @Input() response: any;
  hideFeedback: boolean = false;
  feedbackdetails: any;
  feedbackform: any;
  trialDataObject: FeedbackUpdate;
  trialDataObjects: FeedbackUpdate;
  constructor(
    private userService: UserServiceService,
    private sharedService: SharedService,
    private cdr: ChangeDetectorRef,
    private router: Router,
    private Formbuilder: FormBuilder,
    private parentService: ParentService
  ) {}

  ngOnInit(): void {
    const studentId = localStorage.getItem('id');
    this.getOneParticularManageClass(studentId);
    this.role = localStorage.getItem('role');
    this.emailid = localStorage.getItem('username');
    this.getTrialClasses(this.emailid);

    this.feedbackform = this.Formbuilder.group({
      feedback: ['', [Validators.required,]],
    });

  }

  getOneParticularManageClass(id: any) {
    this.userService.getParticularStudent(id).subscribe({
      next: (response) => {
        this.manageClassResponse = response;

        // this.separateDataByPaymentStatus();
        this.cdr.detectChanges();
        if (this.manageClassResponse.length === 0) {
          this.trueEmptyArrayData = false;
        }
      },
      error: (error) => {},
    });
  }

  // separateDataByPaymentStatus(): void {
  //   this.truePaymentStatusData = this.manageClassResponse.filter(
  //     (item) => item.studentResponse.paymentStatus
  //   );
  //   this.cdr.detectChanges();
  //   if (this.truePaymentStatusData.length === 0) {
  //     this.trueEmptyArrayData = false;
  //   } else {
  //     this.truePaymentStatusData.forEach((item) => {
  //       // this.checkStartDate(item);
  //     });
  //   }
  //   this.falsePaymentStatusData = this.manageClassResponse.filter(
  //     (item) => !item.studentResponse.paymentStatus
  //   );
  //   this.cdr.detectChanges();
  //   if (this.falsePaymentStatusData.length === 0) {
  //     this.falseEmptyArrayData = false;
  //   }
  // }

  // onButtonClick(link: string) {
  //   window.location.href = link;
  // }
  onButtonClick(studentDetails) {
    window.open(studentDetails.dayAndTime.meetingLink, '_blank');
    const studentId = studentDetails.studentId;
    const id = localStorage.getItem('id');
    setTimeout(() => {
      this.parentService.afterMeetingTigger(studentId).subscribe({
        next: (response) => {
          this.getOneParticularManageClass(id);

        },
        error: (error) => {
          console.error(error);
        },
      });
    }, 10 * 1000);
  }

  playDemoVideo(videoUrl: string, event: Event) {
    event.stopPropagation();
    if (videoUrl) {
      window.open(videoUrl, '_blank');
    }
  }

  toggleDescription(index: number, event: Event): void {
    event.preventDefault();
    this.showFullDescription[index] = !this.showFullDescription[index];
    event.stopPropagation();
  }
  formatDay(days: string[]) {
    return this.sharedService.getAbbreviatedDays(days);
  }
  getTrialClasses(studentEmail: string) {
    this.userService.getTrialClass(studentEmail).subscribe({
      next: (response) => {
        this.trialClassData = response;
        // console.log(this.trialClassData,'wdwd');

        if (this.trialClassData.length === 0) {
          this.trueTrialEmptyArrayData = false;
        }
        this.cdr.detectChanges();
      },
      error: (error) => {},
    });
  }
  trialClassLink(link: string) {
    window.location.href = link;
  }

  removeClass(addClasses) {
    console.log(addClasses.studentResponse.studentId);
    Swal.fire({
      title: 'Are you sure you want to delete this class?',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, cancel',
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
    }).then((result) => {
      if (result.isConfirmed) {
        this.deleteMethod(addClasses.studentResponse.studentId);
      }
    });
  }

  deleteMethod(id) {
    this.userService.deleteItem(id).subscribe({
      next: (response) => {
        const studentId = localStorage.getItem('id');
        this.getOneParticularManageClass(studentId);
        this.role = localStorage.getItem('role');
        this.emailid = localStorage.getItem('username');
        this.getTrialClasses(this.emailid);
        this.cdr.detectChanges();
      },
      error: (error) => {},
    });
  }

  goToTeacherProfileCardByID(teacher) {
    console.log(teacher);
    console.log(teacher.classId);
    this.router.navigate(['/teacherProfileCard'], {
      queryParams: { classId: teacher.classId },
    });
  }
//  enable and disable join here
// isTrialClassAvailable(): boolean {
//   const currentDate = new Date(); // Get current date and time

//   const currentDateString = currentDate.toISOString().split('T')[0]; // Extract current date in 'YYYY-MM-DD' format
//   const currentTimeString = `${currentDate.getHours().toString().padStart(2, '0')}:${currentDate.getMinutes().toString().padStart(2, '0')}:${currentDate.getSeconds().toString().padStart(2, '0')}`; // Extract current time in 'HH:MM:SS' format
//   console.log(currentDateString,'current date');
//   console.log(currentTimeString,'current time');


//   // Iterate over trialClassData to find if any trial class matches the conditions
//   for (const trialData of this.trialClassData) {
//     console.log(trialData.date,'response date');

//     if (trialData.date === currentDateString && trialData.time <= currentTimeString) {
//       console.log('I am True');

//       return true; // Return true if conditions are met for any trial class
//     }
//   }
//   console.log('i am false');

//   return false; // Return false if no trial class meets the conditions
// }
// like and dislike
toggleLike(index: number) {
  // Toggle the like state for the item at the specified index
  this.trialClassData[index].liked = !this.trialClassData[index].liked;

}
toggleDislike(index: number) {
  // Toggle the like state for the item at the specified index
  this.trialClassData[index].disliked = !this.trialClassData[index].disliked;

}
hideFeedbackInput(index: number) {
  this.trialClassData[index].disliked = false;
}
handleDislike(index: number) {
  // Check if disliked is true, if yes, set liked to false
  if (this.trialClassData[index].disliked) {
    this.trialClassData[index].liked = false;
  }
}
// submit feedback


submitDislikeFeedback(index: number,trialData:FeedbackUpdate) : void {
  const feedbackvalue =  this.feedbackform.get('feedback').value;
  console.log(feedbackvalue,'ygqygd');
  this.trialDataObject = trialData
  this.trialDataObject.feedback = feedbackvalue;

 this.userService.updatefeedback(this.trialDataObject).subscribe({

    next: (response) => {
      this.feedbackform.reset();
      console.log(trialData);
      console.log(response, 'response');


    },
    error: (error) => {
      console.error(error);
    }
  });

}
addlike(i:number,trialData:FeedbackUpdate):void {
  const addlike =this.feedbackform.get('feedback').setValue('liked');
  this.trialDataObjects = trialData;
  this.trialDataObjects.feedback = addlike;
  this.submitDislikeFeedback(i,this.trialDataObjects);
}

}
