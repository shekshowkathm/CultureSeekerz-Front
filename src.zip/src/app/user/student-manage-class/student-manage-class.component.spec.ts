import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentManageClassComponent } from './student-manage-class.component';

describe('StudentManageClassComponent', () => {
  let component: StudentManageClassComponent;
  let fixture: ComponentFixture<StudentManageClassComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StudentManageClassComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(StudentManageClassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
