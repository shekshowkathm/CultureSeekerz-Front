import { Component } from '@angular/core';
import { HeaderComponent } from '../../login-register/header/header.component';
import { TeacherService } from '../service/teacher-service';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { Teacher } from '../model/teacher.class';

@Component({
  selector: 'app-teacherprofile',
  standalone: true,
  templateUrl: './teacherprofile.component.html',
  styleUrl: './teacherprofile.component.scss',
  imports: [HeaderComponent, CommonModule, MatIconModule],
})
export class TeacherprofileComponent {
  teacherProfile: any;
  getTeacherProfileData: any = {};
  teacher: Teacher;
  constructor(private teacherservice: TeacherService) {}
  ngOnInit(): void {
    
    
    this.getTeacherProfile();
  }

  getTeacherProfile() {
    this.teacherservice.getteacherprofilebyId().subscribe({
      next: (response: any) => {
        // Assuming the response has a 'teacher' property
        this.getTeacherProfileData = response?.teacher;
        this.teacher=response?.teacher;
        console.log(this.teacher);
        
        if (!this.getTeacherProfile) {
          console.error('Teacher profile not found in the response.');
          // Handle the case where the teacher profile is not available in the response
        }
      },
      error: (error) => {
        console.error('Error:', error);
        // Handle error appropriately, show error message to the user, etc.
      }
  });
  }
}
