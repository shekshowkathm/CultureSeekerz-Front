import { TeacherProfile } from './teacher-profile.class';

describe('TeacherProfile', () => {
  it('should create an instance', () => {
    expect(new TeacherProfile()).toBeTruthy();
  });
});
