// import { Fees } from "../modelClass/schedule-class";
import { TeacherDetails } from "./teacher-details.class";

export class PaidClass {
  activity: string;
  ageGroup: string[] = [];
  approve: string;
  availableSeats: string;
  availableTime: any[];
  classId: string;
  classImage: string;
  className: string;
  classType: string;
  day: any[];
  demoVideo: string;
  description: string;
  // fees: Fees [] = [];
  fees:string;
  seats: string;
  skilllevel: string;
  slotResponse: any[];
  studentId: string;
  studentResponse: any;
  students: any[];
  teacher: TeacherDetails;
}
