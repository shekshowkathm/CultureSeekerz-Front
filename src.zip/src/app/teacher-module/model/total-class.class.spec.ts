import { TotalClass } from './total-class.class';

describe('TotalClass', () => {
  it('should create an instance', () => {
    expect(new TotalClass()).toBeTruthy();
  });
});
