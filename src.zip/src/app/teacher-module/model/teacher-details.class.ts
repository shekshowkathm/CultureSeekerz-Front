export class TeacherDetails {
  teacherEmail: string;
  teacherId: string;
  teacherName: string;
  teacherPhoneNumber: string;
  teacherProfile: string;
}
