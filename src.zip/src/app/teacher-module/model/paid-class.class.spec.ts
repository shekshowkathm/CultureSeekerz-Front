import { PaidClass } from './paid-class.class';

describe('PaidClass', () => {
  it('should create an instance', () => {
    expect(new PaidClass()).toBeTruthy();
  });
});
