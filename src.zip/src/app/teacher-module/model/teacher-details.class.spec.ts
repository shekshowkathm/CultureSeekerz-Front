import { TeacherDetails } from './teacher-details.class';

describe('TeacherDetails', () => {
  it('should create an instance', () => {
    expect(new TeacherDetails()).toBeTruthy();
  });
});
