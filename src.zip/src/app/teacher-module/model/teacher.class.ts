import { TeacherProfile } from "./teacher-profile.class";

export class Teacher {
  about: string;
  age: string;
  approve: string;
  b_EdCertificate: string;
  b_EdInstitute: string;
  experienceCertificate: string;
  idProof: string;
  m_EdCertificate: string;
  m_EdInstitute: string;
  mobileNumber: string;
  mode: string;
  pGCertificate: string;
  pGUniversity: string;
  trailclass: string;
  uGCertificate: string;
  uGUniversity: string;
  teacher: TeacherProfile;
}
