
import { TeacherDetails } from "./teacher-details.class";

export class TotalClass {
  activity: string;
  ageGroup: string[] = [];
  approve: string;
  availableSeats: string;
  availableTime: any[];
  classId: string;
  classImage: string;
  className: string;
  classType: string;
  day: any[];
  demoVideo: string;
  description: string;
  fees: string;
  seats: string;
  skilllevel: string;
  slotResponse: any[];
  studentId: string;
  studentResponse: any;
  students: any[];
  teacher: TeacherDetails;
}
