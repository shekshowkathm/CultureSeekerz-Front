import { Teacher } from './teacher.class';

describe('Teacher', () => {
  it('should create an instance', () => {
    expect(new Teacher()).toBeTruthy();
  });
});
