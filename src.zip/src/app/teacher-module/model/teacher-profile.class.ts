export class TeacherProfile {
  about: string;
  additionalQualification: string;
  b_Ed: string;
  dob: string;
  email: string;
  experience: string;
  gender: string;
  m_Ed: string;
  mode: string;
  name: string;
  pg: string;
  profile: string;
  scheduleClass: any[];
  specializedIn: any[];
  teacherId: string;
  trailClass: string;
  ug: string;
}
