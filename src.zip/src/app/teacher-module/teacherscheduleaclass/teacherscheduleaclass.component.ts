import {
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Inject,
  Output,
} from '@angular/core';
import { HeaderComponent } from '../../login-register/header/header.component';
import { MatButtonModule } from '@angular/material/button';
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { CommonModule, DatePipe, NgIf } from '@angular/common';
import { ScheduleClass } from '../modelClass/schedule-class';
import { TeacherService } from '../service/teacher-service';
import { environment } from '../../../environments/environment.development';
import AWSS3UploadAshClient from 'aws-s3-upload-ash';
import { UploadResponse } from 'aws-s3-upload-ash/dist/types';
import { BreakpointObserver } from '@angular/cdk/layout';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectChange, MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { MatCheckboxModule } from '@angular/material/checkbox';
import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogModule,
  MatDialogRef,
} from '@angular/material/dialog';
import Swal from 'sweetalert2';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import {
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
  MAT_NATIVE_DATE_FORMATS,
  MatNativeDateModule,
} from '@angular/material/core';
import { DateAdapter } from 'angular-calendar';

export class DaySchedule {
  startTime: string = '';
  endTime: string = '';
  startDate: string = '';
  endDate: string = '';
  meetingLink: string = '';
}
interface SelectedTimeSlot {
  startTime: string;
  endTime: string;
  startDate: Date | null;
  endDate: Date | null;
}

interface SelectedDay {
  day: string;
  timeSlots: SelectedTimeSlot[];
}

@Component({
  selector: 'app-teachersceduleaclass',
  standalone: true,
  imports: [
    HeaderComponent,
    MatButtonModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    MatFormFieldModule,
    MatSelectModule,
    MatIconModule,
    MatCheckboxModule,
    NgIf,
    MatDialogModule,
    ReactiveFormsModule,
    MatDatepickerModule,
    MatInputModule,
    MatNativeDateModule,
    // MatExpansionModule
  ],
  templateUrl: './teacherscheduleaclass.component.html',
  styleUrl: './teacherscheduleaclass.component.scss',
  providers: [
    DatePipe,
    {
      provide: DateAdapter,
      useClass: MatNativeDateModule,
      deps: [MAT_DATE_LOCALE],
    },
    { provide: MAT_DATE_FORMATS, useValue: MAT_NATIVE_DATE_FORMATS },
    { provide: MatDialogRef, useValue: {} },
    // { provide: MAT_DIALOG_DATA, useValue: {} }
  ],
})
export class TeachersceduleaclassComponent {
  createClass: FormGroup;
  form: FormGroup;
  fileSelected: any = null;
  isDialogMode: boolean = false;
  selectedDays: string[] = [];
  scheduleaClass = new ScheduleClass();
  config = {
    bucketName: 'cultureseekerz-image',
    dirName: 'media',
    region: 'ap-south-1',
    accessKeyId: environment.AWS_ACCESS_KEY,
    secretAccessKey: environment.AWS_SECRET_KEY,
    s3Url: 'https://cultureseekerz-image.s3.ap-south-1.amazonaws.com/',
  };
  S3CustomClient: AWSS3UploadAshClient = new AWSS3UploadAshClient(this.config);
  fileLocation: any;
  public fileLink: any;
  fileSelected1: any;
  fileLocation1: any;
  public fileLink1: any;
  addedFields: { [key: string]: number } = {};
  hours: string[] = [];
  constructor(
    private formbuilder: FormBuilder,
    private addClassService: TeacherService,
    public configure: BreakpointObserver,
    @Inject(MAT_DIALOG_DATA)
    public data: { isDialogMode: boolean; classData: any },
    public dialog: MatDialog,
    private cdr: ChangeDetectorRef,
    public dialogRef: MatDialogRef<TeachersceduleaclassComponent>
  ) {
    this.isDialogMode = data.isDialogMode;
    this.selectedDays = [];
    //   for (let i = 1; i < 24; i++) {
    //     const hour = ('0' + i).slice(-2);
    //     this.hours.push(`${hour}:00`);
    // }

    for (let i = 0; i < 24; i++) {
      const hour = ('0' + i).slice(-2);
      this.hours.push(`${hour}:00`);
      this.hours.push(`${hour}:30`);
    }
    this.hours.push('00:00');
    this.form = this.formbuilder.group({
      chosenDays: this.formbuilder.array([]),
    });
  }

  availableTime: string[] = [];
  lastSelectedDay: string;
  trialclassvalue: boolean = false;
  ngOnInit(): void {
    this.createClass = this.formbuilder.group({
      activity: [this.scheduleaClass.activity, Validators.required],
      ageGroup: [this.scheduleaClass.ageGroup, Validators.required],
      description: [this.scheduleaClass.description, Validators.required],
      classType: [this.scheduleaClass.classType, Validators.required],
      classImage: [this.scheduleaClass.classImage],
      availableDays: [this.scheduleaClass.day, Validators.required],
      feesInr: [this.scheduleaClass.fees, Validators.required],
      teacher: { id: localStorage.getItem('teacherID') },
    });
    /**
     * update method day,time and date
     */
    // const classData = this.data.classData;
    // if (classData.dayAndTimeDTO) {
    //   classData.dayAndTimeDTO.forEach(data => {
    //     this.dayAndTimeData.push(data);
    //   });
    //   this.selectedDayss = classData.day;
    // }
    if (this.data && this.data.classData && this.data.classData.dayAndTimeDTO) {
      const classData = this.data.classData;
      this.createClass = this.formbuilder.group({
        activity: [classData.activity, Validators.required],
        ageGroup: [classData.ageGroup, Validators.required],
        description: [classData.description, Validators.required],
        classType: [classData.classType, Validators.required],
        availableDays: [classData.day, Validators.required],
        feesInr: [classData.fees, Validators.required],
        teacher: { id: localStorage.getItem('teacherID') },
      });
      console.log(this.createClass, 'hhhhhhhhhh');
      let extractedData = classData.dayAndTimeDTO.map((item) => ({
        dayAndTimeId: item.dayAndTimeId,
        day: item.day,
        startTime: item.startTime,
        endTime: item.endTime,
        startDate: item.startDate,
        endDate: item.endDate,
      }));
      console.log(extractedData, 'hhhhhhhhhh11111111111');
      this.update(extractedData);
    }
  }
  /**
   *class image upload
   */
  onclassImage(event: any) {
    if (event.target.files && event.target.files.length > 0) {
      this.fileSelected1 = event.target.files[0];
    } else {
    }
  }
  async handleSendFileclassimg(): Promise<string> {
    try {
      const data: UploadResponse = await this.S3CustomClient.uploadFile(
        this.fileSelected1,
        this.fileSelected1.type,
        undefined,
        this.fileSelected1.name,
        'public-read'
      );
      this.fileLocation = data.location;
      return data.location;
    } catch (err) {
      throw err;
    }
  }
  daysOfWeek = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday',
  ];
  timeslotsAll: [];
  dayChoose: string;
  chosenDaysList: string[] = [];

  get chosenDays(): FormArray {
    return this.form.get('chosenDays') as FormArray;
  }

  private getDayOfWeekNumber(dayName: string): number {
    const daysOfWeek = [
      'Sunday',
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
    ];
    return daysOfWeek.indexOf(dayName);
  }

  mondayFilter = (date: Date | null): boolean =>
    this.dateFilter(date, 'Monday');
  tuesdayFilter = (date: Date | null): boolean =>
    this.dateFilter(date, 'Tuesday');
  wednesdayFilter = (date: Date | null): boolean =>
    this.dateFilter(date, 'Wednesday');
  thursdayFilter = (date: Date | null): boolean =>
    this.dateFilter(date, 'Thursday');
  fridayFilter = (date: Date | null): boolean =>
    this.dateFilter(date, 'Friday');
  saturdayFilter = (date: Date | null): boolean =>
    this.dateFilter(date, 'Saturday');
  sundayFilter = (date: Date | null): boolean =>
    this.dateFilter(date, 'Sunday');

  private dateFilter(date: Date | null, day: string): boolean {
    if (date === null) {
      return false;
    }
    const dayOfWeekNumber = this.getDayOfWeekNumber(day);
    return date.getDay() === dayOfWeekNumber;
  }

  getFilter(day: string): (date: Date | null) => boolean {
    switch (day) {
      case 'Monday':
        return this.mondayFilter;
      case 'Tuesday':
        return this.tuesdayFilter;
      case 'Wednesday':
        return this.wednesdayFilter;
      case 'Thursday':
        return this.thursdayFilter;
      case 'Friday':
        return this.fridayFilter;
      case 'Saturday':
        return this.saturdayFilter;
      case 'Sunday':
        return this.sundayFilter;
      default:
        return () => true;
    }
  }

  addTimeSlot(dayControl: FormGroup | undefined) {
    if (dayControl) {
      const timeSlots = dayControl.get('timeSlots') as FormArray;
      timeSlots.push(
        this.formbuilder.group({
          dayAndTimeId: [''],
          day: [this.dayChoose, Validators.required],
          startTime: ['', Validators.required],
          endTime: ['', Validators.required],
          startDate: [null, Validators.required],
          endDate: [null, Validators.required],
        })
      );
    }
  }

  removeTimeSlot(dayControl: FormGroup | undefined, index: number) {
    if (dayControl) {
      const timeSlots = dayControl.get('timeSlots') as FormArray;
      if (timeSlots.length > index) {
        timeSlots.removeAt(index);
      }
      // Check if timeSlots array is empty after removing the time slot
      if (timeSlots.length === 0) {
        const day = dayControl.get('day')?.value;
        const dayIndex = this.chosenDays.controls.findIndex(
          (control) => control.get('day')?.value === day
        );
        if (dayIndex >= 0) {
          this.chosenDays.removeAt(dayIndex);
        }
        const abbreviatedDay = this.abbreviateDay(day);
        const dayListIndex = this.chosenDaysList.indexOf(abbreviatedDay);
        if (dayListIndex >= 0) {
          this.chosenDaysList.splice(dayListIndex, 1);
        }
      }
    }
  }

  handleDaySelection(day: string, checked: boolean) {
    const abbreviatedDay = this.abbreviateDay(day);
    if (checked) {
      this.chosenDays.push(
        this.formbuilder.group({
          day: new FormControl(day, Validators.required),
          timeSlots: this.formbuilder.array([]),
        })
      );
      this.dayChoose = abbreviatedDay;
      if (!this.chosenDaysList.includes(abbreviatedDay)) {
        this.chosenDaysList.push(abbreviatedDay);
      }
    } else {
      const index = this.chosenDays.controls.findIndex(
        (control) => control.get('day')?.value === day
      );
      if (index >= 0) {
        this.chosenDays.removeAt(index);
      }
      const dayListIndex = this.chosenDaysList.indexOf(abbreviatedDay);
      if (dayListIndex >= 0) {
        this.chosenDaysList.splice(dayListIndex, 1);
      }
    }
  }

  private calculateEndTime(startTime: string): string {
    if (!startTime) return '';
    const [hours, minutes] = startTime.split(':').map(Number);
    const startTimeInMinutes = hours * 60 + minutes;
    const endTimeInMinutes = startTimeInMinutes + 60;
    const endHours = Math.floor(endTimeInMinutes / 60) % 24;
    const endMinutes = endTimeInMinutes % 60;
    return `${String(endHours).padStart(2, '0')}:${String(endMinutes).padStart(
      2,
      '0'
    )}`;
  }

  private calculateEndDate(startDate: Date | null): Date | null {
    if (!startDate) return null;
    const endDate = new Date(startDate);
    endDate.setMonth(endDate.getMonth() + 6);
    return endDate;
  }

  handleStartTimeInput(event: any, dayControl: FormGroup, index: number) {
    const startTime = event.value;
    const timeSlots = dayControl.get('timeSlots') as FormArray;
    if (timeSlots.length > index) {
      const timeSlot = timeSlots.at(index);
      timeSlot.patchValue({
        startTime: startTime || '',
        endTime: startTime
          ? this.calculateEndTime(startTime)
          : timeSlot.get('endTime')?.value,
      });
    }
  }

  handleDateSelectionForDay(event: any, dayControl: FormGroup, index: number) {
    const startDate = event.value;
    const timeSlots = dayControl.get('timeSlots') as FormArray;
    if (timeSlots.length > index) {
      const timeSlot = timeSlots.at(index);
      timeSlot.patchValue({
        startDate: startDate || null,
        endDate: startDate ? this.calculateEndDate(startDate) : null,
      });
    }
  }

  isDaySelected(day: string): boolean {
    return this.chosenDays.controls.some(
      (control) => control.get('day')?.value === day
    );
  }

  getSelectedDay(day: string): FormGroup | undefined {
    return this.chosenDays.controls.find(
      (control) => control.get('day')?.value === day
    ) as FormGroup;
  }

  getTimeSlotControls(day: string): FormArray | null {
    const selectedDay = this.getSelectedDay(day);
    return selectedDay ? (selectedDay.get('timeSlots') as FormArray) : null;
  }

  private formatDate(date: Date | null): string {
    if (!date) return '';
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-based
    const year = date.getFullYear();
    return `${year}-${month}-${day}`;
  }
  private abbreviateDay(day: string): string {
    const dayAbbreviations: { [key: string]: string } = {
      Monday: 'Mon',
      Tuesday: 'Tue',
      Wednesday: 'Wed',
      Thursday: 'Thu',
      Friday: 'Fri',
      Saturday: 'Sat',
      Sunday: 'Sun',
    };
    return dayAbbreviations[day] || day;
  }

  private mapDay(day: string): string {
    const dayMap: { [key: string]: string } = {
      Mon: 'Monday',
      Tue: 'Tuesday',
      Wed: 'Wednesday',
      Thu: 'Thursday',
      Fri: 'Friday',
      Sat: 'Saturday',
      Sun: 'Sunday',
    };
    return dayMap[day] || day;
  }

  classSubmit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      console.log('Form invalid');

      return;
    }
    const allTimeSlots = this.form.value.chosenDays.flatMap((dayGroup: any) => {
      return dayGroup.timeSlots.map((slot: any) => ({
        ...slot,
        day: this.abbreviateDay(dayGroup.day),
        startDate: this.formatDate(slot.startDate),
        endDate: this.formatDate(slot.endDate),
      }));
    });
    this.timeslotsAll = allTimeSlots;
    console.log({ timeSlots: allTimeSlots });
    this.createClass.patchValue({ timeSlots: allTimeSlots });
    console.log(this.createClass.value), 'llllllllllppppppppppppssssssssss';
    console.log('Chosen days list:', this.chosenDaysList);
    const teacherID = localStorage.getItem('teacherID');
    const classvalues = this.createClass.value;
    classvalues['teacher'] = { id: teacherID };
    classvalues['classImage'] = "";
    classvalues['dayAndTime'] = this.timeslotsAll;
    classvalues['day'] = this.chosenDaysList;
    this.addClassService.createclassService(classvalues).subscribe({
      next: (response) => {
        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: 'Your class has been added successfully!',
          confirmButtonText: 'OK',
        });
        this.createClass.reset();
        this.form.reset();
      },
      error: (error) => {},
    });
    // this.handleSendFileclassimg()
    //   .then((fileLocation1) => {
    //     // const teacherID = localStorage.getItem('teacherID');
    //     // const classvalues = this.createClass.value;
    //     // classvalues['teacher'] = { id: teacherID };
    //     // classvalues['classImage'] = fileLocation1;
    //     // classvalues['dayAndTime'] = this.timeslotsAll;
    //     // classvalues['day'] = this.chosenDaysList;
    //     // this.addClassService.createclassService(classvalues).subscribe({
    //     //   next: (response) => {
    //     //     Swal.fire({
    //     //       icon: 'success',
    //     //       title: 'Success',
    //     //       text: 'Your class has been added successfully!',
    //     //       confirmButtonText: 'OK',
    //     //     });
    //     //     this.createClass.reset();
    //     //     this.form.reset();
    //     //   },
    //     //   error: (error) => {},
    //     // });
    //   })
    //   .catch((error) => {});
  }

  private update(responseData: any[]) {
    while (this.chosenDays.length) {
      this.chosenDays.removeAt(0);
    }
    this.chosenDaysList = [];
    const transformedData = responseData.reduce((acc, current) => {
      console.log(current, 'current item in reduce function');
      const day = this.mapDay(current.day);
      const existingDay = acc.find((dayData: any) => dayData.day === day);
      if (existingDay) {
        existingDay.timeSlots.push({
          dayAndTimeId: current.dayAndTimeId,
          startTime: current.startTime,
          endTime: current.endTime,
          startDate: new Date(current.startDate),
          endDate: new Date(current.endDate),
        });
      } else {
        acc.push({
          day,
          timeSlots: [
            {
              dayAndTimeId: current.dayAndTimeId,
              startTime: current.startTime,
              endTime: current.endTime,
              startDate: new Date(current.startDate),
              endDate: new Date(current.endDate),
            },
          ],
        });
      }
      return acc;
    }, []);

    transformedData.forEach((dayData: any) => {
      this.handleDaySelection(dayData.day, true);
      const dayControl = this.getSelectedDay(dayData.day);
      dayData.timeSlots.forEach((slot: any, index: number) => {
        this.addTimeSlot(dayControl);
        if (dayControl) {
          const timeSlots = dayControl.get('timeSlots') as FormArray;
          if (timeSlots.length > index) {
            const timeSlotControl = timeSlots.at(index) as FormGroup;
            timeSlotControl.patchValue({
              dayAndTimeId: slot.dayAndTimeId,
              startTime: slot.startTime,
              endTime: slot.endTime,
              startDate: slot.startDate,
              endDate: slot.endDate,
            });
          }
        }
      });
    });
  }
  updateClass(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const allTimeSlots = this.form.value.chosenDays.flatMap((dayGroup: any) => {
      return dayGroup.timeSlots.map((slot: any) => ({
        ...slot,
        day: this.abbreviateDay(dayGroup.day),
        startDate: this.formatDate(slot.startDate),
        endDate: this.formatDate(slot.endDate),
        dayAndTimeId: slot.dayAndTimeId || '',
      }));
    });

    this.timeslotsAll = allTimeSlots;
    console.log({ timeSlots: allTimeSlots });
    this.createClass.patchValue({ timeSlots: allTimeSlots });
    console.log(this.createClass.value), 'llllllllllppppppppppppssssssssss';
    console.log('Chosen days list:', this.chosenDaysList);
    const classId = this.data.classData.classId;
    const classvalues = this.createClass.value;
    classvalues['id'] = classId;
    classvalues['dayAndTime'] = this.timeslotsAll;
    classvalues['day'] = this.chosenDaysList;
    console.log(this.createClass.value);
    
    this.addClassService.updateClasss(classvalues).subscribe(
      (response) => {
        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: 'Your class has been successfully updated!',
          confirmButtonText: 'OK',
        }).then(() => {
          this.dialogRef.close('updated');
        });
        console.log(classvalues, '1111111111111111111111');
        this.createClass.reset();
        this.form.reset();
      },
      (error) => {
        console.error('Error updating class:', error);
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: 'An error occurred while updating the class. Please try again later.',
          confirmButtonText: 'OK',
        });
      }
    );
    console.log('777777777777777');
  }
}
