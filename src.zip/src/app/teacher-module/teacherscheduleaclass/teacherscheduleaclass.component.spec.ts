import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TeachersceduleaclassComponent } from './teacherscheduleaclass.component';

describe('TeachersceduleaclassComponent', () => {
  let component: TeachersceduleaclassComponent;
  let fixture: ComponentFixture<TeachersceduleaclassComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TeachersceduleaclassComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TeachersceduleaclassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
