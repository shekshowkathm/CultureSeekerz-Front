import { Component } from '@angular/core';
import { HeaderComponent } from '../../../login-register/header/header.component';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { FooterComponent } from '../../../login-register/components/footer/footer.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-teacher-home',
  standalone: true,
  templateUrl: './teacher-home.component.html',
  styleUrl: './teacher-home.component.scss',
  imports: [
    HeaderComponent,
    MatIconModule,
    MatButtonModule,
    FooterComponent,
  ],
})
export class TeacherHomeComponent {
  constructor(private router: Router) {}

  navigateToProfile() {
    this.router.navigate(['/teacher/teacherprofile']);
  }
  navigateToScheduleClass() {
    this.router.navigate(['/teacher/scheduletheclass']);
  }
  navigateToManageClass() {
    this.router.navigate(['/teacher/teachermanageclass']);
  }
  navigateCalendarClass(){
    this.router.navigate(['/calendarscheduler']);
  }
}
