import { Component, ElementRef, ViewChild,AfterViewInit, Inject } from '@angular/core';
import { TeachersceduleaclassComponent } from '../../teacherscheduleaclass/teacherscheduleaclass.component';
import { MatDialogModule } from '@angular/material/dialog';

@Component({
  selector: 'app-updateclass',
  standalone: true,
  imports: [
    TeachersceduleaclassComponent,
    MatDialogModule
  ],
  templateUrl: './updateclass.component.html',
  styleUrl: './updateclass.component.scss'
})
export class UpdateclassComponent   {

}


