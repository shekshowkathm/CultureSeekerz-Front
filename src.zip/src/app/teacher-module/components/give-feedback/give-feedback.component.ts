import { NgFor, NgIf } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { TeacherService } from '../../service/teacher-service';
import { MatChipsModule } from '@angular/material/chips';
import { MatFormFieldModule } from '@angular/material/form-field';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-give-feedback',
  standalone: true,
  imports: [
    MatIconModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    NgIf,
    NgFor,
    MatChipsModule,
    MatFormFieldModule,
  ],
  templateUrl: './give-feedback.component.html',
  styleUrl: './give-feedback.component.scss',
})
export class GiveFeedbackComponent {
  formData = {
    studentId: null,
    goals: [] as string[],
    feedbacks: [] as string[],
    accomplishments: [] as string[],
    topicsCovered: [] as string[],
  };
  objectdata;
  enrollStudents: any[] = [];

  constructor(
    public dialogRef: MatDialogRef<GiveFeedbackComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private teacherService: TeacherService
  ) {
    console.log(data);
    
    this.objectdata = data;
    this.enrollStudents = data.enrollStudents.filter(student => student.attendStatus);
    console.log(this.enrollStudents);
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  addGoal(event: KeyboardEvent): void {
    const input = event.target as HTMLInputElement;
    if (event.key === 'Enter' && input.value.trim() !== '') {
      this.formData.goals.push(input.value.trim());
      input.value = '';
      event.preventDefault();
    }
  }

  removeGoal(index: number): void {
    this.formData.goals.splice(index, 1);
  }

  addFeedback(event: KeyboardEvent): void {
    const input = event.target as HTMLInputElement;
    if (event.key === 'Enter' && input.value.trim() !== '') {
      this.formData.feedbacks.push(input.value.trim());
      input.value = '';
      event.preventDefault();
    }
  }

  removeFeedback(index: number): void {
    this.formData.feedbacks.splice(index, 1);
  }

  addAccomplishment(event: KeyboardEvent): void {
    const input = event.target as HTMLInputElement;
    if (event.key === 'Enter' && input.value.trim() !== '') {
      this.formData.accomplishments.push(input.value.trim());
      input.value = '';
      event.preventDefault();
    }
  }

  removeAccomplishment(index: number): void {
    this.formData.accomplishments.splice(index, 1);
  }
  addtopicsCovered(event: KeyboardEvent): void {
    const input = event.target as HTMLInputElement;
    if (event.key === 'Enter' && input.value.trim() !== '') {
      this.formData.topicsCovered.push(input.value.trim());
      input.value = '';
      event.preventDefault();
    }
  }

  removetopicsCovered(index: number): void {
    this.formData.topicsCovered.splice(index, 1);
  }

  onSubmit(form) {
    if (form.valid) {
      this.formData.studentId = parseInt(this.formData.studentId, 10);
      console.log(this.formData);
      this.teacherService.giveFeebackToStudent(this.formData).subscribe({
        next: (response) => {
          console.log(response);
          this.formData.goals = [];
          this.formData.accomplishments = [];
          this.formData.feedbacks = [];
          this.formData.topicsCovered = [];
          this.formData.studentId = '';
          Swal.fire({
            icon: 'success',
            title: 'Success',
            text: 'Your feedback has been added successfully!',
            confirmButtonText: 'OK',
          });
        },
        error: (error) => {
          console.error('Error feedback object:', error);
          Swal.fire({
            title: 'Feedback failed',
            text: 'Please check your credentials.',
            timer: 1000,
            timerProgressBar: false,
            icon: 'error',
            showConfirmButton: false,
          });
        },
      });
    }
  }
}
