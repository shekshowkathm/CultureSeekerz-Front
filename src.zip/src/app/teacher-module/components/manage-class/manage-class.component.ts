import { Component, Input } from '@angular/core';
import { HeaderComponent } from '../../../login-register/header/header.component';
import { NgFor, NgIf } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatTabsModule } from '@angular/material/tabs';
import { MatIconModule } from '@angular/material/icon';
import { UserServiceService } from '../../../user/service/user-service.service';
import { TeacherService } from '../../service/teacher-service';
import { PaidClass } from '../../model/paid-class.class';
import { TotalClass } from '../../model/total-class.class';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { TeachersceduleaclassComponent } from '../../teacherscheduleaclass/teacherscheduleaclass.component';
import { GiveFeedbackComponent } from '../give-feedback/give-feedback.component';

interface SlotCount {
  time: string;
  count: number;
  meetingLink: string;
}

@Component({
  selector: 'app-manage-class',
  standalone: true,
  imports: [
    HeaderComponent,
    NgFor,
    MatButtonModule,
    NgIf,
    MatTabsModule,
    MatIconModule,
    MatDialogModule,
  ],
  templateUrl: './manage-class.component.html',
  styleUrl: './manage-class.component.scss',
})
export class ManageClassComponent {
  manageClassResponse: any[] = [];
  truePaymentStatusData: any[] = [];
  falsePaymentStatusData: any[] = [];
  trueEmptyArrayData: boolean = true;
  falseEmptyArrayData: boolean = true;
  isStartDateValid: boolean = false;
  @Input() response: any;
  paidclasses: any[] = [];
  totalClasses: TotalClass[];
  showFullDescription: boolean = false;
  trialClassDataForTeacher: any[] = [];

  constructor(
    private userService: UserServiceService,
    private teacherService: TeacherService,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    const id = localStorage.getItem('teacherID');
    this.getOneParticularManageClass(id);
    this.getTeacherTrialClass();
  }

  getOneParticularManageClass(id: any) {
    this.teacherService.getManageClassTeacher(id).subscribe({
      next: (response) => {
        console.log(response, 'jjjjjjjjjjjjjjj');

        this.manageClassResponse = this.filterClasses(response);

        this.paidclasses = this.filterClasses(response);

        console.log('Paid Classess', this.paidclasses);
      },
      error: (error) => {
        console.error('Error retrieving object:', error);
      },
    });
  }

  filterClasses(classes: any[]): any[] {
    return classes.map((classItem) => {
      return {
        ...classItem,
        dayAndTimeDTO: classItem.dayAndTimeDTO.map((dayTime) => {
          return {
            ...dayTime,
            enrollStudents: dayTime.enrollStudents.filter(
              (student) => student.attendStatus
            ),
          };
        }),
      };
    });
  }

  getTeacherTrialClass() {
    const teacherEmail = localStorage.getItem('username');
    this.teacherService
      .getManageClassTeacherForTrialclass(teacherEmail)
      .subscribe({
        next: (response) => {
          this.trialClassDataForTeacher = response;
        },
        error: (error) => {
          console.error('Error retrieving object:', error);
        },
      });
  }

  // separateDataByPaymentStatus(): void {
  //   this.paidclasses = this.manageClassResponse.filter((classData) =>
  //     classData.dayAndTimeDTO.some((slot) =>
  //       slot.enrollStudents.some((student) => student.paymentStatus === true)
  //     )
  //   );

  //   this.paidclasses.forEach((classData) => {
  //     classData.dayAndTimeDTO.forEach((slot) => {
  //       slot.enrollStudents = slot.enrollStudents.filter(
  //         (student) => student.paymentStatus === true
  //       );
  //     });
  //   });
  //   if (!this.paidclasses) {
  //     this.paidclasses = [];
  //   }
  //   console.log('Paid Classes:', this.paidclasses);
  //   this.paidclasses.forEach((classData) => {});
  // }
  separateDataByPaymentStatus(): void {
    if (!this.manageClassResponse) {
      console.error('manageClassResponse is undefined');
      return;
    }
    console.log(this.manageClassResponse);

    // console.log(this.paidclasses);

    // this.paidclasses.forEach((classData) => {
    //   if (!classData.dayAndTimeDTO) {
    //     console.error('dayAndTimeDTO is undefined for classData:', classData);
    //     return;
    //   }

    //   classData.dayAndTimeDTO.forEach((slot) => {
    //     if (!slot.enrollStudents) {
    //       console.error('enrollStudents is undefined for slot:', slot);
    //       return;
    //     }

    //     slot.enrollStudents = slot.enrollStudents.filter(
    //       (student) => student.paymentStatus === true
    //     );
    //   });
    // });

    // if (!this.paidclasses) {
    //   this.paidclasses = [];
    // }
  }

  checkStartDate(item: any): void {
    const currentDate = new Date();
    const startDate = new Date(item.startDate);
    this.isStartDateValid = startDate > currentDate;
  }

  onButtonClick(link: string) {
    window.location.href = link;
  }

  joinMeeting(meetingLink: string) {
    window.open(meetingLink);
  }

  toggleDescription() {
    this.showFullDescription = !this.showFullDescription;
  }

  trialClassLink(link: string) {
    window.open(link, '_blank');
  }

  openTeacherScheduleDialog(selectedClass: any): void {
    console.log('Sending data :', selectedClass);
    const dialogRef = this.dialog.open(TeachersceduleaclassComponent, {
      width: '1000px',
      height: '800px',
      data: { isDialogMode: true, classData: selectedClass },
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log('The dialog was closed');
      if (result === 'updated') {
        const id = localStorage.getItem('teacherID');
        this.getOneParticularManageClass(id);
      }
    });
  }

  hasPaidStudents(slot: any): boolean {
    return slot.enrollStudents.some((student) => student.paymentStatus);
  }

  // isJoinable(startDate: string): boolean {
  //   const currentDate = new Date();
  //   const slotDate = new Date(startDate);

  //   // Compare only dates (ignore time)
  //   const isSameDate = currentDate.toDateString() === slotDate.toDateString();

  //   // Return true if the dates match
  //   return isSameDate;
  // }
  isJoinable(startDate: string, startTime: string, paidCount: number): boolean {
    const currentDateTime = new Date();
    const slotDateTime = new Date(startDate + 'T' + startTime);
    return currentDateTime.getTime() >= slotDateTime.getTime() && paidCount > 0;
  }

  giveFeedBack(slot) {
    console.log('feed back method');
    console.log(slot);
    const dialogRef = this.dialog.open(GiveFeedbackComponent, {
      width: 'auto', // specify width
      height: 'auto', // specify height
      data: slot,
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log('Dialog was closed');
    });
  }
}
