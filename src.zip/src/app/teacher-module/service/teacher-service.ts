import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ScheduleClass } from '../modelClass/schedule-class';
import { Observable, catchError, map, throwError } from 'rxjs';
import { environment } from '../../../environments/environment.development';

@Injectable({
  providedIn: 'root',
})
export class TeacherService {
  public createClassApi = environment.localdomain + '/activeclass/add';
  public updateDayAndTimeApi = environment.localdomain + '/activeclass/update';
  public getTeacherApi = environment.localdomain + '/teacher/get/{id}';
  public getTeacherClassURL = environment.localdomain + '/teacher/get/';
  public getTeacherManageClass = environment.localdomain + '/teacher/get/';
  public updateteacherClass =
    environment.localdomain + '/activeclass/updatefees';
  public getTeacherScheduledClassAPI =
    environment.localdomain + '/teacher/getmanageclass/';
  public getTeacherTrailManageClassAPI =
    environment.localdomain + '/trailclass/getteachertrialClass/';
  public teacherGivefeedback =
    environment.localdomain + '/student/providelearningprogress';
  public dataforUpdate: any[] = [];
  constructor(private http: HttpClient) {}

  private getRequestOptions(): { headers: HttpHeaders } {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + localStorage.getItem('token'),
    });
    return { headers };
  }

  private getRequestOptionss(): { headers: HttpHeaders } {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + localStorage.getItem('token'),
    });
    return { headers };
  }

  createclassService(createClass: ScheduleClass) {
    const requestOptions = this.getRequestOptions();
    const requestBody = JSON.stringify(createClass);
    const api = `${this.createClassApi}`;
    return this.http.post(api, requestBody, requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError)
    );
  }

  updateClasss(updatedClass: ScheduleClass) {
    console.log('Update method triggered in service ');
    const requestOptions = this.getRequestOptionss();
    const requestBody = JSON.stringify(updatedClass);
    const api = `${this.updateDayAndTimeApi}`;
    return this.http.put(api, requestBody, requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError)
    );
  }

  getteacherprofilebyId(): Observable<any> {
    const userId = localStorage.getItem('teacherID');
    console.log(userId + 'olaa');

    if (!userId) {
      console.error('User ID not found in local storage.');
      return throwError(() => new Error('User ID not found'));
    }

    const requestOptions = this.getRequestOptions();
    const apiUrl = `${this.getTeacherApi.replace('{id}', userId)}`;

    return this.http.get(apiUrl, requestOptions).pipe(
      catchError((error: HttpErrorResponse) => {
        console.error('Error fetching teacher profile:', error);
        return throwError(() => new Error('Error fetching teacher profile'));
      })
    );
  }

  /**
   * @param error
   */
  private handleError(error: any): Observable<never> {
    console.error('An error occurred:', error);
    throw error;
  }

  getScheduledClassData(id: any): Observable<any> {
    const requestOptions = this.getRequestOptionss();
    return this.http.get<any>(this.getTeacherClassURL + id, requestOptions);
  }

  getManageClassTeacher(id: any) {
    const requestOptions = this.getRequestOptionss();
    return this.http.get<any>(
      this.getTeacherScheduledClassAPI + id,
      requestOptions
    );
  }
  getManageClassTeacherForTrialclass(id: any) {
    const requestOptions = this.getRequestOptionss();
    return this.http.get<any>(
      this.getTeacherTrailManageClassAPI + id,
      requestOptions
    );
  }
  updateClass(classId: number, updatedClass: any): Observable<any> {
    const requestOptions = this.getRequestOptions();
    const requestBody = JSON.stringify(updatedClass);
    const api = `${this.updateteacherClass}`; // Assuming updateClassApi is your endpoint for updating a class
    return this.http.put(api, requestBody, requestOptions).pipe(
      map((response) => response),
      catchError(this.handleError)
    );
  }

  giveFeebackToStudent(feedback) {
    const requestOptions = this.getRequestOptions();
    return this.http.put(this.teacherGivefeedback, feedback, requestOptions);
  }
}
