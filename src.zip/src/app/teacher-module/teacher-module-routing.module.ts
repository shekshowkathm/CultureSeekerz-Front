import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TeacherprofileComponent } from './teacherprofile/teacherprofile.component';
import { TeachersceduleaclassComponent } from './teacherscheduleaclass/teacherscheduleaclass.component';
import { TeacherHomeComponent } from './components/teacher-home/teacher-home.component';
import { ManageClassComponent } from './components/manage-class/manage-class.component';
import { routeAuthGuard } from '../route-guard/route-auth.guard';

const routes: Routes = [
  {
    path: 'teacherprofile',
    component: TeacherprofileComponent,
    data: { allowedRoles: ['TEACHER'] },
    canActivate: [routeAuthGuard],
  },
  {
    path: 'scheduletheclass',
    component: TeachersceduleaclassComponent,
    data: { allowedRoles: ['TEACHER'] },
    canActivate: [routeAuthGuard],
  },
  {
    path: 'home',
    component: TeacherHomeComponent,
    data: { allowedRoles: ['TEACHER'] },
    canActivate: [routeAuthGuard],
  },
  {
    path: 'teachermanageclass',
    component: ManageClassComponent,
    data: { allowedRoles: ['TEACHER'] },
    canActivate: [routeAuthGuard],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class TeacherModuleRoutingModule {}
