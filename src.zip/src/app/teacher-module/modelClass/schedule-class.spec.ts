import { ScheduleClass } from './schedule-class';

describe('ScheduleClass', () => {
  it('should create an instance', () => {
    expect(new ScheduleClass()).toBeTruthy();
  });
});
