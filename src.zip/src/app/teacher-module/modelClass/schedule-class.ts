export class ScheduleClass {
  classUniqueId: string;
  classId : number = 0;
  activity: string = '';
  skilllevel: string = '';
  className: string = '';
  demoVideo: string = '';
  duration: string = '';
  seats: number = 0;
  feesRange: string = '';
  fees: string = '';
  ageGroup: string | string[] = [];
  startDate: Date | null = null;
  endDate?: Date | null = null;
  day: string[] = [];
  dayAndTimeDTO: {
    dayAndTimeId:number;
    startTime: string;
    endTime : string;
    startDate : string ;
    endDate : string;
    meetingLink : string ;
    day: string,
    // time: string[]
  }[] = [];
  // meetingLink?: string = '';
  trailClass: boolean;
  description: string = '';
  classType: string | string []= [];
  classImage: string = '';
  teacher: {
    teacherName: string;
    teacherEmail: string;
    teacherProfile: string;
    teacherPhoneNumber: string;
    teacherId: number;
  } = {
    teacherName: "",
    teacherEmail: "",
    teacherProfile: "",
    teacherPhoneNumber: "",
    teacherId: 0
  };

}

