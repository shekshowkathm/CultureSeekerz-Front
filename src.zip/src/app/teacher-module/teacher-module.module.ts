import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TeacherModuleRoutingModule } from './teacher-module-routing.module';
import { LoginRegisterModule } from '../login-register/login-register.module';
import { TeacherService } from './service/teacher-service';
import { UserServiceService } from '../user/service/user-service.service';
import { TeachersceduleaclassComponent } from './teacherscheduleaclass/teacherscheduleaclass.component';
import { MatDialogModule , MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material/core';


@NgModule({
  declarations: [

  ],
  imports: [
    CommonModule,
    TeacherModuleRoutingModule,
    LoginRegisterModule , 
    MatDialogModule , 
    ReactiveFormsModule,
    MatDatepickerModule,
    MatInputModule,
    MatNativeDateModule,
    // MatExpansionModule
  ],
  providers:[
    TeacherService,UserServiceService ,
    { provide: MAT_DIALOG_DATA, useValue: {} }
  ],
  
})
export class TeacherModuleModule { }
