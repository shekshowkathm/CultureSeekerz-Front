import {
  ActivatedRouteSnapshot,
  CanActivateFn,
  Router,
  RouterStateSnapshot,
} from '@angular/router';
import { inject } from '@angular/core';

export const routeAuthGuard: CanActivateFn = (
  route: ActivatedRouteSnapshot,
  state: RouterStateSnapshot
) => {
  const userRole = localStorage.getItem('role');
  const allowedRoles = route.data['allowedRoles'] as string[];

  if (userRole === allowedRoles[0]) {
    return true;
  } else if (userRole === 'ADMIN') {
    return true;
  } else if (
    allowedRoles[0] === 'userAndStudentPage' &&
    userRole !== 'TEACHER' &&
    userRole !== 'PARENT'
  ) {
    return true;
  } else {
    inject(Router).navigate(['/login']);
    return false;
  }
};
