import { ApplicationConfig, isDevMode } from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';
import { provideAnimations } from '@angular/platform-browser/animations';
import { provideServiceWorker } from '@angular/service-worker';
import { provideHttpClient } from '@angular/common/http';
import { initializeApp, provideFirebaseApp } from '@angular/fire/app';
import { getMessaging, provideMessaging } from '@angular/fire/messaging';

const firebaseConfig = {
  projectId: 'push-notification-40b43',
  appId: '1:690049637641:web:fa360860ddb8bbe07a87d8',
  storageBucket: 'push-notification-40b43.appspot.com',
  apiKey: 'AIzaSyCeW4n7uzZavWUZ29tJf4S8uKuv-9YMF2w',
  authDomain: 'push-notification-40b43.firebaseapp.com',
  messagingSenderId: '690049637641',
  measurementId: 'G-RPEHC2NN86'
};
export const appConfig: ApplicationConfig = {
  providers: [provideHttpClient(),provideFirebaseApp(() => initializeApp(firebaseConfig)),provideMessaging(() => getMessaging()), provideRouter(routes), provideAnimations(), provideServiceWorker('ngsw-worker.js', {
        enabled: !isDevMode(),
        registrationStrategy: 'registerWhenStable:30000'
    })]
};
