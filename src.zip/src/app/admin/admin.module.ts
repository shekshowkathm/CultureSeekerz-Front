import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminService } from './service/admin.service';
import { LoginRegisterModule } from '../login-register/login-register.module';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AdminRoutingModule,
    LoginRegisterModule,HttpClientModule
  ],
  providers: [
    AdminService,
  ],
})
export class AdminModule { }
