import { Component, ElementRef, ViewChild } from '@angular/core';
import { AdminService } from '../../service/admin.service';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { NgFor, NgIf } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTabGroup, MatTabsModule } from '@angular/material/tabs';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { RescheduleInfoComponent } from '../reschedule-info/reschedule-info.component';
import { MatDialog } from '@angular/material/dialog';

import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSelectModule } from '@angular/material/select';

@Component({
  selector: 'app-payment-history',
  standalone: true,
  imports: [
    MatIconModule,
    MatButtonModule,
    FormsModule,
    ReactiveFormsModule,
    MatInputModule,
    MatTableModule,
    MatPaginator,
    MatSort,
    NgFor,
    NgIf,
    MatTabsModule,
    MatSlideToggleModule,
    MatSelectModule,
  ],
  templateUrl: './payment-history.component.html',
  styleUrl: './payment-history.component.scss',
})
export class PaymentHistoryComponent {
  selectedActivity: string = '';

  isApproved: boolean = true;

  activityList = [
    'jan',
    'feb',
    'mar',
    'apr',
    'may',
    'jun',
    'july',
    'aug',
    'sept',
    'oct',
    'nov',
    'dec',
    'all',
  ];

  isTabSearch: boolean = true;

  @ViewChild('tabGroup', { static: true }) tabGroup: MatTabGroup;

  searchValue: string = '';

  monthName: string = '';

  months = [
    { name: 'January', value: 1 },
    { name: 'February', value: 2 },
    { name: 'March', value: 3 },
    { name: 'April', value: 4 },
    { name: 'May', value: 5 },
    { name: 'June', value: 6 },
    { name: 'July', value: 7 },
    { name: 'August', value: 8 },
    { name: 'September', value: 9 },
    { name: 'October', value: 10 },
    { name: 'November', value: 11 },
    { name: 'December', value: 12 },
  ];

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  displayedColumns: string[] = [
    'studentid',
    'studentName',
    'studentUniqueId',
    'parentName',
    'parentEmail',
    'phonenumber',
    'monthlyAmount',
    'view',
    'status',
  ];

  dataSource!: MatTableDataSource<any>;

  constructor(private adminService: AdminService, public dialog: MatDialog) {}

  ngOnInit() {
    this.fetchPaymentData('1');
  }

  fetchPaymentData(activity: string): void {
    if (this.isTabSearch) {
      if (this.isApproved) {
        this.adminService
          .getPaymentHistory(activity, this.isApproved)
          .subscribe({
            next: (response: any) => {
              console.log(response);
              this.dataSource = new MatTableDataSource(response);
              this.dataSource.sort = this.sort;
              this.dataSource.paginator = this.paginator;
            },
            error: (error: any) => {
              console.error('Error fetching data:', error);
            },
          });
      } else {
        this.adminService
          .getPaymentHistory(activity, this.isApproved)
          .subscribe({
            next: (response: any) => {
              console.log(response);
              this.dataSource = new MatTableDataSource(response);
              this.dataSource.paginator = this.paginator;
              this.dataSource.sort = this.sort;
            },
            error: (error: any) => {
              console.error('Error fetching data:', error);
            },
          });
      }
    }
  }

  tabChanged(event: MatTabChangeEvent): void {
    const index = event.index + 1;
    this.selectedActivity = index.toString();
    console.log(this.selectedActivity);

    this.fetchPaymentData(this.selectedActivity);
  }

  capitalizeFirstLetter(word: string): string {
    return word.charAt(0).toUpperCase() + word.slice(1);
  }

  approvedPayment() {
    this.isApproved = true;
    if (this.selectedActivity === '') {
      this.selectedActivity = '1';
    }
    this.fetchPaymentData(this.selectedActivity);
  }
  nonapprovedPayment() {
    this.isApproved = false;
    if (this.selectedActivity === '') {
      this.selectedActivity = '1';
    }
    this.fetchPaymentData(this.selectedActivity);
  }

  viewPaymentHistory(data) {
    const dialogRef = this.dialog.open(RescheduleInfoComponent, {
      width: 'auto',
      height: 'auto',
      data: { role: 'paymentHistory', element: data },
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log('The dialog was closed');
      console.log(result);
    });
  }

  updateAPI(data) {
    const studentIds = data.paymentHistory.map((history) => history.studentId);

    console.log(studentIds);
    this.adminService.updatePaymentHistory(studentIds).subscribe({
      next: (response: any) => {
        console.log(response);
        this.fetchPaymentData(this.selectedActivity);
      },
      error: (error: any) => {
        console.error('Error fetching data:', error);
      },
    });
  }

  onSearch(): void {
    console.log(this.searchValue);
    console.log(this.monthName);

    this.isTabSearch = false;

    this.adminService
      .getPaymentHistoryByUniqueID(this.searchValue, this.monthName)
      .subscribe({
        next: (response: any) => {
          console.log(response);
          this.dataSource = new MatTableDataSource(response);
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;

          const activityIndex = this.activityList.indexOf('all');
          if (activityIndex !== -1) {
            this.tabGroup.selectedIndex = activityIndex;
          }

          setTimeout(() => {
            this.searchValue = '';
            this.monthName = '';
            this.isTabSearch = true;
          }, 1250);
        },
        error: (error: any) => {
          console.error('Error fetching data:', error);
        },
      });
  }
}
