import { NgFor, NgIf } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-teacher-info',
  standalone: true,
  imports: [MatIconModule,NgIf,NgFor],
  templateUrl: './teacher-info.component.html',
  styleUrl: './teacher-info.component.scss',
})
export class TeacherInfoComponent {
  constructor(
    @Inject(MAT_DIALOG_DATA) public teacherInfo: any,
    public dialogRef: MatDialogRef<TeacherInfoComponent>
  ) {
  }

  closeDialog(): void {
    this.dialogRef.close();
  }
}
