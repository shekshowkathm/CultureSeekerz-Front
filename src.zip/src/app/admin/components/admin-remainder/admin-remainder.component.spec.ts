import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminRemainderComponent } from './admin-remainder.component';

describe('AdminRemainderComponent', () => {
  let component: AdminRemainderComponent;
  let fixture: ComponentFixture<AdminRemainderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminRemainderComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AdminRemainderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
