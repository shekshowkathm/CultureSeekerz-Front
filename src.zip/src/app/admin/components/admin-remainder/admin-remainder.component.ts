import { Component, ViewChild } from '@angular/core';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { AdminService } from '../../service/admin.service';
import Swal from 'sweetalert2';
import { MatTabChangeEvent, MatTabsModule } from '@angular/material/tabs';
import { NgFor, NgIf } from '@angular/common';

@Component({
  selector: 'app-admin-remainder',
  standalone: true,
  imports: [
    MatPaginatorModule,
    MatTableModule,
    MatSortModule,
    MatSlideToggleModule,
    MatTabsModule,
    NgFor,
    NgIf,
  ],
  templateUrl: './admin-remainder.component.html',
  styleUrl: './admin-remainder.component.scss',
})
export class AdminRemainderComponent {
  sampleBackEndResponse = [
    {
      studentName: 'pacific  child five',
      teacherName: 'shek showkath teacher',
      activity: 'Carnatic',
      studentId: 6,
      parentEmail: 'pacifictime@gmail.com',
      remainderStatus: false,
    },
  ];

  displayedColumns: string[] = [
    'parentEmail',
    'studentName',
    'activity',
    'teacherName',
    'status',
  ];
  dataSource = new MatTableDataSource<any>();

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  selectedActivity: string = '';

  activityList = [
    'tamil',
    'bible',
    'carnatic',
    'shloka',
    'chess',
    'programming',
    'maths',
    'science',
    'telugu',
    'yoga',
    'Mridangam',
    'Hindi',
  ];

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    this.getRemainderData();
    // this.openSlotInfo('summa');
  }

  ngAfterViewInit() {
    // this.dataSource = new MatTableDataSource(this.sampleBackEndResponse);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  getRemainderData() {
    this.adminService.getRemainderValues().subscribe({
      next: (response) => {
        console.log(response);
        this.dataSource = new MatTableDataSource(response);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      },
      error: (error) => {
        console.error('Error retrieving object:', error);
        // Handle error, if needed
      },
    });
  }

  changeStatus(element) {
    console.log('Status changed');
    console.log(element);
    Swal.fire({
      title: 'Are you sure want to send reminder?',
      showCancelButton: true,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
    }).then((result) => {
      if (result.isConfirmed) {
        this.sendReminder(element);
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        this.getRemainderData();
      }
    });
  }

  sendReminder(element) {
    // Implement your send method here
    console.log('Sending reminder...');
    this.adminService.sendRemainderMail(element).subscribe({
      next: (response) => {
        console.log(response);
        this.getRemainderData();
      },
      error: (error) => {
        console.error('Error retrieving object:', error);
        // Handle error, if needed
      },
    });
  }

  tabChanged(event: MatTabChangeEvent): void {
    const label = event.tab.textLabel;

    const modifiedLabel = label.charAt(0).toLowerCase() + label.slice(1);
    this.selectedActivity = label;
    // this.getActivityByNameResponse(this.selectedActivity);
  }

  capitalizeFirstLetter(word: string): string {
    return word.charAt(0).toUpperCase() + word.slice(1);
  }
}
