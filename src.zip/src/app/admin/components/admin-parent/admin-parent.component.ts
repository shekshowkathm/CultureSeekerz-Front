import { Component, ViewChild } from '@angular/core';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { NgFor, NgIf } from '@angular/common';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatIconModule, MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule, NgForm, ReactiveFormsModule } from '@angular/forms';
import { AdminService } from '../../service/admin.service';
import { MatDialog } from '@angular/material/dialog';
import { ScheduledClassDetailsComponent } from '../scheduled-class-details/scheduled-class-details.component';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import Swal from 'sweetalert2';
import { MatTabChangeEvent, MatTabsModule } from '@angular/material/tabs';
import { MatSelectModule } from '@angular/material/select';
import { PaymentTeacherInfoComponent } from '../payment-teacher-info/payment-teacher-info.component';

@Component({
  selector: 'app-admin-parent',
  standalone: true,
  imports: [
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatSortModule,
    MatPaginatorModule,
    NgFor,
    MatTooltipModule,
    MatIconModule,
    NgIf,
    MatButtonModule,
    FormsModule,
    ReactiveFormsModule,
    MatSlideToggleModule,
    MatTabsModule,
    MatSelectModule,
  ],
  templateUrl: './admin-parent.component.html',
  styleUrl: './admin-parent.component.scss',
  providers: [HttpClient, MatIconRegistry],
})
export class AdminParentComponent {
  dataSource = new MatTableDataSource<any>();
  // displayedColumns: string[] = [
  //   'serialNumber',
  //   'studentName',
  //   'studentEmail',
  //   'studentNumber',
  //   'className',
  //   // 'SelectedTime',
  //   // 'classTimings',
  //   'approve',
  //   'teacherinfo',
  //   'parentInfo',
  //   // 'fees',
  //   // 'classType',
  //   // 'teacherName',
  //   // 'teacherEmail',
  //   // 'teacherPhoneNumber',
  //   // 'parentName',
  //   // 'parentEmail',
  //   // 'parentPhoneNumber',
  // ];

  displayedColumns: string[] = [
    'serialNumber',
    'childName',
    'teacherName',
    'feesRange',
    'studTime',
    'studDate',
    'classType',
    'ageGroup',
    'fees',
  ];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  getActiveClassResponse: any;
  enterLink: boolean[] = [];
  startDate: string = '';
  endDate: string = '';
  timeInput: string = '';
  linkInput: string = '';
  duration: string = '';

  selectedActivity: string = '';

  activityList = [
    'tamil',
    'bible',
    'carnatic',
    'shloka',
    'chess',
    'programming',
    'maths',
    'science',
    'telugu',
    'yoga',
    'Mridangam',
    'Hindi',
  ];

  selectedTime: any;
  isApproved: boolean = true;

  constructor(
    private matIconRegistry: MatIconRegistry,
    private domSanitizer: DomSanitizer,
    private adminService: AdminService,
    public dialog: MatDialog
  ) {}

  ngOnInit(): void {
    // this.initializeLinkVisibility();
    // this.getParentsAndStudentData();
    // this.openDialog('suma');
    this.selectedActivity = 'Tamil';
    this.getActivityByNameResponse(this.selectedActivity);
  }

  getParentsAndStudentData() {
    this.adminService.getActiveClassPayments().subscribe({
      next: (response) => {
        this.getActiveClassResponse = response;
        this.initializeLinkVisibility();

        // Assign the response to the object property
        // Handle success, if needed
      },
      error: (error) => {
        console.error('Error retrieving object:', error);
        // Handle error, if needed
      },
    });
  }

  toggleLinkVisibility(index: number, row: any): void {
    this.enterLink[index] = !this.enterLink[index];

    const bodyObject = {
      meetingLink: this.linkInput,
      fees: row.scheduleClass.fees,
      startDate: this.startDate,
      endDate: this.endDate,
      time: this.timeInput,
      activeClassId: row.scheduleClass.classId,
      duration: this.duration,
    };
    this.adminService.updateActiveClassPayemnts(bodyObject).subscribe({
      next: (response) => {
        this.getParentsAndStudentData();
        // Handle success, if needed
      },
      error: (error) => {
        console.error('Error updating object:', error);
        // Handle error, if needed
        this.getParentsAndStudentData();
      },
    });
    // this.getParentsAndStudentData();
  }

  initializeLinkVisibility(): void {
    // this.enterLink = new Array(this.dataSource.data.length).fill(true); // Set all rows initially visible
  }

  showInputs(index: number, row) {
    this.enterLink[index] = !this.enterLink[index];
    this.linkInput = row.scheduleClass.meetingLink;
    this.timeInput = row.scheduleClass.time;
    this.startDate = row.scheduleClass.startDate;
    this.endDate = row.scheduleClass.endDate;
    this.duration = row.scheduleClass.duration;
  }

  openDialog(data: any): void {
    const dialogRef = this.dialog.open(ScheduledClassDetailsComponent, {
      width: 'auto',
      height: 'auto',
      data: data,
    });
    dialogRef.afterClosed().subscribe((result) => {});
  }

  changeStatus(checked: boolean, teacherid: string) {
    if (checked) {
      Swal.fire({
        title: 'Are you sure to approve this student?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes',
        cancelButtonText: 'No',
      }).then((result) => {
        if (result.isConfirmed) {
          this.statusMethod(teacherid);
        } else {
          // No action needed, user canceled
          // this.getParentsAndStudentData();
          this.getActivityByNameResponse(this.selectedActivity);
        }
      });
    } else {
      Swal.fire({
        title: 'Do you want to disapprove this student?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes',
        cancelButtonText: 'No',
      }).then((result) => {
        if (result.isConfirmed) {
          this.statusMethod(teacherid);
        } else {
          // User canceled
          // this.getParentsAndStudentData();
          this.getActivityByNameResponse(this.selectedActivity);
        }
      });
    }
  }

  statusMethod(studentID: string) {
    this.adminService.updateStudentPayemnts(studentID).subscribe({
      next: (data) => {
        this.getActivityByNameResponse(this.selectedActivity);
      },
      error: (error) => {
        console.error('Error fetching teachers:', error);
        this.getActivityByNameResponse(this.selectedActivity);
      },
    });
  }

  tabChanged(event: MatTabChangeEvent): void {
    const label = event.tab.textLabel;

    const modifiedLabel = label.charAt(0).toLowerCase() + label.slice(1);
    this.selectedActivity = label;
    this.getActivityByNameResponse(this.selectedActivity);
  }

  capitalizeFirstLetter(word: string): string {
    return word.charAt(0).toUpperCase() + word.slice(1);
  }

  getActivityByNameResponse(activity: string) {
    if (this.isApproved) {
      this.adminService
        .getActivityValuesByName(
          'getEnrolledStudents/',
          activity,
          this.isApproved
        )
        .subscribe({
          next: (response) => {
            this.dataSource.data = response;
            this.dataSource.paginator = this.paginator;
            this.dataSource.sort = this.sort;
          },
          error: (error) => {
            console.error('Error retrieving object:', error);
            // Handle error, if needed
          },
        });
    } else {
      this.adminService
        .getActivityValuesByName(
          'getEnrolledStudents/',
          activity,
          this.isApproved
        )
        .subscribe({
          next: (response) => {
            this.dataSource.data = response;
            this.dataSource.paginator = this.paginator;
            this.dataSource.sort = this.sort;
          },
          error: (error) => {
            console.error('Error retrieving object:', error);
            // Handle error, if needed
          },
        });
    }
  }

  slotBooking(element: any, selectedTime, studentID: any) {
    const slotObject = {
      id: studentID,

      slots: {
        id: selectedTime,
      },
    };
    this.adminService.updateSlotBooking(slotObject).subscribe({
      next: (response) => {
        this.getActivityByNameResponse(this.selectedActivity);
      },
      error: (error) => {
        console.error('Error retrieving object:', error);
        this.getActivityByNameResponse(this.selectedActivity);

        // Handle error, if needed
      },
    });
  }

  openTeacherInfo(element) {
    const dialogRef = this.dialog.open(PaymentTeacherInfoComponent, {
      width: '550px', // specify width
      height: 'auto', // specify height
      data: { data: element, type: 'teacher' },
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log('Dialog was closed');
    });
  }

  openParentInfo(details) {
    const dialogRef = this.dialog.open(PaymentTeacherInfoComponent, {
      width: '400px', // specify width
      height: 'auto', // specify height
      data: { data: details, type: 'parent' },
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log('Dialog was closed');
    });
  }

  approvedPayments() {
    this.isApproved = true;
    if (this.selectedActivity === '') {
      this.selectedActivity = 'Tamil';
    }
    this.getActivityByNameResponse(this.selectedActivity);
  }
  nonapprovedPayments() {
    this.isApproved = false;
    if (this.selectedActivity === '') {
      this.selectedActivity = 'Tamil';
    }
    this.getActivityByNameResponse(this.selectedActivity);
  }

  submitFees(student: any) {
    // console.log(
    //   'Submitted fees for student:',
    //   student.studentId,
    //   'Fees:',
    //   student.fees
    // );
    // console.log(student);

    console.log(student);

    if (
      student.classFees !== null &&
      student.classFees.toString().length >= 2
    ) {
      console.log(
        'Submitted fees for student:',
        student.studentId,
        'Fees:',
        student.classFees
      );

      this.adminService.updateFeestDetails(student).subscribe({
        next: (response) => {
          // Clear the input field after submission
          student.classFees = null;
          console.log(response);
          this.getActivityByNameResponse(this.selectedActivity);
        },
        error: (error) => {
          console.error('Error retrieving object:', error);
          // Handle error, if needed
        },
      });
    } else {
      console.log('Validation error');
    }
  }
}
