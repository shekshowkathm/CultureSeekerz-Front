import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RescheduleInfoComponent } from './reschedule-info.component';

describe('RescheduleInfoComponent', () => {
  let component: RescheduleInfoComponent;
  let fixture: ComponentFixture<RescheduleInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RescheduleInfoComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(RescheduleInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
