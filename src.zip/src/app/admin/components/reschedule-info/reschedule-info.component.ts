import { NgFor, NgIf } from '@angular/common';
import { Component, Inject, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';

@Component({
  selector: 'app-reschedule-info',
  standalone: true,
  imports: [
    MatIconModule,
    MatButtonModule,
    NgIf,
    NgFor,
    MatPaginator,
    MatTableModule,
  ],
  templateUrl: './reschedule-info.component.html',
  styleUrl: './reschedule-info.component.scss',
})
export class RescheduleInfoComponent {
  passedData;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  dataSource!: MatTableDataSource<any>;

  displayedColumns: string[] = [
    'teacherName',
    'activity',
    'enrolledOn',
    'fees',
    'activeClassId',
    'paid',
    'studentId',
  ];

  constructor(
    public dialogRef: MatDialogRef<RescheduleInfoComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.passedData = data;
    console.log(this.passedData);
  }

  ngOnInit() {
    this.dataSource = new MatTableDataSource(this.passedData.element);
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }

  closedialog(): void {
    this.dialogRef.close();
  }
}
