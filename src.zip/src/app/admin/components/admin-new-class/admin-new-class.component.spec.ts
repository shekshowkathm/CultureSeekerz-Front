import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminNewClassComponent } from './admin-new-class.component';

describe('AdminNewClassComponent', () => {
  let component: AdminNewClassComponent;
  let fixture: ComponentFixture<AdminNewClassComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminNewClassComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AdminNewClassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
