import { Component, ViewChild } from '@angular/core';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { NgFor, NgIf } from '@angular/common';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatIconModule, MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminService } from '../../service/admin.service';
import { MatDialog } from '@angular/material/dialog';
import { TeacherInfoComponent } from '../teacher-info/teacher-info.component';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import Swal from 'sweetalert2';
import { SlotDetailsComponent } from '../slot-details/slot-details.component';
import {
  MatTabChangeEvent,
  MatTabGroup,
  MatTabsModule,
} from '@angular/material/tabs';
import { MatInputModule } from '@angular/material/input';

import { MatSelectModule } from '@angular/material/select';

@Component({
  selector: 'app-admin-new-class',
  standalone: true,
  imports: [
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatSortModule,
    MatPaginatorModule,
    NgFor,
    MatTooltipModule,
    MatIconModule,
    NgIf,
    MatButtonModule,
    FormsModule,
    ReactiveFormsModule,
    NgIf,
    NgFor,
    MatSlideToggleModule,
    MatTabsModule,
    MatInputModule,
    MatSelectModule,
  ],
  templateUrl: './admin-new-class.component.html',
  styleUrl: './admin-new-class.component.scss',
  providers: [HttpClient, MatIconRegistry],
})
export class AdminNewClassComponent {
  displayedColumns: string[] = [
    'serialNumber',
    // 'className',
    'activity',
    'feesRange',
    'feesInr',
    'day',
    // 'seats',
    'teacherinfo',
    // 'classTimings',
    'Slotdetails',
    'status',
  ];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  enterLink: boolean[] = [];
  dateInput: string = '';
  timeInput: string = '';
  linkInput: string = '';
  startDate: string = '';
  endDate: string = '';
  // duration: number = 0;

  days: string[] = [];
  selectedDay: string = '';
  selectedDayTimes: string[] = [];
  selectedTime: string = '';

  selectedActivity: string = 'Tamil';

  activityList = [
    'tamil',
    'bible',
    'carnatic',
    'shloka',
    'chess',
    'programming',
    'maths',
    'science',
    'telugu',
    'yoga',
    'Mridangam',
    'Hindi',
    'all',
  ];

  isApproved: boolean = true;

  @ViewChild('tabGroup', { static: true }) tabGroup: MatTabGroup;

  searchValue: string = '';

  isTabSearch: boolean = true;

  searchType: string = '';

  constructor(
    private matIconRegistry: MatIconRegistry,
    private domSanitizer: DomSanitizer,
    private adminService: AdminService,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.getNewClassData('Tamil');
    // this.openSlotInfo('summa');
  }

  getNewClassData(activity: string) {
    if (this.isTabSearch) {
      if (this.isApproved) {
        this.adminService
          .getNewClasses('getClasses/', activity, this.isApproved)
          .subscribe({
            next: (response) => {
              this.dataSource = new MatTableDataSource(response);
              this.dataSource.paginator = this.paginator;
              this.dataSource.sort = this.sort;
              this.initializeLinkVisibility();
            },
            error: (error) => {
              console.error('Error retrieving object:', error);
              // Handle error, if needed
            },
          });
      } else {
        this.adminService
          .getNewClasses('getClasses/', activity, this.isApproved)
          .subscribe({
            next: (response) => {
              this.dataSource = new MatTableDataSource(response);
              this.dataSource.paginator = this.paginator;
              this.dataSource.sort = this.sort;
              this.initializeLinkVisibility();
            },
            error: (error) => {
              console.error('Error retrieving object:', error);
              // Handle error, if needed
            },
          });
      }
    }
  }

  copyToClipboard(link: string) {
    navigator.clipboard
      .writeText(link)
      .then(() => {})
      .catch((error) => {
        console.error('Failed to copy meeting link to clipboard:', error);
      });
  }

  openTeacherInfo(object: any) {
    const dialogRef = this.dialog.open(TeacherInfoComponent, {
      width: 'auto',
      height: 'auto',
      data: object,
    });
    dialogRef.afterClosed().subscribe((result) => {});
  }
  openSlotInfo(object: any) {
    const dialogRef = this.dialog.open(SlotDetailsComponent, {
      width: 'auto',
      height: 'auto',
      data: object,
    });
    dialogRef.afterClosed().subscribe((result) => {
      this.getNewClassData(this.selectedActivity);
    });
  }
  changeStatus(checked: boolean, teacherid: string) {
    if (checked) {
      Swal.fire({
        title: 'Are you sure to approve this teacher?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes',
        cancelButtonText: 'No',
      }).then((result) => {
        if (result.isConfirmed) {
          this.statusMethod(teacherid);
        } else {
          // No action needed, user canceled
          this.getNewClassData(this.selectedActivity);
        }
      });
    } else {
      Swal.fire({
        title: 'Do you want to disapprove this teacher?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes',
        cancelButtonText: 'No',
      }).then((result) => {
        if (result.isConfirmed) {
          this.statusMethod(teacherid);
        } else {
          // User canceled
          this.getNewClassData(this.selectedActivity);
        }
      });
    }
  }

  statusMethod(teacherid: string) {
    this.adminService.approveClass(teacherid).subscribe({
      next: (data) => {
        this.getNewClassData(this.selectedActivity);
      },
      error: (error) => {
        console.error('Error fetching teachers:', error);
      },
    });
  }

  initializeLinkVisibility(): void {
    this.enterLink = new Array(this.dataSource.data.length).fill(true); // Set all rows initially visible
  }

  toggleLinkVisibility(index: number, row: any): void {
    this.enterLink[index] = !this.enterLink[index];

    const updateObject = {
      // time: this.timeInput,
      // meetingLink: this.linkInput,
      // activeClass: {
      //   id: row.classId,
      // },
      time: this.timeInput,
      meetingLink: this.linkInput,
      startDate: this.startDate,
      endDate: this.endDate,
      // duration: this.duration,
      activeClass: {
        id: row.classId,
      },
      day: this.selectedDay,
    };
    this.timeInput = '';
    this.linkInput = '';
    this.startDate = '';
    this.endDate = '';
    // this.duration=0
    this.adminService.updateSlotDetails(updateObject).subscribe({
      next: (response) => {
        this.getNewClassData(this.selectedActivity);
      },
      error: (error) => {
        console.error('Error updating object:', error);
        this.getNewClassData(this.selectedActivity);
      },
    });
  }
  showInputs(index: number) {
    this.enterLink[index] = !this.enterLink[index];
  }
  onDaySelection(event: Event, dayAndTimeDTO) {
    const selectedDay = (event.target as HTMLSelectElement).value;
    const myDayAndTime = [
      {
        id: 1,
        day: 'Mon',
        time: ['09.00am - 10.00am', '10.00am - 11.00am', '11.00am - 12.00pm'],
      },
      {
        id: 2,
        day: 'Tue',
        time: ['12.00pm - 01.00pm', '01.00pm - 02.00pm', '02.00pm - 03.00pm'],
      },
      {
        id: 3,
        day: 'Wed',
        time: ['03.00pm - 04.00pm', '04.00pm - 05.00pm', '05.00pm - 06.00pm'],
      },
      {
        id: 4,
        day: 'Thu',
        time: ['03.00pm - 04.00pm', '05.00pm - 06.00pm'],
      },
      {
        id: 5,
        day: 'Fri',
        time: ['06.00am - 07.00am', '07.00am - 08.00am'],
      },
      {
        id: 6,
        day: 'Sat',
        time: ['08.00pm - 09.00pm', '09.00pm - 10.00pm', '11.00pm - 12.00am'],
      },
      {
        id: 7,
        day: 'Sun',
        time: ['01.00pm - 02.00pm'],
      },
    ];
    const filterredData = dayAndTimeDTO.filter(
      (item) => item.day === selectedDay
    );
    this.selectedDayTimes = filterredData[0].time;
  }
  tabChanged(event: MatTabChangeEvent): void {
    const label = event.tab.textLabel;
    const modifiedLabel = label.charAt(0).toLowerCase() + label.slice(1);
    this.selectedActivity = label;
    this.getNewClassData(this.selectedActivity);
  }
  capitalizeFirstLetter(word: string): string {
    return word.charAt(0).toUpperCase() + word.slice(1);
  }
  approvedClass() {
    this.isApproved = true;
    if (this.selectedActivity === '') {
      this.selectedActivity = 'Tamil';
    }
    this.getNewClassData(this.selectedActivity);
  }
  nonapprovedClass() {
    this.isApproved = false;
    if (this.selectedActivity === '') {
      this.selectedActivity = 'Tamil';
    }
    this.getNewClassData(this.selectedActivity);
  }
  onSearch(): void {
    this.isTabSearch = false;
    if (this.searchType === 'classid') {
      this.adminService.getSearchNewClasses(this.searchValue).subscribe({
        next: (response) => {
          this.dataSource = new MatTableDataSource(response);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
          this.initializeLinkVisibility();
          const activity = response[0].scheduleClass.activity.toLowerCase();
          const activityIndex = this.activityList.indexOf(activity);
          if (activityIndex !== -1) {
            this.tabGroup.selectedIndex = activityIndex;
          }
          setTimeout(() => {
            this.searchValue = '';
            this.searchType = '';
            this.isTabSearch = true;
          }, 1250);
        },
        error: (error) => {
          console.error('Error retrieving object:', error);
        },
      });
    } else {
      this.adminService.getSearcTeacherhNewClasses(this.searchValue).subscribe({
        next: (response) => {
          this.dataSource = new MatTableDataSource(response);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
          this.initializeLinkVisibility();
          const activity = 'all';
          const activityIndex = this.activityList.indexOf(activity);
          if (activityIndex !== -1) {
            this.tabGroup.selectedIndex = activityIndex;
          }
          setTimeout(() => {
            this.searchValue = '';
            this.searchType = '';
            this.isTabSearch = true;
          }, 1250);
        },
        error: (error) => {
          console.error('Error retrieving object:', error);
        },
      });
    }
  }
}
