import { NgClass, NgFor, NgIf, NgSwitch, NgSwitchCase } from '@angular/common';
import { Component, HostListener } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { AdminService } from '../../service/admin.service';

import { AdminTeacherComponent } from '../admin-teacher/admin-teacher.component';
import { AdminParentComponent } from '../admin-parent/admin-parent.component';
import { AdminTrialClassComponent } from '../admin-trial-class/admin-trial-class.component';
import { AdminNewClassComponent } from '../admin-new-class/admin-new-class.component';
import { AdminRemainderComponent } from '../admin-remainder/admin-remainder.component';
import { RescheduleComponent } from '../reschedule/reschedule.component';
import { PaymentHistoryComponent } from '../payment-history/payment-history.component';
import { FeedbackComponent } from "../feedback/feedback.component";

@Component({
  selector: 'app-admin-sidebar',
  standalone: true,
  templateUrl: './admin-sidebar.component.html',
  styleUrl: './admin-sidebar.component.scss',
  imports: [
    MatIconModule,
    MatTooltipModule,
    NgIf,
    NgClass,
    NgFor,
    NgSwitch,
    NgSwitchCase,
    AdminTeacherComponent,
    AdminParentComponent,
    AdminTrialClassComponent,
    AdminNewClassComponent,
    AdminRemainderComponent,
    RescheduleComponent,
    PaymentHistoryComponent,
    FeedbackComponent
],
})
export class AdminSidebarComponent {
  isSideNavOpened: boolean = true;

  navigationArrays = [
    {
      icon: 'school',
      items: 'Teacher',
    },
    {
      icon: 'fiber_new',
      items: 'New Class',
    },
    {
      icon: 'school',
      items: 'Trial Class',
    },
    {
      icon: 'people',
      items: 'Fees',
    },
    {
      icon: 'attach_money',
      items: 'Remainder',
    },
    {
      icon: 'access_time',
      items: 'Reschedule',
    },
    {
      icon: 'history',
      items: 'Payment History',
    },
    {
      icon: 'feedback',
      items: 'Feedback',
    },
  ];
  currentNavItem: string = 'Profile';
  constructor(private adminService: AdminService) {}

  ngOnInit() {
    this.adminService.currentNavItem.subscribe((navItem) => {
      this.currentNavItem = navItem;
    });
    this.checkWidth();
  }

  closeSideNav() {
    this.isSideNavOpened = !this.isSideNavOpened;
  }

  changeNavItem(item: string) {
    this.adminService.setCurrentNavItem(item);
  }

  @HostListener('window:resize', ['$event'])
  onResize(event: any) {
    this.checkWidth();
  }

  checkWidth() {
    const screenWidth = window.innerWidth;
    if (screenWidth < 769) {
      // Adjust this value as per your mobile view breakpoint
      this.mobileViewMethod();
    } else if (screenWidth >= 769 && screenWidth <= 1024) {
      // Adjust the range for tablet view as per your requirement
      this.mobileViewMethod();
    } else {
      this.desktopViewMethod();
    }
  }

  mobileViewMethod() {
    // Method to trigger when viewport width is in mobile view
    this.isSideNavOpened = false;
  }

  desktopViewMethod() {
    // Method to trigger when viewport width is greater than mobile view
    this.isSideNavOpened = true;
  }
}
