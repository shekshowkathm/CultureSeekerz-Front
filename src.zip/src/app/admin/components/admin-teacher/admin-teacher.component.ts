import { Component, ElementRef, ViewChild } from '@angular/core';
import { AdminService } from '../../service/admin.service';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { NgFor, NgIf } from '@angular/common';
import { CdkDrag } from '@angular/cdk/drag-drop';
import { MatIconModule } from '@angular/material/icon';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import Swal from 'sweetalert2';
import {
  MatTabChangeEvent,
  MatTabGroup,
  MatTabsModule,
} from '@angular/material/tabs';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-admin-teacher',
  standalone: true,
  imports: [
    MatTableModule,
    MatPaginator,
    MatSort,
    NgFor,
    CdkDrag,
    NgIf,
    MatIconModule,
    MatSlideToggleModule,
    MatTabsModule,
    MatButtonModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  templateUrl: './admin-teacher.component.html',
  styleUrl: './admin-teacher.component.scss',
})
export class AdminTeacherComponent {
  displayedColumns: string[] = [
    'serialNumber',
    'basicInfo',
    'email',
    'gender',
    'ug',
    'pg',
    'bed',
    'med',
    'specializedIn',
    'certificate',
    'status',
  ]; // Add more columns as needed
  displayedColumnsForCertificate: string[] = [
    'name',
    'uGCertificate',
    'pGCertificate',
    'bedCertificate',
    'medCertificate',
    'idProof',
    'expCert',
    'status',
  ];
  dataSource!: MatTableDataSource<any>;
  dataSourceForCertificate: MatTableDataSource<any>;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('teacherMatSort') teacherMatSort: MatSort;
  @ViewChild('teacherMatPaginator') teacherMatPaginator: MatPaginator;
  public teacherResponse: any;
  public certificateResponse: any;

  viewCertificate: boolean = false;
  certificateLink: string = '';
  width = 300; // initial width
  height = 350; // initial height
  hover = false;
  resizeCursor = 'auto';
  startX: number;
  startY: number;

  selectedActivity: string = '';

  isApproved: boolean = true;

  activityList = [
    'tamil',
    'bible',
    'carnatic',
    'shloka',
    'chess',
    'programming',
    'maths',
    'science',
    'telugu',
    'yoga',
    'Mridangam',
    'Hindi',
  ];

  @ViewChild('tabGroup', { static: true }) tabGroup: MatTabGroup;

  searchValue: string = '';

  isTabSearch: boolean = true;

  constructor(
    private adminService: AdminService,
    private elementRef: ElementRef
  ) {}

  ngOnInit() {
    this.fetchteacherData('Tamil');
  }
  ngAfterViewInit() {
    // this.dataSource.sort = this.sort;
  }
  fetchteacherData(activity: string): void {
    if (this.isTabSearch) {
      if (this.isApproved) {
        this.adminService
          .getteacherData('retrieveTeachers/', activity, this.isApproved)
          .subscribe({
            next: (response: any) => {
              this.teacherResponse = response;
              this.dataSource = new MatTableDataSource(this.teacherResponse);
              this.dataSource.sort = this.sort;
              this.dataSource.paginator = this.paginator; // Set paginator here
              this.dataSource.paginator.pageSize = 25;
              this.dataSource.sort = this.sort;
              this.certificateResponse = response;
              this.dataSourceForCertificate = new MatTableDataSource(
                this.certificateResponse
              );
              this.dataSourceForCertificate.sort = this.teacherMatSort;
              this.dataSourceForCertificate.paginator =
                this.teacherMatPaginator;
            },
            error: (error: any) => {
              console.error('Error fetching data:', error);
            },
          });
      } else {
        this.adminService
          .getteacherData('retrieveTeachers/', activity, this.isApproved)
          .subscribe({
            next: (response: any) => {
              this.teacherResponse = response;
              this.dataSource = new MatTableDataSource(this.teacherResponse);
              this.dataSource.sort = this.sort;
              this.dataSource.paginator = this.paginator; // Set paginator here
              this.dataSource.paginator.pageSize = 25;
              this.dataSource.sort = this.sort;
              this.certificateResponse = response;
              this.dataSourceForCertificate = new MatTableDataSource(
                this.certificateResponse
              );
              this.dataSourceForCertificate.sort = this.teacherMatSort;
              this.dataSourceForCertificate.paginator =
                this.teacherMatPaginator;
            },
            error: (error: any) => {
              console.error('Error fetching data:', error);
            },
          });
      }
    }
  }

  closeViewCertificate() {
    this.viewCertificate = false;
  }

  showCertificateImage(imageLink: string) {
    this.viewCertificate = true;
    this.certificateLink = imageLink;
  }

  changeStatus(checked: boolean, teacherid: string) {
    if (checked) {
      Swal.fire({
        title: 'Are you sure to approve this teacher?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes',
        cancelButtonText: 'No',
      }).then((result) => {
        if (result.isConfirmed) {
          this.statusMethod(teacherid);
        } else {
          // No action needed, user canceled
          this.fetchteacherData(this.selectedActivity);
        }
      });
    } else {
      Swal.fire({
        title: 'Do you want to disapprove this teacher?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes',
        cancelButtonText: 'No',
      }).then((result) => {
        if (result.isConfirmed) {
          this.statusMethod(teacherid);
        } else {
          // User canceled
          this.fetchteacherData(this.selectedActivity);
        }
      });
    }
  }

  statusMethod(teacherid: string) {
    this.adminService.approveTeacher(teacherid).subscribe({
      next: (data) => {
        this.fetchteacherData(this.selectedActivity);
      },
      error: (error) => {
        console.error('Error fetching teachers:', error);
      },
    });
  }

  startHover() {
    this.hover = true;
    this.setResizeCursor();
  }

  stopHover() {
    this.hover = false;
    this.setResizeCursor();
  }

  onMouseMove(event: MouseEvent) {
    if (this.hover) {
      const element = this.elementRef.nativeElement.querySelector(
        '.image-area'
      ) as HTMLElement;
      const rect = element.getBoundingClientRect();
      if (event.clientX > rect.right - 10 || event.clientY > rect.bottom - 10) {
        this.setResizeCursor();
      } else {
        this.resizeCursor = 'auto';
      }
    }
  }

  setResizeCursor() {
    this.resizeCursor = 'nwse-resize';
  }

  startResizing(event: MouseEvent) {
    this.startX = event.clientX;
    this.startY = event.clientY;
    document.addEventListener('mousemove', this.resize);
    document.addEventListener('mouseup', this.stopResizing);
  }

  stopResizing = () => {
    document.removeEventListener('mousemove', this.resize);
    document.removeEventListener('mouseup', this.stopResizing);
  };

  resize = (event: MouseEvent) => {
    const newWidth = this.width + (event.clientX - this.startX);
    const newHeight = this.height + (event.clientY - this.startY);
    this.width = Math.max(100, newWidth); // minimum width
    this.height = Math.max(75, newHeight); // minimum height
    this.startX = event.clientX;
    this.startY = event.clientY;
  };

  showCertificatePDF(link: string) {
    window.open(link, '_blank');
  }

  tabChanged(event: MatTabChangeEvent): void {
    const label = event.tab.textLabel;

    const modifiedLabel = label.charAt(0).toLowerCase() + label.slice(1);
    this.selectedActivity = label;
    console.log(this.selectedActivity);

    this.fetchteacherData(this.selectedActivity);
  }

  capitalizeFirstLetter(word: string): string {
    return word.charAt(0).toUpperCase() + word.slice(1);
  }

  approvedTeachers() {
    this.isApproved = true;
    if (this.selectedActivity === '') {
      this.selectedActivity = 'Tamil';
    }
    this.fetchteacherData(this.selectedActivity);
  }
  nonapprovedTeachers() {
    this.isApproved = false;
    if (this.selectedActivity === '') {
      this.selectedActivity = 'Tamil';
    }
    this.fetchteacherData(this.selectedActivity);
  }

  onSearch(): void {
    console.log(this.searchValue);
    this.isTabSearch = false;
    this.adminService.getSearchTeacherData(this.searchValue).subscribe({
      next: (response: any) => {
        this.teacherResponse = response;
        // console.log(this.teacherResponse.teacher.specializedIn[0].toLowerCase());

        // console.log(this.teacherResponse);
        const activity =
        response[0].teacher.specializedIn[0].toLowerCase();
          console.log(activity);
          

        const activityIndex = this.activityList.indexOf(activity);
        if (activityIndex !== -1) {
          this.tabGroup.selectedIndex = activityIndex;
        }

        setTimeout(() => {
          this.searchValue = '';
          this.isTabSearch = true;

          console.log(this.teacherResponse);
          

          this.dataSource = new MatTableDataSource(this.teacherResponse);
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator; // Set paginator here
          this.dataSource.paginator.pageSize = 25;
          this.dataSource.sort = this.sort;
          this.certificateResponse = response;
          this.dataSourceForCertificate = new MatTableDataSource(
            this.certificateResponse
          );
          this.dataSourceForCertificate.sort = this.teacherMatSort;
          this.dataSourceForCertificate.paginator = this.teacherMatPaginator;
        }, 1250);
      },
      error: (error: any) => {
        console.error('Error fetching data:', error);
      },
    });
  }
}
