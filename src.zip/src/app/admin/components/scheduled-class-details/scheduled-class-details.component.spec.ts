import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ScheduledClassDetailsComponent } from './scheduled-class-details.component';

describe('ScheduledClassDetailsComponent', () => {
  let component: ScheduledClassDetailsComponent;
  let fixture: ComponentFixture<ScheduledClassDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ScheduledClassDetailsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ScheduledClassDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
