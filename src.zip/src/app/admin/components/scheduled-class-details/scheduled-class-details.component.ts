import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-scheduled-class-details',
  standalone: true,
  imports: [MatIconModule],
  templateUrl: './scheduled-class-details.component.html',
  styleUrl: './scheduled-class-details.component.scss',
})
export class ScheduledClassDetailsComponent {
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<ScheduledClassDetailsComponent>
  ) {
  }

  closeDialog(): void {
    this.dialogRef.close();
  }
}
