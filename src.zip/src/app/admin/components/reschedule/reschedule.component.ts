import { Component, ViewChild } from '@angular/core';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { NgFor, NgIf } from '@angular/common';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatIconModule, MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminService } from '../../service/admin.service';
import { MatDialog } from '@angular/material/dialog';
import Swal from 'sweetalert2';
import {
  MatTabChangeEvent,
  MatTabGroup,
  MatTabsModule,
} from '@angular/material/tabs';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { RescheduleInfoComponent } from '../reschedule-info/reschedule-info.component';
import { MatInputModule } from '@angular/material/input';

@Component({
  selector: 'app-reschedule',
  standalone: true,
  imports: [
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatSortModule,
    MatPaginatorModule,
    NgFor,
    MatTooltipModule,
    MatIconModule,
    NgIf,
    MatButtonModule,
    FormsModule,
    ReactiveFormsModule,
    MatSlideToggleModule,
    MatTabsModule,
    MatSelectModule,
    MatInputModule,
  ],
  templateUrl: './reschedule.component.html',
  styleUrl: './reschedule.component.scss',
})
export class RescheduleComponent {
  isApproved: boolean = true;

  selectedActivity: string = '';

  activityList = [
    'tamil',
    'bible',
    'carnatic',
    'shloka',
    'chess',
    'programming',
    'maths',
    'science',
    'telugu',
    'yoga',
    'Mridangam',
    'Hindi',
  ];

  displayedColumns: string[] = [
    's.No',
    'teacherInfo',
    'parentInfo',
    'studentInfo',
    'scheduleDays',
    'selectedDate',
    'selectDays',
    'select date',
    'status',
  ];
  dataSource = new MatTableDataSource<any>();

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  selectedOption: any;
  minDate: string;
  newDate;
  studentId;
  dayAndTimeId;
  newStartTime;
  newEndTime;

  @ViewChild('tabGroup', { static: true }) tabGroup: MatTabGroup;

  searchValue: string = '';

  isTabSearch: boolean = true;

  constructor(private adminService: AdminService, public dialog: MatDialog) {}

  ngOnInit(): void {
    this.getReschedule('Tamil');
    this.setMinDate();
  }

  getReschedule(activity: string) {
    if (this.isTabSearch) {
      if (this.isApproved) {
        this.adminService
          .getReschudlesValues(
            'getrescheduleclasses/',
            activity,
            this.isApproved
          )
          .subscribe({
            next: (response) => {
              console.log(response);

              this.dataSource.data = response;
              this.dataSource.paginator = this.paginator;
              this.dataSource.sort = this.sort;

              // Assign the response to the object property
              // Handle success, if needed
            },
            error: (error) => {
              console.error('Error retrieving object:', error);
              // Handle error, if needed
            },
          });
      } else {
        this.adminService
          .getReschudlesValues(
            'getrescheduleclasses/',
            activity,
            this.isApproved
          )
          .subscribe({
            next: (response) => {
              console.log(response);

              this.dataSource.data = response;
              this.dataSource.paginator = this.paginator;
              this.dataSource.sort = this.sort;

              // Assign the response to the object property
              // Handle success, if needed
            },
            error: (error) => {
              console.error('Error retrieving object:', error);
              // Handle error, if needed
            },
          });
      }
    }
  }

  setMinDate() {
    const today = new Date();
    const day = String(today.getDate()).padStart(2, '0');
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const year = today.getFullYear();
    this.minDate = `${year}-${month}-${day}`;
  }

  tabChanged(event: MatTabChangeEvent): void {
    const label = event.tab.textLabel;

    const modifiedLabel = label.charAt(0).toLowerCase() + label.slice(1);
    this.selectedActivity = label;
    console.log(this.selectedActivity);
    this.getReschedule(this.selectedActivity);
  }

  capitalizeFirstLetter(word: string): string {
    return word.charAt(0).toUpperCase() + word.slice(1);
  }

  approvedPayments() {
    this.isApproved = true;
    if (this.selectedActivity === '') {
      this.selectedActivity = 'Tamil';
    }
    this.getReschedule(this.selectedActivity);
  }
  nonapprovedPayments() {
    this.isApproved = false;
    if (this.selectedActivity === '') {
      this.selectedActivity = 'Tamil';
    }
    this.getReschedule(this.selectedActivity);
  }

  onSelectChange(dayAndTimeId: string, element: any) {
    // console.log(element);
    // console.log(dayAndTimeId);

    const selectedOption = element.dayAndTimeDTO.find(
      (option) => option.dayAndTimeId === +dayAndTimeId
    );
    // console.log(selectedOption);
    // console.log(element.student.studentId);

    // console.log(selectedOption.dayAndTimeId);
    // console.log(selectedOption.startTime);
    // console.log(selectedOption.endTime);
    this.studentId = element.student.studentId;
    this.dayAndTimeId = selectedOption.dayAndTimeId;
    this.newStartTime = selectedOption.startTime;
    this.newEndTime = selectedOption.endTime;
  }

  rescheduleClass() {
    // console.log(this.newDate);
    // console.log(this.studentId);
    // console.log(this.dayAndTimeId);
    // console.log(this.newStartTime);
    // console.log(this.newEndTime);
    const scheduleObject = {
      studentId: this.studentId,
      dayAndTimeId: this.dayAndTimeId,
      newDate: this.newDate,
      newStartTime: this.newStartTime,
      newEndTime: this.newEndTime,
    };

    this.adminService.rescheduleClass(scheduleObject).subscribe({
      next: (response) => {
        console.log(response);
      },
      error: (error) => {
        console.error('Error retrieving object:', error);
        // Handle error, if needed
      },
    });
  }

  openDialog(role: any, element): void {
    const dialogRef = this.dialog.open(RescheduleInfoComponent, {
      width: 'auto',
      height: 'auto',
      data: { role: role, element: element },
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log('The dialog was closed');
      console.log(result);
    });
  }

  onSearch(): void {
    console.log(this.searchValue);
    this.isTabSearch = false;

    this.adminService.getSearchReschudlesValues(this.searchValue).subscribe({
      next: (response) => {
        console.log(response);

        const activity = response[0].activity.toLowerCase();
        console.log(activity);

        const activityIndex = this.activityList.indexOf(activity);
        if (activityIndex !== -1) {
          this.tabGroup.selectedIndex = activityIndex;
        }

        setTimeout(() => {
          this.searchValue = '';
          this.isTabSearch = true;

          this.dataSource.data = response;
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }, 1250);

        // Assign the response to the object property
        // Handle success, if needed
      },
      error: (error) => {
        console.error('Error retrieving object:', error);
        // Handle error, if needed
      },
    });
  }
}
