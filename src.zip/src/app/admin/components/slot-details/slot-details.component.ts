import { NgFor, NgIf } from '@angular/common';
import { Component, Inject, ViewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { AdminService } from '../../service/admin.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import Swal from 'sweetalert2';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';

@Component({
  selector: 'app-slot-details',
  standalone: true,
  imports: [
    MatIconModule,
    FormsModule,
    ReactiveFormsModule,
    NgIf,
    NgFor,
    MatButtonModule,
    HttpClientModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatSortModule,
    MatPaginatorModule,
  ],
  templateUrl: './slot-details.component.html',
  styleUrl: './slot-details.component.scss',
  providers: [HttpClient, AdminService],
})
export class SlotDetailsComponent {

  objectData: any[] = [];

  displayedColumns: string[] = ['day', 'startDate', 'endDate', 'meetingLink', 'actions'];
  dataSource = new MatTableDataSource<any>([]);
  editingRowIndex: number = -1;

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(
    public dialogRef: MatDialogRef<SlotDetailsComponent>,
    private adminService: AdminService,
    @Inject(MAT_DIALOG_DATA) public object: any
  ) {
    console.log(object);
    this.objectData = object.scheduleClass.dayAndTimeDTO;
    console.log(this.objectData);
    
  }

  ngOnInit(): void {
    this.dataSource.data = this.objectData.map(item => ({ ...item, editing: false }));
  }

  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  editRow(index: number) {
    this.dataSource.data.forEach((item, i) => {
      item.editing = index === i;
    });
  }

  saveRow(index: number) {
    const row = this.dataSource.data[index];
    console.log('Row Data:', row);
    console.log('Meeting Link:', row.meetingLink);
    row.editing = false;
    console.log(row.dayAndTimeId);
    this.adminService.updateMeetingLinkForSlotDetails(row.dayAndTimeId,row.meetingLink).subscribe({
      next:(response:any)=>{
        console.log(response);
        
      },
      error: (error) => {
        console.error('Error retrieving object:', error);
        // Handle error, if needed
      },
    })

    
  }

  // enableEditMode(index: number) {
  //   this.editModeIndex = index;
  // }

  // saveData(
  //   index: number,
  //   slot: any,
  //   slotid: any,
  //   timeInput,
  //   link: any,
  //   startDate: any,
  //   endDate: any,
  //   selectedDay
  // ) {
  //   // Call your API to save data here, for demonstration, let's just log the data
  //   this.editModeIndex = -1;
  //   // console.log(timeInput);

  //   const updateObject = {
  //     // id: slotid,
  //     // time: time,
  //     // meetingLink: link,
  //     // activeClass: {
  //     //   id: this.classid,
  //     // },

  //     id: slotid,
  //     time: timeInput,
  //     meetingLink: link,
  //     startDate: startDate,
  //     endDate: endDate,
  //     day: selectedDay,
  //     activeClass: {
  //       id: this.classid,
  //     },
  //   };
  //   this.adminService.updateSlotReceivedData(updateObject).subscribe({
  //     next: (data) => {
  //       Swal.fire({
  //         title: 'Success!',
  //         text: 'Slot updated successfully',
  //         icon: 'success',
  //         confirmButtonText: 'OK',
  //       }).then((result) => {
  //         if (result.isConfirmed) {
  //           // Call your method here
  //           // For example:
  //           this.closeDialog();
  //         }
  //       });
  //     },
  //     error: (error) => {
  //       console.error('Error fetching teachers:', error);
  //     },
  //   });
  // }

  // onDaySelection(event: Event, dayAndTimeDTO) {
  //   const selectedDay = (event.target as HTMLSelectElement).value;
  //   // You can call other methods or perform any logic here

  //   const filterredData = dayAndTimeDTO.filter(
  //     (item) => item.day === selectedDay
  //   );
  //   // console.log(filterredData[0].time);
  //   this.selectedDayTimes = filterredData[0].time;
  //   console.log(this.selectedDayTimes);
  // }

  // initializeSelectedDays(dataLength: number): void {
  //   for (let i = 0; i < dataLength; i++) {
  //     this.selectedDays.push('');
  //   }
  // }

  // onDaySelectionsss(event: any, index: number,dayAndTimeDTO): void {
  //   // Update the selected day for the specific row
  //   this.selectedDays[index] = event.target.value;
  //   const selectedDay = (event.target as HTMLSelectElement).value;
  //   const filterredData = dayAndTimeDTO.filter(
  //     (item) => item.day === selectedDay
  //   );
  //   // console.log(filterredData[0].time);
  //   this.selectedDayTimes = filterredData[0].time;
  //   console.log(this.selectedDayTimes);
  // }

  // onTimeSelection(event: any, rowData: any): void {
  //   rowData.time = event.target.value;
  // }
}
