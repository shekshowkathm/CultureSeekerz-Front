import { NgFor, NgIf } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA,MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-payment-teacher-info',
  standalone: true,
  imports: [NgIf,NgFor,MatIconModule],
  templateUrl: './payment-teacher-info.component.html',
  styleUrl: './payment-teacher-info.component.scss',
})
export class PaymentTeacherInfoComponent {
  tableInfo;
  type:string;
  constructor(public dialogRef: MatDialogRef<PaymentTeacherInfoComponent>,@Inject(MAT_DIALOG_DATA) public data: any) {
    this.type=data.type
    this.tableInfo = data.data;
    console.log(this.tableInfo);
  }

  closeDialog(): void {
    this.dialogRef.close();
  }
}
