import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentTeacherInfoComponent } from './payment-teacher-info.component';

describe('PaymentTeacherInfoComponent', () => {
  let component: PaymentTeacherInfoComponent;
  let fixture: ComponentFixture<PaymentTeacherInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PaymentTeacherInfoComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PaymentTeacherInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
