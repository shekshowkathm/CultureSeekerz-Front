import { NgFor, NgIf } from '@angular/common';
import { Component, ViewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatTabsModule } from '@angular/material/tabs';
import { AdminService } from '../../service/admin.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-feedback',
  standalone: true,
  imports: [
    MatIconModule,
    MatButtonModule,
    FormsModule,
    ReactiveFormsModule,
    MatInputModule,
    MatTableModule,
    MatPaginator,
    MatSort,
    NgFor,
    NgIf,
    MatTabsModule,
    MatSlideToggleModule,
    MatSelectModule,
    NgFor,
    NgIf,
  ],
  templateUrl: './feedback.component.html',
  styleUrl: './feedback.component.scss',
})
export class FeedbackComponent {
  displayedColumns: string[] = [
    'id',
    'name',
    'email',
    'phone',
    'feedback',
    'approached',
  ];

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  dataSource!: MatTableDataSource<any>;
  isApproved: boolean = true;
  searchValue: string = '';

  isTabSearch: boolean = true;

  isExpanded: boolean[] = [];

  constructor(private adminService: AdminService) {}

  ngOnInit() {
    this.approvedFeedback();
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  toggleApproached(element: any) {
    element.approached = !element.approached;
  }

  /**
   * Toggles the read more/read less state for a specific row.
   * @param index The index of the row in the table.
   */
  toggleReadMore(index: number) {
    this.isExpanded[index] = !this.isExpanded[index];
  }

  /**
   * Returns truncated text if it's longer than 40 characters.
   * @param text The original feedback text.
   * @returns The truncated text with '...' if needed.
   */
  getTruncatedText(text: string): string {
    return text.length > 40 ? text.substring(0, 40) + '...' : text;
  }

  onSearch(): void {}

  approvedFeedback() {
    this.isApproved = true;
    this.adminService.getFeedbackInfo('getallapprachesbytrue').subscribe({
      next: (response) => {
        console.log(response);
        this.dataSource = new MatTableDataSource(response);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      },
      error: (err) => {
        console.log(err);
      },
    });
  }
  nonapprovedFeedback() {
    this.isApproved = false;
    this.adminService.getFeedbackInfo('getallapprachesbyfalse').subscribe({
      next: (response) => {
        console.log(response);
        this.dataSource = new MatTableDataSource(response);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      },
      error: (err) => {
        console.log(err);
      },
    });
  }

  onApproachedChange(event: any, element: any) {
    const originalApproachedValue = element.approached;

    // Temporarily prevent the toggle from changing
    event.source.checked = originalApproachedValue;

    Swal.fire({
      title: 'Are you sure?',
      text: 'Are you sure you have approached this feedback?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, update it!',
      cancelButtonText: 'No, cancel!',
      reverseButtons: true,
    }).then((result) => {
      if (result.isConfirmed) {
        // If confirmed, change the approached value and trigger your PUT request
        element.approached = !originalApproachedValue; // Update the toggle state
        event.source.checked = element.approached; // Set the UI toggle to new state
        this.updateFeedback(element); // Call the API
      } else {
        // If cancelled, revert the toggle to its original state
        event.source.checked = originalApproachedValue;
      }
    });
  }

  updateFeedback(element) {
    console.log(element);
    this.adminService.updatefeedback(element.id).subscribe({
      next: (response) => {
        console.log(response);
        if (this.isApproved) {
          this.approvedFeedback();
        } else {
          this.nonapprovedFeedback();
        }
      },
      error: (err) => {
        console.log(err);
      },
    });
  }
}
