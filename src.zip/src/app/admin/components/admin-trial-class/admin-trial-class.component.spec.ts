import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminTrialClassComponent } from './admin-trial-class.component';

describe('AdminTrialClassComponent', () => {
  let component: AdminTrialClassComponent;
  let fixture: ComponentFixture<AdminTrialClassComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminTrialClassComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AdminTrialClassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
