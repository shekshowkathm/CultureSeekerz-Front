import { Component, ViewChild } from '@angular/core';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { NgFor, NgIf } from '@angular/common';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatIconModule, MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminService } from '../../service/admin.service';
import {
  MatTabChangeEvent,
  MatTabGroup,
  MatTabsModule,
} from '@angular/material/tabs';
import { MatInputModule } from '@angular/material/input';

@Component({
  selector: 'app-admin-trial-class',
  standalone: true,
  imports: [
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatSortModule,
    MatPaginatorModule,
    NgFor,
    MatTooltipModule,
    MatIconModule,
    NgIf,
    MatButtonModule,
    FormsModule,
    MatTabsModule,
    ReactiveFormsModule,
    MatInputModule,
  ],
  templateUrl: './admin-trial-class.component.html',
  styleUrl: './admin-trial-class.component.scss',
  providers: [HttpClient, MatIconRegistry],
})
export class AdminTrialClassComponent {
  trialClassDetails = [
    {
      id: 1,
      teacherEmail: 'tamilselvanKS470@gmail.com',
      phoneNumber: '9087654321',
      activity: 'chess',
      meetingLink: null,
      studentCount: 9,
      time: null,
      date: null,
      teacherName: 'tamilselvan',
      studentEmail: [
        'dharanidhasebastin07@gmail.com',
        'sridharsrid25@gmail.com',
        'josephinerani2002@gmail.com',
        'dharanidhasebastin07@gmail.com',
        'sridharsrid25@gmail.com',
        'josephinerani2002@gmail.com',
      ],
    },
    {
      id: 2,
      teacherEmail: 'shekshowkath@gmail.com',
      phoneNumber: '123456789',
      activity: 'Carrom',
      meetingLink: null,
      studentCount: 2,
      time: null,
      date: null,
      teacherName: 'Shek Showkath',
      studentEmail: ['sridharsrid25@gmail.com', 'josephinerani2002@gmail.com'],
    },
    {
      id: 1,
      teacherEmail: 'tamilselvanKS470@gmail.com',
      phoneNumber: '9087654321',
      activity: 'chess',
      meetingLink: null,
      studentCount: 3,
      time: null,
      date: null,
      teacherName: 'tamilselvan',
      studentEmail: [
        'dharanidhasebastin07@gmail.com',
        'sridharsrid25@gmail.com',
        'josephinerani2002@gmail.com',
      ],
    },
    {
      id: 2,
      teacherEmail: 'shekshowkath@gmail.com',
      phoneNumber: '123456789',
      activity: 'Carrom',
      meetingLink: null,
      studentCount: 2,
      time: null,
      date: null,
      teacherName: 'Shek Showkath',
      studentEmail: ['sridharsrid25@gmail.com', 'josephinerani2002@gmail.com'],
    },
    {
      id: 1,
      teacherEmail: 'tamilselvanKS470@gmail.com',
      phoneNumber: '9087654321',
      activity: 'chess',
      meetingLink: null,
      studentCount: 3,
      time: null,
      date: null,
      teacherName: 'tamilselvan',
      studentEmail: [
        'dharanidhasebastin07@gmail.com',
        'sridharsrid25@gmail.com',
        'josephinerani2002@gmail.com',
      ],
    },
    {
      id: 2,
      teacherEmail: 'shekshowkath@gmail.com',
      phoneNumber: '123456789',
      activity: 'Carrom',
      meetingLink: null,
      studentCount: 2,
      time: null,
      date: null,
      teacherName: 'Shek Showkath',
      studentEmail: ['sridharsrid25@gmail.com', 'josephinerani2002@gmail.com'],
    },
    {
      id: 1,
      teacherEmail: 'tamilselvanKS470@gmail.com',
      phoneNumber: '9087654321',
      activity: 'chess',
      meetingLink: null,
      studentCount: 3,
      time: null,
      date: null,
      teacherName: 'tamilselvan',
      studentEmail: [
        'dharanidhasebastin07@gmail.com',
        'sridharsrid25@gmail.com',
        'josephinerani2002@gmail.com',
      ],
    },
    {
      id: 2,
      teacherEmail: 'shekshowkath@gmail.com',
      phoneNumber: '123456789',
      activity: 'Carrom',
      meetingLink: null,
      studentCount: 2,
      time: null,
      date: null,
      teacherName: 'Shek Showkath',
      studentEmail: ['sridharsrid25@gmail.com', 'josephinerani2002@gmail.com'],
    },
  ];

  dataSource: MatTableDataSource<any>;
  displayedColumns: string[] = [
    'serialNumber',
    'teacherName',
    // 'phoneNumber',
    // 'activity',
    'meetingLink',
    // 'studentCount',
    'time',
    'date',

    'studentEmail',
    'feedback',
    'timeZone',
  ];

  trialClassArrayAPI: any;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  enterLink: boolean[] = [];
  dateInput: string = '';
  timeInput: string = '';
  linkInput: string = '';
  selectedTimeZone: string = '';

  selectedActivity: string = 'Tamil';

  activityList = [
    'tamil',
    'bible',
    'carnatic',
    'shloka',
    'chess',
    'programming',
    'maths',
    'science',
    'telugu',
    'yoga',
    'Mridangam',
    'Hindi',
    'all',
  ];

  isApproved: boolean = true;

  @ViewChild('tabGroup', { static: true }) tabGroup: MatTabGroup;

  searchValue: string = '';

  isTabSearch: boolean = true;

  constructor(
    private matIconRegistry: MatIconRegistry,
    private domSanitizer: DomSanitizer,
    private adminService: AdminService
  ) {
    this.matIconRegistry.addSvgIcon(
      'icon', // Icon name
      this.domSanitizer.bypassSecurityTrustResourceUrl('assets/teams.svg') // Icon URL
    );
  }

  ngOnInit(): void {
    this.getTrailClassesData('Tamil');
  }

  // ngAfterViewInit(): void {
  //   this.dataSource.paginator = this.paginator;
  //   this.dataSource.sort = this.sort;
  // }

  // formatTime(time: string): string {
  //   const [hours, minutes] = time.split(':');
  //   let formattedTime = '';

  //   // Convert hours to 12-hour format
  //   let hour = parseInt(hours, 10);
  //   const amPm = hour >= 12 ? 'PM' : 'AM';
  //   hour = hour % 12 || 12; // Handle midnight

  //   formattedTime = `${hour}:${minutes} ${amPm}`;

  //   return formattedTime;
  // }

  formatTime(time: string): string {
    const [hours, minutes] = time.split(':');
    let formattedTime = '';

    // Convert hours to 24-hour format
    let hour = parseInt(hours, 10);
    const amPm = hour >= 12 ? 'PM' : 'AM';
    hour = hour % 24; // Ensure hour is in the 24-hour range

    // Pad the hour with leading zero if necessary
    const paddedHour = hour.toString().padStart(2, '0');

    formattedTime = `${paddedHour}:${minutes}`;

    return formattedTime;
  }

  openTeams(): void {
    // Open Microsoft Teams
    window.open('msteams://', '_blank');
  }

  initializeLinkVisibility(): void {
    this.enterLink = new Array(this.dataSource.data.length).fill(true); // Set all rows initially visible
  }

  // Function to toggle visibility of link input fields for a specific row
  toggleLinkVisibility(index: number, row: any): void {
    this.enterLink[index] = !this.enterLink[index];
    row.meetingLink = this.linkInput;
    row.time = this.formatTime(this.timeInput);
    row.date = this.dateInput;
    row.timeZone = this.selectedTimeZone;
    this.adminService.updateObject(row).subscribe({
      next: (response) => {
        // Handle success, if needed
        this.selectedTimeZone = '';
        this.dateInput = '';
        this.linkInput = '';
        this.timeInput = '';
        this.getTrailClassesData(this.selectedActivity);
      },
      error: (error) => {
        console.error('Error updating object:', error);
        // Handle error, if needed
        this.selectedTimeZone = '';
        this.dateInput = '';
        this.linkInput = '';
        this.timeInput = '';
      },
    });
  }



  showInputs(index: number) {
    this.enterLink[index] = !this.enterLink[index];
  }

  getTrailClassesData(activity: string): void {
    if (this.isTabSearch) {
      if (this.isApproved) {
        this.adminService
          .getTrialClasses('getTrialClasses/', activity, this.isApproved)
          .subscribe({
            next: (response) => {
              this.trialClassArrayAPI = response;
              this.dataSource = new MatTableDataSource(this.trialClassArrayAPI);
              this.dataSource.paginator = this.paginator;
              this.dataSource.sort = this.sort;
              this.initializeLinkVisibility();
              // Assign the response to the object property
              // Handle success, if needed
            },
            error: (error) => {
              console.error('Error retrieving object:', error);
              // Handle error, if needed
            },
          });
      } else {
        this.adminService
          .getTrialClasses('getTrialClasses/', activity, this.isApproved)
          .subscribe({
            next: (response) => {
              this.trialClassArrayAPI = response;
              this.dataSource = new MatTableDataSource(this.trialClassArrayAPI);
              this.dataSource.paginator = this.paginator;
              this.dataSource.sort = this.sort;
              this.initializeLinkVisibility();
              // Assign the response to the object property
              // Handle success, if needed
            },
            error: (error) => {
              console.error('Error retrieving object:', error);
              // Handle error, if needed
            },
          });
      }
    }
  }

  tabChanged(event: MatTabChangeEvent): void {
    const label = event.tab.textLabel;

    const modifiedLabel = label.charAt(0).toLowerCase() + label.slice(1);
    this.selectedActivity = label;
    this.getTrailClassesData(this.selectedActivity);
  }

  capitalizeFirstLetter(word: string): string {
    return word.charAt(0).toUpperCase() + word.slice(1);
  }

  approvedPayments() {
    this.isApproved = true;
    if (this.selectedActivity === '') {
      this.selectedActivity = 'Tamil';
    }
    this.getTrailClassesData(this.selectedActivity);
  }
  nonapprovedPayments() {
    this.isApproved = false;
    if (this.selectedActivity === '') {
      this.selectedActivity = 'Tamil';
    }
    this.getTrailClassesData(this.selectedActivity);
  }

  onSearch(): void {
    console.log(this.searchValue);
    this.isTabSearch = false;

    this.adminService.getSearchTrialClasses(this.searchValue).subscribe({
      next: (response) => {
        this.trialClassArrayAPI = response;

        const activity = 'all';
        console.log(activity);

        const activityIndex = this.activityList.indexOf(activity);
        if (activityIndex !== -1) {
          this.tabGroup.selectedIndex = activityIndex;
        }

        setTimeout(() => {
          this.searchValue = '';
          this.isTabSearch = true;

          this.dataSource = new MatTableDataSource(this.trialClassArrayAPI);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
          this.initializeLinkVisibility();
        }, 1250);

        // Assign the response to the object property
        // Handle success, if needed
      },
      error: (error) => {
        console.error('Error retrieving object:', error);
        // Handle error, if needed
      },
    });
  }


  isFormValid(i: number): boolean {
    return (
      this.linkInput?.trim() !== '' &&
      this.dateInput !== '' &&
      this.timeInput !== '' &&
      this.selectedTimeZone?.trim() !== undefined &&
      this.selectedTimeZone?.trim() !== '' &&
      !this.enterLink[i]
    );
  }
  
}
