import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { environment } from '../../../environments/environment.development';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class AdminService {
  private currentNavItemSubject!: BehaviorSubject<string>;
  public currentNavItem!: Observable<string>;
  public getAllTeacherURL = environment.localdomain + '/teacher/';
  public getSearchTeacherURL =
    environment.localdomain + '/teacher/getTeacherByuniqueId/';
  public approveTeacherURL =
    environment.localdomain + '/teacher/aprroveteacher/';
  public approveClassURL =
    environment.localdomain + '/activeclass/approveclass/';
  public sendEmailTrailClass =
    environment.localdomain + '/trailclass/sendEmail';
  public getTrailClass = environment.localdomain + '/trailclass/';
  public getSearchTrailClass =
    environment.localdomain + '/trailclass/getTeacher/';
  public getNewClassAPI = environment.localdomain + '/activeclass/';
  public getSearchNewClassAPI =
    environment.localdomain + '/activeclass/getClassesByUniqueId/';
  public getSearchTeacherNewClassAPI =
    environment.localdomain + '/activeclass/getTeachersClasses/';
  public getStudentScheduledAPI = environment.localdomain + '/student/get';
  public updateScheduleThings =
    environment.localdomain + '/student/paymentapproval';
  public activePayementApprovalDetailsAPI =
    environment.localdomain + '/activeclass/paymentapprovaldetails';
  public updateActivePayementApprovalDetailsAPI =
    environment.localdomain + '/activeclass/paymentapprove';
  public updateStudentPaymentAPI =
    environment.localdomain + '/student/paymentapproval/';
  public updateSlotInNewClassAPI =
    environment.localdomain + '/activeclass/scheduleclass';
  public updateFeesAPI =
    environment.localdomain + '/student/updateFeesForStudent';
  public updateSlotReceivedAPI =
    environment.localdomain + '/activeclass/updateschedule';
  public getByActivityNameAPI = environment.localdomain + '/student/';
  public bookingSlotAPI = environment.localdomain + '/student/scheduleslot';
  public updateSlotDetailAPI =
    environment.localdomain + '/activeclass/meetingLink';
  public remainderAPI = environment.localdomain + '/student/remainderstatus';
  public sendRemainderAPI =
    environment.localdomain + '/student/sendRemaindermail';
  public rescheduleUpdateAPI =
    environment.localdomain + '/student/updateReschedule';
  public getRescheduleAPI = environment.localdomain + '/student/';
  public getSearchRescheduleAPI =
    environment.localdomain + '/student/getStudentByUniqueId/';
  public getPaymentHistoryAPI =
    environment.localdomain + '/student/retrievePaymentHistory/';
  public getPaymentHistoryByUniqueAPI =
    environment.localdomain + '/student/getpaymenthistroyByUniqueId/';

  public updatePaymentHistoryAPI =
    environment.localdomain + '/student/paymentApproved';
  public getFeedbackAPI = environment.localdomain + '/feedback/';
  public updateFeedbackAPI =
    environment.localdomain + '/feedback/updatefeedback/';

  constructor(private http: HttpClient) {
    this.currentNavItemSubject = new BehaviorSubject<string>('Teacher');
    this.currentNavItem = this.currentNavItemSubject.asObservable();
  }

  private getRequestOptions(): { headers: HttpHeaders } {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + localStorage.getItem('token'),
    });
    return { headers };
  }

  setCurrentNavItem(navItem: string) {
    this.currentNavItemSubject.next(navItem);
    console.log(this.currentNavItem);
  }

  getteacherData(
    isApproved: string,
    activity: string,
    approve: boolean
  ): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<any>(
      this.getAllTeacherURL + isApproved + activity + '/' + approve,
      requestOptions
    );
  }
  getSearchTeacherData(uniqueID: string): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<any>(
      this.getSearchTeacherURL + uniqueID,
      requestOptions
    );
  }

  approveTeacher(id: string) {
    const requestOptions = this.getRequestOptions();
    return this.http.put(this.approveTeacherURL + id, '', requestOptions);
    // return this.http.put(this.approveTeacherURL + id, requestOptions);
  }
  updateStudentPayemnts(id: string) {
    const requestOptions = this.getRequestOptions();
    return this.http.put(this.updateStudentPaymentAPI + id, '', requestOptions);
    // return this.http.put(this.approveTeacherURL + id, requestOptions);
  }
  updateSlotDetails(body: any) {
    const requestOptions = this.getRequestOptions();
    return this.http.put(this.updateSlotInNewClassAPI, body, requestOptions);
    // return this.http.put(this.approveTeacherURL + id, requestOptions);
  }
  updateSlotReceivedData(body: any) {
    const requestOptions = this.getRequestOptions();
    return this.http.put(this.updateSlotReceivedAPI, body, requestOptions);
    // return this.http.put(this.approveTeacherURL + id, requestOptions);
  }

  approveClass(id: string) {
    const requestOptions = this.getRequestOptions();
    // return this.http.get<any>(this.approveClassURL + id, requestOptions);
    return this.http.put(this.approveClassURL + id, '', requestOptions);
  }

  updateObject(updatedObject: any): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.put<any>(
      this.sendEmailTrailClass,
      updatedObject,
      requestOptions
    );
  }
  updateSchuduledClass(updatedObject: any): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.put<any>(
      this.updateScheduleThings,
      updatedObject,
      requestOptions
    );
  }
  updateActiveClassPayemnts(updatedObject: any): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.put<any>(
      this.updateActivePayementApprovalDetailsAPI,
      updatedObject,
      requestOptions
    );
  }
  updateSlotBooking(updatedObject: any): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.put<any>(
      this.bookingSlotAPI,
      updatedObject,
      requestOptions
    );
  }

  getTrialClasses(
    isApproved: string,
    activity: string,
    approve: boolean
  ): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<any>(
      this.getTrailClass + isApproved + activity + '/' + approve,
      requestOptions
    );
  }
  getSearchTrialClasses(uniqueID: string): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<any>(
      this.getSearchTrailClass + uniqueID,
      requestOptions
    );
  }
  getNewClasses(
    isApproved: string,
    activity: string,
    approve: boolean
  ): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<any>(
      this.getNewClassAPI + isApproved + activity + '/' + approve,
      requestOptions
    );
  }
  getSearchNewClasses(uniqueID: string): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<any>(
      this.getSearchNewClassAPI + uniqueID,
      requestOptions
    );
  }
  getSearcTeacherhNewClasses(uniqueID: string): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<any>(
      this.getSearchTeacherNewClassAPI + uniqueID,
      requestOptions
    );
  }
  getStudentScheduledClasses(): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<any>(this.getStudentScheduledAPI, requestOptions);
  }

  getActiveClassPayments() {
    const requestOptions = this.getRequestOptions();
    return this.http.get<any>(
      this.activePayementApprovalDetailsAPI,
      requestOptions
    );
  }

  getActivityValuesByName(
    isApproved: string,
    activity: string,
    approve: boolean
  ) {
    const requestOptions = this.getRequestOptions();
    return this.http.get<any>(
      this.getByActivityNameAPI + isApproved + activity + '/' + approve,
      requestOptions
    );
  }
  getRemainderValues() {
    const requestOptions = this.getRequestOptions();
    return this.http.get<any>(this.remainderAPI, requestOptions);
  }
  getReschudlesValues(isApproved: string, activity: string, approve: boolean) {
    const requestOptions = this.getRequestOptions();
    return this.http.get<any>(
      this.getRescheduleAPI + isApproved + activity + '/' + approve,
      requestOptions
    );
  }
  getSearchReschudlesValues(uniqueID: string) {
    const requestOptions = this.getRequestOptions();
    return this.http.get<any>(
      this.getSearchRescheduleAPI + uniqueID,
      requestOptions
    );
  }

  sendRemainderMail(updatedObject: any): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.put<any>(
      this.sendRemainderAPI,
      updatedObject,
      requestOptions
    );
  }
  rescheduleClass(updatedObject: any): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.put<any>(
      this.rescheduleUpdateAPI,
      updatedObject,
      requestOptions
    );
  }

  updateMeetingLinkForSlotDetails(id: number, meetingLink: string) {
    // Create HttpParams object to set the query parameters
    let params = new HttpParams();
    params = params.append('id', id);
    params = params.append('meetingLink', meetingLink);
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + localStorage.getItem('token'),
    });

    // Pass params as options in the PUT request
    return this.http.put(this.updateSlotDetailAPI, null, {
      params: params,
      headers: headers,
    });
  }

  updateFeestDetails(body: any) {
    const requestOptions = this.getRequestOptions();
    return this.http.put(this.updateFeesAPI, body, requestOptions);
    // return this.http.put(this.approveTeacherURL + id, requestOptions);
  }
  updatePaymentHistory(body: any) {
    const requestOptions = this.getRequestOptions();
    return this.http.put(this.updatePaymentHistoryAPI, body, requestOptions);
    // return this.http.put(this.approveTeacherURL + id, requestOptions);
  }

  getPaymentHistory(monthNumber, approve: boolean): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<any>(
      this.getPaymentHistoryAPI + monthNumber + '/' + approve,
      requestOptions
    );
  }
  getPaymentHistoryByUniqueID(uniqueId: string, monthNumber): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<any>(
      this.getPaymentHistoryByUniqueAPI + uniqueId + '/' + monthNumber,
      requestOptions
    );
  }

  getFeedbackInfo(apprachString): Observable<any> {
    const requestOptions = this.getRequestOptions();
    return this.http.get<any>(
      this.getFeedbackAPI + apprachString,
      requestOptions
    );
  }

  updatefeedback(id) {
    const requestOptions = this.getRequestOptions();
    return this.http.put(this.updateFeedbackAPI + id, id, requestOptions);
  }
}
