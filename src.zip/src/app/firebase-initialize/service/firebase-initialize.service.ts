import { APP_INITIALIZER, ApplicationRef, Injectable, Injector } from '@angular/core';
import { SwPush, SwUpdate } from '@angular/service-worker';
import { Observable, concat, interval, throwError } from 'rxjs';
import { catchError, first, map } from 'rxjs/operators'
import { Messaging, getToken, isSupported } from '@angular/fire/messaging';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { environment } from '../../../environments/environment.development';

@Injectable({
  providedIn: 'root'
})
export class FirebaseInitializeService {
  private vapidKey = 'BCa6qyX8sst2z3OZGjPygiD4WYCFZgJH0z3nLLxR4t2v3pnEGC-z_MJ2cfXkLCRIEbZRQbakOFUMocjgvZtmsfM';
  public pushNotificationToken = environment.localdomain + '/pushnotification/add';

  constructor(
    private appRef : ApplicationRef, 
    private updateService : SwUpdate,
    private swPush: SwPush,
    private injector: Injector,
    private http: HttpClient,
  ) { }

  async initializePushNotifications(): Promise<void> {
    // const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
    // const isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent) && !/CriOS/i.test(navigator.userAgent) && !/FxiOS/i.test(navigator.userAgent);

    // if (isIOS) {
    //   alert('Push notifications are not supported in Safari on iOS.');
    //   this.requestPermissionForMacOSSafari();
    //   this.subscribeToPush();
    //   this.requestPermission();
    //   return;
    // }

    // if (isSafari) {
    //   console.log('Safari detected: Proceeding with push notifications for macOS Safari');
    //   this.requestPermissionForMacOSSafari();
    //   this.subscribeToPush();
    //   this.requestPermission();
    //   return;
    // }
    console.log('Checking if messaging is supported');
    if (await isSupported()) {
      console.log('Messaging is supported');
      // alert('Push notifications are not supported in android on.');
      this.subscribeToPush();
      this.requestPermission();
    } else {
      console.log('Messaging is not supported on this browser.');
    }
  }


  // private requestPermissionForMacOSSafari(): void {
  //   console.log('Requesting push notification permission for macOS Safari');
  //   // Implement macOS Safari-specific push notifications via APNs here.
  // }

  private subscribeToPush(): void {
    this.swPush.messages.subscribe(
      (message: any) => {
        console.log('Received push message one the data:', message);
      },
      (error) => {
        console.error('Error subscribing to push messages:', error);
      }
    );
  }

  private async requestPermission(): Promise<boolean> {
    try {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        console.log('Notification permission granted');
        const messaging = this.injector.get(Messaging);
        const registration = await navigator.serviceWorker.ready;
        const token = await getToken(messaging, {
          vapidKey: this.vapidKey,
          serviceWorkerRegistration: registration,
        });
        console.log('FCM Token:', token);
        this.firebaseTokanSubmit(token);
        return true;
      } else {
        console.log('Notification permission not granted');
        return false;
      }
    } catch (err) {
      console.error('Error requesting notification permission:', err);
      return false;
    }
  }

  private getRequestOptionsWithToken(): { headers: HttpHeaders } {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + localStorage.getItem('token'),
    });
    return { headers };
  }
  sendDataToFirebaseService(parentId:any): void{
  }
  private firebaseTokanSubmit(token: any): void { 
    const requestOptions = this.getRequestOptionsWithToken();
    const personId = localStorage.getItem('id') 
    const role = localStorage.getItem('role') 
    const params = new HttpParams().set('id', personId).set('notificationToken', token).set('role', role);
    console.log(role,personId,"lllllllllrrrrtxxxxxxxx");
    this.http.post(this.pushNotificationToken, null, { headers: requestOptions.headers, params: params,responseType: 'text' as 'json' }).pipe
    (catchError(this.handleError))
    .subscribe({
      next: response => console.log('POST request successful:', response),
      error: error => console.error('Error in POST request:', error)
    });
  }
  private handleError(error: any): Observable<never> {
    console.error('An error occurred:', error);
    return throwError(() => new Error('Something bad happened; please try again later.'));
  }
}
export function initializeApp(injector: Injector) {
  return async () => {
    const messaging = injector.get(Messaging);
  };
}

export const appInitializerProviders = [
  { provide: APP_INITIALIZER, useFactory: initializeApp, deps: [Injector], multi: true }
];
