import { TestBed } from '@angular/core/testing';

import { FirebaseInitializeService } from './firebase-initialize.service';

describe('FirebaseInitializeService', () => {
  let service: FirebaseInitializeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FirebaseInitializeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
