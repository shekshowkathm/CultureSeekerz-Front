import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FirebaseInitializeRoutingModule } from './firebase-initialize-routing.module';
import { provideFirebaseApp, initializeApp } from '@angular/fire/app';
import { provideMessaging, getMessaging, Messaging } from '@angular/fire/messaging';
import { AngularFireModule } from '@angular/fire/compat';
import { AngularFireMessagingModule } from '@angular/fire/compat/messaging';
import { FirebaseInitializeService } from './service/firebase-initialize.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';

const firebaseConfig = {
  projectId: 'push-notification-40b43',
  appId: '1:690049637641:web:fa360860ddb8bbe07a87d8',
  storageBucket: 'push-notification-40b43.appspot.com',
  apiKey: 'AIzaSyCeW4n7uzZavWUZ29tJf4S8uKuv-9YMF2w',
  authDomain: 'push-notification-40b43.firebaseapp.com',
  messagingSenderId: '690049637641',
  measurementId: 'G-RPEHC2NN86'
};

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    HttpClientModule,
    FirebaseInitializeRoutingModule,
    AngularFireModule.initializeApp(firebaseConfig),
    AngularFireMessagingModule
  ],
  providers: [
    FirebaseInitializeService,
    Messaging,
    provideFirebaseApp(() => initializeApp(firebaseConfig)),
    provideMessaging(() => getMessaging())
  ]
})

export class FirebaseInitializeModule { }
