import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppComponent } from './app/app.component';
import { environment } from './environments/environment.development';

bootstrapApplication(AppComponent, appConfig)
  .catch((err) => console.error(err));
7


  if ('serviceWorker' in navigator && environment.production) {
    navigator.serviceWorker.register('ngsw-worker.js').then(registration => {
      console.log('Service Worker registered with scope:', registration.scope);
  
      // Pass the base URL to the service worker
      if (navigator.serviceWorker.controller) {
        navigator.serviceWorker.controller.postMessage({
          type: 'SET_BASE_URL',
          baseUrl: environment.localdomain // Pass your base URL here
        });
      }
    }).catch(error => {
      console.error('Service Worker registration failed:', error);
    });
  }